package com.voyah.polaris.test;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.voyah.polaris.PolarisAgentManager;
import com.voyah.polaris.event.PolarisEvent;
import android.view.MotionEvent;

public class MainActivity extends Activity {
    private static final String TAG = "PolarisTester";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. 初始化 SDK
        Log.i(TAG, "Initializing Polaris SDK...");
        PolarisAgentManager.getInstance().init(getApplicationContext());

        // 简单构建 UI (不用 XML 了，省事)
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button btnSend = new Button(this);
        btnSend.setText("Send Test Event");
        btnSend.setOnClickListener(v -> sendTestEvent());

        layout.addView(btnSend);
        setContentView(layout);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            sendTestEvent();
            return true; // 消费事件
        }
        return super.onTouchEvent(event);
    }

    private void sendTestEvent() {
        try {
            // 2. 构造事件
            // 参数：EventID, ProcessName, Version
            PolarisEvent event = new PolarisEvent(9999, "PolarisTester", "1.0.0");
            
            Bundle params = new Bundle();
            params.putString("test_key", "Hello from Java");
            params.putLong("timestamp", System.currentTimeMillis());
            event.setParams(params);

            // 3. 发送
            PolarisAgentManager.getInstance().reportEvent(event);
            
            Log.i(TAG, "Event sent: " + event.toString());
            Toast.makeText(this, "Event Sent!", Toast.LENGTH_SHORT).show();
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to send event", e);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 4. 释放资源 (可选)
        PolarisAgentManager.getInstance().release();
    }
}