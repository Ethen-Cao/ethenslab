# Polaris 1.0

ROOT: `vendor/voyah/polaris/`

## Modules
- protocol/: 协议规范与代码生成（Single Source of Truth: global_events.csv）
- sdk/: 公共框架库（AIDL + Java），产出 `polaris-framework.jar`
- app/: PolarisAgent.apk（system app, sharedUserId=android.uid.system）
- native/: polaris_native_daemon

## Codegen
```bash
cd vendor/voyah/polaris/protocol/scripts
python3 -m pip install -r requirements.txt
python3 codegen.py
```

> 生成：
> - `sdk/src/main/java/com/voyah/polaris/event/EventID.java`
> - `native/include/polaris_event.h`

