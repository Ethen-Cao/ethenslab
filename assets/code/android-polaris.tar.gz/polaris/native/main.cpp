#include "core/PolarisManager.h"
#include "message/AppMessageHandler.h"
#include "message/HostMessageHandler.h" // 确保包含
#include "communication/AppTransport.h"
#include "communication/NativeTransport.h"
#include "communication/HostTransport.h"

#include <android-base/logging.h>
#include <binder/ProcessState.h> // 如果 bp 里有 libbinder，建议加上
#include <signal.h>
#include <unistd.h>
#include <condition_variable>
#include <mutex>
#include <iostream>

using namespace voyah::polaris;

// 用于信号处理的同步机制
static std::mutex gMainMutex;
static std::condition_variable gMainCond;
static bool gExitRequested = false;

// 信号处理回调
void SignalHandler(int sig) {
    LOG(INFO) << "Received signal " << sig << ", initiating shutdown...";
    {
        std::lock_guard<std::mutex> lock(gMainMutex);
        gExitRequested = true;
    }
    gMainCond.notify_one();
}

// 注册信号
void SetupSignalHandlers() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = SignalHandler;
    sigaction(SIGTERM, &sa, nullptr);
    sigaction(SIGINT, &sa, nullptr);
    // 忽略 SIGPIPE，防止 socket 对端断开导致进程退出
    signal(SIGPIPE, SIG_IGN); 
}

int main(int argc, char** argv) {
    // 1. 初始化日志
    android::base::InitLogging(argv, android::base::LogdLogger(android::base::SYSTEM));
    LOG(INFO) << "polarisd (v0.2) starting...";

    // 2. 信号注册
    SetupSignalHandlers();

    // 3. (可选) 启动 Binder 线程池
    // 如果后续鉴权需要 Binder，这一步是必须的
    android::ProcessState::self()->startThreadPool();

    // 4. 获取/创建组件实例
    auto appTransport = AppTransport::getInstance();
    auto hostTransport = HostTransport::getInstance();
    auto manager = PolarisManager::getInstance();
    
    // 为了统一管理生命周期，建议 NativeTransport 也使用智能指针（虽然栈变量也可以，但指针更灵活）
    auto nativeTransport = std::make_shared<NativeTransport>();

    // 5. 创建业务 Handlers
    auto appHandler = std::make_shared<AppMessageHandler>();
    auto hostHandler = std::make_shared<HostMessageHandler>();

    // 6. 依赖注入 (Dependency Injection)
    LOG(INFO) << "Wiring dependencies...";
    appTransport->setMessageHandler(appHandler);
    hostTransport->setMessageHandler(hostHandler);

    // 7. 启动所有组件 (Start Phase)
    // 建议顺序：底层 Transport -> 核心逻辑
    LOG(INFO) << "Starting components...";
    
    nativeTransport->start();
    appTransport->start();
    hostTransport->start();
    
    manager->start();

    LOG(INFO) << "polarisd is running and waiting for events.";

    // 8. 主线程阻塞等待退出信号
    // 不再依赖 manager->join()，而是依赖信号量，这样我们可以控制退出的时机
    {
        std::unique_lock<std::mutex> lock(gMainMutex);
        gMainCond.wait(lock, [] { return gExitRequested; });
    }

    LOG(INFO) << "Shutdown signal received. Stopping components...";

    // 9. 显式停止所有组件 (Stop Phase)
    // 必须显式调用 stop，确保线程 Join，不要依赖静态变量析构顺序
    // 停止顺序通常与启动顺序相反：先停入口，再停核心
    
    // 先停 Transport，防止新数据进来
    appTransport->stop();
    hostTransport->stop();
    nativeTransport->stop();
    
    // 最后停 Manager，处理完剩余事件
    manager->stop();
    manager->join(); // 确保 Manager 线程彻底退出

    LOG(INFO) << "polarisd shutdown complete. Bye.";

    return 0;
}