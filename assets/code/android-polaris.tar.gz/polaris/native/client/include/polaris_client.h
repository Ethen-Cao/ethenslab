#pragma once

#include <string>
#include "polarisd/PolarisEvent.h" 

namespace voyah {
namespace polaris {

class PolarisClient {
public:
    static int init();
    static int reportEvent(const PolarisEvent& event);
    static int reportSimple(const std::string& processName, const std::string& msg);
};

} // namespace polaris
} // namespace voyah