#include "polaris_client.h"
#include "protocol/LspCodec.h" 

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <vector>
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

// 内部静态变量持有 fd
static int g_socketFd = -1;

int PolarisClient::init() {
    if (g_socketFd > 0) return 0; // 已初始化

    // [注意]: 使用 SOCK_DGRAM (UDP) 进行上报
    int fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (fd < 0) {
        PLOG(ERROR) << "PolarisClient failed to create socket";
        return -1;
    }

    // 设置发送超时 (防止 sendto 阻塞业务线程)
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 100 * 1000; // 100ms timeout
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    // Native Client 是 UDP 模式，通常不需要 connect，但为了方便使用 send() 可以 connect
    // 或者在 reportEvent 里使用 sendto()。
    // 这里演示使用 sendto 的方式，不需要 connect。
    
    g_socketFd = fd;
    return 0;
}

int PolarisClient::reportEvent(const PolarisEvent& event) {
    if (g_socketFd < 0) {
        if (init() < 0) return -1;
    }

    // [核心逻辑]: 
    // 1. 调用公共库 LspCodec 将 Object 转为 LSP 协议包 (Header + JSON)
    //    这保证了 Client 和 Daemon 使用完全相同的序列化逻辑
    std::vector<uint8_t> packet = LspCodec::encodeEvent(event);

    // 2. 准备目标地址
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    // 对应 polarisd.rc 中的 socket polaris_report dgram ...
    strncpy(addr.sun_path, "/dev/socket/polaris_report", sizeof(addr.sun_path) - 1);

    // 3. 发送 (Fire and Forget)
    ssize_t sent = sendto(g_socketFd, packet.data(), packet.size(), MSG_NOSIGNAL,
                          (struct sockaddr*)&addr, sizeof(addr));

    if (sent < 0) {
        // 即使发送失败也不 crash，仅记录日志 (但在高频路径下最好通过宏控制日志频次)
        // PLOG(ERROR) << "PolarisClient sendto failed";
        return -1;
    }

    return sent;
}

int PolarisClient::reportSimple(const std::string& processName, const std::string& msg) {
    PolarisEvent event;
    event.timestamp = time(nullptr) * 1000; // 简易时间戳
    event.pid = getpid();
    event.processName = processName;
    // 构造一个简单的 JSON params
    event.params = "{\"msg\": \"" + msg + "\"}"; 
    
    return reportEvent(event);
}

} // namespace polaris
} // namespace voyah