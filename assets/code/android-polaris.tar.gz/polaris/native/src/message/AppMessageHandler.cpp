#include "message/AppMessageHandler.h"
#include "communication/AppTransport.h"
// 依赖 Protocol 层进行解码
#include "protocol/LspCodec.h"
// 依赖 Core 层的数据结构和队列
#include "core/EventQueue.h"
#include "polarisd/PolarisManagerEvent.h"
#include "polarisd/CommandResult.h"
#include "communication/AppTransport.h"

#include <android-base/logging.h>

namespace voyah {
namespace polaris {

void AppMessageHandler::onMessage(const std::vector<uint8_t>& data, std::shared_ptr<IResponder> responder) {
    // 1. 准备请求对象
    CommandRequest request;
    
    // 2. 尝试解码 (Bytes -> Object)
    // LspCodec::decodeRequest 会校验 Header、MsgType，并解析 JSON Payload
    if (!LspCodec::decodeRequest(data, request)) {
        LOG(ERROR) << "AppMessageHandler: Failed to decode LSP request. Dropping packet.";
        
        // [可选增强]: 如果解码失败，最好给 App 回复一个协议错误，而不是让 App 超时
        if (responder) {
            auto errResult = std::make_shared<CommandResult>();
            // 尝试从 header 中提取 reqId 用于回执，如果提取不到则为 0
            uint16_t type;
            uint32_t reqId = 0;
            size_t len;
            if (LspCodec::decodeHeader(data, type, reqId, len)) {
                errResult->reqId = reqId;
            }
            errResult->code = -1; // 通用错误码
            errResult->msg = "Protocol Decode Error: Invalid LSP packet or JSON";
            responder->sendResult(errResult);
        }
        return;
    }

    LOG(INFO) << "AppMessageHandler: Received CMD_REQ id=" << request.reqId 
              << ", action=" << request.action 
              << ", target=" << (int)request.target;

    // 3. 封装为内部总线事件 (ManagerEvent)
    auto event = std::make_shared<PolarisManagerEvent>();
    event->type = PolarisManagerEvent::TYPE_APP_CMD_REQ;
    
    // 拷贝/移动 Request 数据
    event->cmdData = std::make_shared<CommandRequest>(request);
    
    // 4. 关键：透传 Context (Responder)
    // 这样 PolarisManager 在处理完后，不需要查表，直接调用 event->responder->sendResult() 即可
    // 这里发生隐式转换 (shared_ptr -> weak_ptr)
    // 引用计数不会增加，这是我们想要的
    event->responder = responder;

    // 5. 推送至核心队列
    EventQueue::getInstance()->push(event);
}

void AppMessageHandler::broadcastEvent(const std::shared_ptr<PolarisEvent>& event) {
    if (!event) {
        LOG(WARNING) << "AppMessageHandler: Attempted to broadcast null event.";
        return;
    }

    // 1. 编码 (Layer 2: Protocol)
    std::vector<uint8_t> packet = LspCodec::encodeEvent(*event);

    // 2. 发送 (Layer 1: Communication)
    // 使用单例访问 Transport
    AppTransport::getInstance()->broadcast(packet);
    
    LOG(DEBUG) << "AppMessageHandler broadcasted event " << event->eventId;
}

} // namespace polaris
} // namespace voyah