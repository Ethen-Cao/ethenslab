#pragma once

#include "polarisd/IResponder.h"
#include "polarisd/PolarisEvent.h"
#include <vector>
#include <memory>
#include <cstdint>

namespace voyah {
namespace polaris {

/**
 * @brief App 消息处理器
 * 负责处理来自 App (PolarisAgent) 的 LSP 数据包。
 * * 主要流程：
 * 1. 接收原始 bytes
 * 2. 调用 LspCodec 解码为 CommandRequest
 * 3. 封装为 PolarisManagerEvent (TYPE_APP_CMD_REQ)
 * 4. Push 到 EventQueue
 */
class AppMessageHandler {
public:
    AppMessageHandler() = default;
    ~AppMessageHandler() = default;

    /**
     * @brief 处理单条消息
     * @param data 完整的 LSP 数据包 (Header + Payload)
     * @param responder 回调接口 (用于 Core 层处理完后回传结果)
     */
    void onMessage(const std::vector<uint8_t>& data, std::shared_ptr<IResponder> responder);
    /**
     * @brief 静态广播方法 (Core -> App)
     * 1. 编码 Event -> Bytes
     * 2. 调用 Transport -> Broadcast
     */
    static void broadcastEvent(const std::shared_ptr<PolarisEvent>& event);
};

} // namespace polaris
} // namespace voyah