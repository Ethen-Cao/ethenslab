#include "message/HostMessageHandler.h"

// 协议层
#include "protocol/PlpCodec.h"
#include "protocol/PacketTypes.h"
#include "protocol/utils/JsonUtils.h"

// 通信层
#include "communication/HostTransport.h"

// 核心层
#include "core/EventQueue.h"
#include "polarisd/PolarisManagerEvent.h"
#include "polarisd/CommandRequest.h"
#include "polarisd/PolarisEvent.h"

// 基础库
#include <android-base/logging.h>
#include <json/json.h> 

namespace voyah {
namespace polaris {

void HostMessageHandler::onMessage(const std::vector<uint8_t>& data, std::shared_ptr<IResponder> responder) {
    // =================================================================
    // 1. PLP 协议层解码 (Layer 2)
    // =================================================================
    PlpCodec::Header header;
    std::vector<uint8_t> payload;

    if (!PlpCodec::decode(data, header, payload)) {
        LOG(ERROR) << "HostMessageHandler: PLP decode failed. Dropping packet.";
        return;
    }

    // 预处理：心跳包 (使用 VERBOSE 避免日志刷屏)
    if (header.type == PLP_TYPE_HEARTBEAT) {
        LOG(VERBOSE) << "HostMessageHandler: Received heartbeat from Host.";
        return; 
    }

    // 预处理：JSON 检查
    if (!(header.flags & PlpCodec::FLAG_IS_JSON)) {
        LOG(WARNING) << "HostMessageHandler: Drop non-JSON payload, type=0x" << std::hex << header.type;
        return;
    }

    // =================================================================
    // 2. JSON 反序列化 (Layer 3 - Zero Copy Optimization)
    // =================================================================
    Json::Value root;
    
    if (!payload.empty()) {
        // [优化]: 直接指针操作，避免 std::string 构造产生的内存拷贝
        const char* begin = reinterpret_cast<const char*>(payload.data());
        const char* end = begin + payload.size();
        
        Json::CharReaderBuilder builder;
        std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
        std::string errs;

        if (!reader->parse(begin, end, &root, &errs)) {
            LOG(ERROR) << "HostMessageHandler: Invalid JSON payload: " << errs;
            return;
        }
    } else {
        // 如果 Payload 为空但不是心跳包，视为异常
        LOG(WARNING) << "HostMessageHandler: Empty payload for type=0x" << std::hex << header.type;
        return;
    }

    // =================================================================
    // 3. 构建 ManagerEvent
    // =================================================================
    auto event = std::make_shared<PolarisManagerEvent>();
    // [关键]: 防止僵尸对象，使用 weak_ptr
    event->responder = responder;

    switch (header.type) {
        // -----------------------------------------------------------
        // 场景 A: Host 下发控制指令 (Host -> Guest)
        // -----------------------------------------------------------
        case PLP_CMD_REQ_H2G: {
            event->type = PolarisManagerEvent::TYPE_HOST_CMD_REQ;
            
            auto req = std::make_shared<CommandRequest>();
            
            // 1. reqId: 复用 PLP SeqID
            req->reqId = header.seqId;
            
            // 2. target: Host 发来的，目标是本端执行
            req->target = CommandTarget::LOCAL;
            
            // 3. action
            req->action = root.get("action", "").asString();
            
            // 4. args (JSON String)
            // [优化]: 复用 JsonUtils::toString 处理 Object/Array 转 String 的逻辑
            // 替代了原本手写的 FastWriter 和 去换行符代码
            if (root.isMember("args")) {
                const Json::Value& argsNode = root["args"];
                if (argsNode.isObject() || argsNode.isArray()) {
                    req->args = JsonUtils::toString(argsNode);
                } else {
                    req->args = argsNode.asString();
                }
            } else {
                req->args = "{}";
            }

            // 5. timeout
            req->timeout = root.get("timeout", 0).asUInt();

            if (req->action.empty()) {
                LOG(ERROR) << "HostMessageHandler: CMD_REQ missing 'action'";
                return;
            }

            event->cmdData = req;
            LOG(INFO) << "HostMessageHandler: REQ id=" << req->reqId << " act=" << req->action;
            break;
        }

        // -----------------------------------------------------------
        // 场景 B: Host 上报感知事件 (Host -> Guest)
        // -----------------------------------------------------------
        case PLP_TYPE_EVENT_H2G: {
            event->type = PolarisManagerEvent::TYPE_HOST_EVENT;

            // [优化]: 使用统一的解析工厂方法
            auto evt = JsonUtils::parsePolarisEvent(root);
            
            if (!evt) {
                // parsePolarisEvent 内部已打印 WARNING
                return;
            }
            
            // 修正来源名称 (可选后处理)
            if (evt->processName == "unknown") {
                evt->processName = "host_system";
            }

            event->eventData = evt;
            LOG(INFO) << "HostMessageHandler: EVENT id=" << evt->eventId << " proc=" << evt->processName;
            break;
        }

        // -----------------------------------------------------------
        // 场景 C: Host 回复 Guest 的请求 (Host -> Guest)
        // -----------------------------------------------------------
        case PLP_CMD_RESP_H2G: {
            // 目前架构主要处理 G2H 的 Request，反向暂未实现 Pending 队列
            LOG(INFO) << "HostMessageHandler: Received Async Response seq=" << header.seqId 
                      << " (Not handled yet)";
            return;
        }

        default:
            LOG(WARNING) << "HostMessageHandler: Unknown PLP Type 0x" << std::hex << header.type;
            return;
    }

    // =================================================================
    // 4. 推入队列
    // =================================================================
    EventQueue::getInstance()->push(event);
}

void HostMessageHandler::broadcastEvent(const std::shared_ptr<PolarisEvent>& event) {
    if (!event) {
        LOG(WARNING) << "HostMessageHandler: broadcastEvent called with null event";
        return;
    }
    // TODO: Implement broadcast logic
    LOG(INFO) << "HostMessageHandler: Broadcasting event id=" << event->eventId;
}
} // namespace polaris
} // namespace voyah