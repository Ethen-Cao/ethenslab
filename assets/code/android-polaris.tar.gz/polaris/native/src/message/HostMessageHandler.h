#pragma once

#include "polarisd/IResponder.h"
#include "polarisd/PolarisEvent.h"
#include <vector>
#include <memory>

namespace voyah {
namespace polaris {

class HostMessageHandler {
public:
    HostMessageHandler() = default;
    ~HostMessageHandler() = default;

    // 处理接收到的消息 (Bytes -> Object -> EventQueue)
    void onMessage(const std::vector<uint8_t>& data, std::shared_ptr<IResponder> responder);

    // [静态广播]: Core -> Host
    static void broadcastEvent(const std::shared_ptr<PolarisEvent>& event);
};

} // namespace polaris
} // namespace voyah