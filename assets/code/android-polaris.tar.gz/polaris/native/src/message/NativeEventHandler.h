#pragma once

#include <vector>
#include <cstdint>

namespace voyah {
namespace polaris {

/**
 * @brief Native 事件处理器
 */
class NativeEventHandler {
public:
    NativeEventHandler() = default;
    ~NativeEventHandler() = default;

    /**
     * @brief 处理单条消息
     * @param data 完整的 LSP 数据包 (右值引用，移交所有权)
     */
    void onMessage(std::vector<uint8_t>&& data);
};

} // namespace polaris
} // namespace voyah