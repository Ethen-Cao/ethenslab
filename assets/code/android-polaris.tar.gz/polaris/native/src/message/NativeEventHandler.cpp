#include "message/NativeEventHandler.h"

#include "protocol/LspCodec.h"
#include "protocol/PacketTypes.h"
#include "protocol/utils/JsonUtils.h" // 复用你的 JsonUtils
#include "core/EventQueue.h"
#include "polarisd/PolarisManagerEvent.h"
#include "polarisd/PolarisEvent.h"   // 确保引用了标准实体定义

#include <android-base/logging.h>
#include <json/json.h>

namespace voyah {
namespace polaris {

// LSP Header 固定长度 (Magic + Ver + Type + ReqId + Len)
static constexpr size_t LSP_HEADER_LEN = 12;

void NativeEventHandler::onMessage(std::vector<uint8_t>&& data) {
    // =================================================================
    // 1. 协议头风控 (Layer 2 Sanity Check)
    // =================================================================
    if (data.size() < LSP_HEADER_LEN) {
        LOG(ERROR) << "NativeEventHandler: Packet too short (" << data.size() << "). Dropping.";
        return;
    }

    uint16_t msgType = 0;
    uint32_t reqId = 0; 
    size_t payloadLen = 0;

    // 解码头部
    if (!LspCodec::decodeHeader(data, msgType, reqId, payloadLen)) {
        LOG(ERROR) << "NativeEventHandler: Invalid LSP header.";
        return;
    }

    // 关键安全检查：防止 Buffer Overflow / 截断
    if (data.size() < LSP_HEADER_LEN + payloadLen) {
        LOG(ERROR) << "NativeEventHandler: Incomplete packet. Declared: " << payloadLen 
                   << ", Actual: " << (data.size() - LSP_HEADER_LEN);
        return;
    }

    // 类型校验：NativeEvent 只应该收到 EVENT_REPORT
    if (msgType != LSP_TYPE_EVENT_REPORT) {
        LOG(WARNING) << "NativeEventHandler: Unexpected msgType 0x" << std::hex << msgType
                     << ". Expected EVENT_REPORT.";
        return;
    }

    // =================================================================
    // 2. JSON 反序列化 (Layer 3)
    // =================================================================
    Json::Value root;
    
    if (payloadLen > 0) {
        // [优化]: 零拷贝解析。直接读取 vector 内存地址。
        const char* begin = reinterpret_cast<const char*>(data.data() + LSP_HEADER_LEN);
        const char* end = begin + payloadLen;
        
        Json::CharReaderBuilder builder;
        std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
        std::string errs;
        
        if (!reader->parse(begin, end, &root, &errs)) {
            LOG(ERROR) << "NativeEventHandler: JSON parse error: " << errs;
            return;
        }
    } else {
        LOG(WARNING) << "NativeEventHandler: Empty payload.";
        return;
    }

    // =================================================================
    // 3. 映射为 PolarisEvent (严格符合 2.1 数据契约)
    // =================================================================
    // [重构]: 使用统一解析逻辑
    auto eventData = JsonUtils::parsePolarisEvent(root);

    if (!eventData) {
        // JsonUtils 内部已经打过 WARNING 了，这里直接返回即可
        return;
    }

    LOG(DEBUG) << "NativeEventHandler: Event " << eventData->eventId 
                 << " from " << eventData->processName;

    // =================================================================
    // 4. 封装入队
    // =================================================================
    auto managerEvent = std::make_shared<PolarisManagerEvent>();
    
    // 标记来源为 Native
    managerEvent->type = PolarisManagerEvent::TYPE_NATIVE_EVENT;
    
    // 只有数据，没有 responder (因为是单向 Event，不需要回包)
    managerEvent->eventData = eventData;
    
    EventQueue::getInstance()->push(managerEvent);
}

} // namespace polaris
} // namespace voyah