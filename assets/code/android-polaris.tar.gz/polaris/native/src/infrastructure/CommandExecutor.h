#pragma once
#include "polarisd/CommandRequest.h"
#include "polarisd/IResponder.h"
#include <thread>

namespace voyah {
namespace polaris {


class CommandExecutor {
public:
    static CommandExecutor* getInstance();
    
    // Async execution
    void execute(std::shared_ptr<CommandRequest> req, std::weak_ptr<IResponder> responder);

private:
    CommandExecutor() = default;
    void workerRoutine(std::shared_ptr<CommandRequest> req, std::weak_ptr<IResponder> responder);
};

} // namespace polaris
} // namespace voyah
