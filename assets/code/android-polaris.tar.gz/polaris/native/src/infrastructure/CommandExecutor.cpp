#include "infrastructure/CommandExecutor.h"
#include "infrastructure/actions/ActionFactory.h" // 引入工厂
#include "core/EventQueue.h"
#include "polarisd/PolarisManagerEvent.h"
#include "polarisd/CommandResult.h" // 确保引入结果定义
#include <android-base/logging.h>
#include <thread> // 必须引入线程库

namespace voyah {
namespace polaris {

// =========================================================
// 1. 单例实现 (之前缺失的部分，导致链接错误)
// =========================================================
CommandExecutor* CommandExecutor::getInstance() {
    static CommandExecutor instance;
    return &instance;
}

// =========================================================
// 2. 公共执行入口 (之前缺失的部分，导致链接错误)
// =========================================================
void CommandExecutor::execute(std::shared_ptr<CommandRequest> req, std::weak_ptr<IResponder> responder) {
    // 启动一个分离线程来处理耗时任务
    // 注意：这里捕获 this 指针、req 和 responder
    std::thread([this, req, responder]() {
        this->workerRoutine(req, responder);
    }).detach();
}

// =========================================================
// 3. 后台工作线程逻辑 (集成 ActionFactory)
// =========================================================
void CommandExecutor::workerRoutine(std::shared_ptr<CommandRequest> req, std::weak_ptr<IResponder> responder) {
    // 检查点 1: Fast Fail - 如果客户端已经断开，直接放弃任务
    if (responder.expired()) {
        LOG(INFO) << "CommandExecutor: Client gone before task started. Aborting " << req->action;
        return;
    }

    LOG(VERBOSE) << "CommandExecutor: Working on action: " << req->action << " (reqId=" << req->reqId << ")";

    // ---------------------------------------------------------
    // A. 使用工厂创建 Action 并执行
    // ---------------------------------------------------------
    auto action = ActionFactory::create(req->action);
    
    CommandResult result; // 栈上对象

    if (action) {
        // 存在对应 Action (如 PingAction) -> 执行 execute()
        result = action->execute(*req);
    } else {
        // 未知 Action -> 返回错误码
        LOG(WARNING) << "CommandExecutor: Unknown action '" << req->action << "'";
        result = CommandResult::makeError(req->reqId, -1, "Unknown Action: " + req->action);
    }

    // ---------------------------------------------------------
    // B. 结果回传处理
    // ---------------------------------------------------------
    
    // 检查点 2: Lazy Fail - 任务做完了，再检查一次客户端还在不在
    if (responder.expired()) {
        LOG(INFO) << "CommandExecutor: Client gone after task finished. Dropping result.";
        return;
    }

    // 封装为 Manager 事件
    auto event = std::make_shared<PolarisManagerEvent>();
    event->type = PolarisManagerEvent::TYPE_CMD_EXEC_RESULT;
    
    // 将栈上的 result 拷贝到堆上的 shared_ptr
    event->resultData = std::make_shared<CommandResult>(result); 
    
    // 传递 Responder 上下文
    event->responder = responder;

    // 推入事件队列，通知主线程发送回包
    EventQueue::getInstance()->push(event);
}

} // namespace polaris
} // namespace voyah