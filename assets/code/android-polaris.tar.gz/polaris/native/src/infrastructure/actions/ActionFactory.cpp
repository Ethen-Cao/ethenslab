#include "infrastructure/actions/ActionFactory.h"

// 引入具体的 Action
#include "infrastructure/actions/PingAction.h"

namespace voyah {
namespace polaris {

std::unique_ptr<BaseAction> ActionFactory::create(const std::string& actionName) {
    if (actionName == "ping") {
        return std::make_unique<PingAction>();
    }

    // 未来扩展点：
    // if (actionName == "get_version") return std::make_unique<GetVersionAction>();
    // if (actionName == "dump_log")    return std::make_unique<DumpLogAction>();

    // 未知命令
    return nullptr;
}

} // namespace polaris
} // namespace voyah