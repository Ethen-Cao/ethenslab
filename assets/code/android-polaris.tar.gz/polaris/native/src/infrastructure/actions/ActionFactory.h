#pragma once

#include "infrastructure/actions/BaseAction.h"
#include <memory>
#include <string>

namespace voyah {
namespace polaris {

class ActionFactory {
public:
    // 使用 unique_ptr，自动管理 Action 对象的生命周期
    // 如果找不到对应的 Action，返回 nullptr
    static std::unique_ptr<BaseAction> create(const std::string& actionName);
};

} // namespace polaris
} // namespace voyah