#pragma once
#include "polarisd/CommandRequest.h"
#include "polarisd/CommandResult.h"

namespace voyah {
namespace polaris {


class BaseAction {
public:
    virtual ~BaseAction() = default;
    virtual CommandResult execute(const CommandRequest& req) = 0;
};

} // namespace polaris
} // namespace voyah
