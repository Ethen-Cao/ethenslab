#pragma once

#include "infrastructure/actions/BaseAction.h"
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

/**
 * @brief 处理 "ping" 命令
 *用于检测链路连通性，直接返回 "pong"
 */
class PingAction : public BaseAction {
public:
    virtual ~PingAction() = default;

    CommandResult execute(const CommandRequest& req) override {
        LOG(INFO) << "Action: Executing PING (reqId=" << req.reqId << ")";
        
        // 使用 CommandResult 的辅助方法构建成功回包
        // reqId:以此请求的 ID 回复
        // data: "pong" (客户端收到后会校验此字符串)
        return CommandResult::makeSuccess(req.reqId, "{\"status\": \"pong\"}");
    }
};

} // namespace polaris
} // namespace voyah