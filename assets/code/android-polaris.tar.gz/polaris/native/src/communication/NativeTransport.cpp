#include "communication/NativeTransport.h"
#include "message/NativeEventHandler.h" 

#include <cutils/sockets.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <android-base/logging.h>
#include <vector>
#include <cerrno>

namespace voyah {
namespace polaris {

// 接收缓冲区大小 (4MB)
// 注意：UDP/DGRAM 的 kernel buffer 限制通常较小，
// 如果发送方发太大，可能在 Kernel 层就丢包了。这里 4MB 是用户态的防御上限。
static constexpr size_t MAX_PACKET_SIZE = 4 * 1024 * 1024;
// 最小协议头长度 (防垃圾包)
static constexpr size_t MIN_HEADER_LEN = 12; 

NativeTransport::NativeTransport() : mSocketFd(-1), mRunning(false) {}

NativeTransport::~NativeTransport() {
    stop();
}

void NativeTransport::start() {
    if (mRunning) return;

    // 获取 socket (init.rc 创建)
    mSocketFd = android_get_control_socket("polaris_report");
    if (mSocketFd < 0) {
        PLOG(ERROR) << "Failed to get control socket 'polaris_report'. Check .rc file";
        return;
    }

    LOG(INFO) << "NativeTransport obtained socket fd=" << mSocketFd;

    mRunning = true;
    mReadThread = std::thread(&NativeTransport::readLoop, this);
}

void NativeTransport::stop() {
    bool expected = true;
    if (mRunning.compare_exchange_strong(expected, false)) {
        // 关闭 Socket 唤醒 recv 阻塞
        if (mSocketFd >= 0) {
            shutdown(mSocketFd, SHUT_RDWR);
            close(mSocketFd);
            mSocketFd = -1;
        }

        if (mReadThread.joinable()) {
            mReadThread.join();
        }
    }
}

void NativeTransport::readLoop() {
    pthread_setname_np(pthread_self(), "NativeTransport");
    LOG(INFO) << "NativeTransport read loop started";

    // 预分配接收 Buffer
    std::vector<uint8_t> buffer(MAX_PACKET_SIZE);

    // 实例化 Handler
    NativeEventHandler eventHandler;

    while (mRunning) {
        // [优化 1]: 使用 MSG_TRUNC 标志
        // 如果数据包 > buffer大小，recvfrom 会返回实际的数据包大小，而不是截断后的大小
        ssize_t n = recvfrom(mSocketFd, buffer.data(), buffer.size(), MSG_TRUNC, nullptr, nullptr);

        if (n < 0) {
            if (errno == EINTR) continue;
            if (mRunning) PLOG(ERROR) << "NativeTransport recvfrom failed";
            break;
        }

        if (n == 0) continue;

        // [优化 2]: 检测截断
        if (static_cast<size_t>(n) > buffer.size()) {
            LOG(ERROR) << "NativeTransport: Packet truncated! Real size: " << n 
                       << ", Buffer size: " << buffer.size() << ". Dropping.";
            // DGRAM 是基于消息的，这一次 recv 丢弃了，不会影响下一次，不需要断开连接
            continue;
        }

        // [优化 3]: 最小长度校验 (Sanity Check)
        if (static_cast<size_t>(n) < MIN_HEADER_LEN) {
            LOG(WARNING) << "NativeTransport: Packet too short (" << n << " bytes). Dropping.";
            continue;
        }

        // 构造数据包 (发生一次内存拷贝)
        std::vector<uint8_t> packetData(buffer.begin(), buffer.begin() + n);

        // [优化 4]: 使用 move 语义传递给 Handler
        // 假设 Handler 签名为: void onMessage(std::vector<uint8_t>&& data);
        eventHandler.onMessage(std::move(packetData));
    }

    LOG(INFO) << "NativeTransport read loop exited";
}

} // namespace polaris
} // namespace voyah