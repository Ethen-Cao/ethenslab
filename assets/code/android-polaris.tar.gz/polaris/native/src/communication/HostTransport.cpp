#include "communication/HostTransport.h"
#include <sys/socket.h>
#include <linux/vm_sockets.h> // VSOCK 定义
#include <unistd.h>
#include <android-base/logging.h>
#include <cerrno>

namespace voyah {
namespace polaris {

// 约定端口 (需与 Host 端 polarisd 一致)
static constexpr unsigned int HOST_PORT = 9001; 
// Host 的 CID 固定为 2
static constexpr unsigned int HOST_CID = 2; // VMADDR_CID_HOST

HostTransport* HostTransport::getInstance() {
    static HostTransport instance;
    return &instance;
}

HostTransport::HostTransport() : mRunning(false) {}

HostTransport::~HostTransport() {
    stop();
}

void HostTransport::setMessageHandler(std::shared_ptr<HostMessageHandler> handler) {
    mHandler = handler;
}

void HostTransport::start() {
    if (mRunning) return;
    mRunning = true;
    mConnectThread = std::thread(&HostTransport::connectLoop, this);
}

void HostTransport::stop() {
    mRunning = false;
    
    // 停止线程
    if (mConnectThread.joinable()) {
        mConnectThread.join();
    }

    // 停止会话
    std::lock_guard<std::mutex> lock(mSessionMutex);
    if (mSession) {
        mSession->stop();
        mSession = nullptr;
    }
}

void HostTransport::broadcast(const std::vector<uint8_t>& data) {
    std::lock_guard<std::mutex> lock(mSessionMutex);
    if (mSession && mSession->isAlive()) {
        mSession->sendRaw(data);
    }
}

void HostTransport::connectLoop() {
    pthread_setname_np(pthread_self(), "HostTransport");
    LOG(INFO) << "HostTransport: Connect loop started. Target CID=" << HOST_CID << " Port=" << HOST_PORT;

    while (mRunning) {
        // 1. 检查当前是否已有连接
        {
            std::lock_guard<std::mutex> lock(mSessionMutex);
            if (mSession && mSession->isAlive()) {
                // 如果连接正常，释放锁并休眠，稍后再检查
                // 我们通过 Session 自身的 readLoop 结束来感知断开
            } else {
                // 如果 Session 死了或为空，清理掉
                mSession = nullptr;
            }
        }

        // 如果有活跃连接，sleep 并 continue，避免重复连接
        // 这种轮询检查虽然简单，但对于“保活”逻辑足够有效
        // 更优雅的方式是使用 condition_variable 等待 session 结束，但这里用 sleep 1s 足够
        if (mSession) {
            sleep(1);
            continue;
        }

        // 2. 开始连接流程
        int fd = socket(AF_VSOCK, SOCK_STREAM, 0);
        if (fd < 0) {
            LOG(ERROR) << "HostTransport: Failed to create VSOCK socket";
            sleep(2);
            continue;
        }

        struct sockaddr_vm sa = {};
        sa.svm_family = AF_VSOCK;
        sa.svm_cid = HOST_CID;
        sa.svm_port = HOST_PORT;

        LOG(VERBOSE) << "HostTransport: Connecting to Host...";

        if (connect(fd, (struct sockaddr*)&sa, sizeof(sa)) != 0) {
            // 连接失败 (Host 可能没启动)
            LOG(WARNING) << "HostTransport: Connect failed"; 
            close(fd);
            sleep(2); // 等待后重试
            continue;
        }

        LOG(INFO) << "HostTransport: Connected to Host! fd=" << fd;

        // 3. 连接成功，创建 Session
        auto newSession = std::make_shared<HostSession>(fd, mHandler);
        newSession->start();

        {
            std::lock_guard<std::mutex> lock(mSessionMutex);
            mSession = newSession;
        }
    }
}

} // namespace polaris
} // namespace voyah