#pragma once
#include "polarisd/IResponder.h"
#include <memory>
#include <vector>
#include <atomic>
#include <thread>
#include <mutex>

namespace voyah {
namespace polaris {

class HostMessageHandler; // 前置声明

class HostSession : public IResponder, public std::enable_shared_from_this<HostSession> {
public:
    // 依赖注入 Handler
    HostSession(int fd, std::shared_ptr<HostMessageHandler> handler);
    ~HostSession();

    void start();
    void stop();

    // IResponder 实现
    void sendResult(std::shared_ptr<CommandResult> result) override;
    
    // 广播接口
    void sendRaw(const std::vector<uint8_t>& data);

    bool isAlive() const { return mRunning; }

private:
    void readLoop();

    int mFd;
    std::shared_ptr<HostMessageHandler> mHandler;
    std::atomic<bool> mRunning;
    std::thread mReadThread;
    std::mutex mSendMutex;
    std::mutex mLifecycleMutex;
};

} // namespace polaris
} // namespace voyah