#include "communication/AppSession.h"
#include "protocol/LspCodec.h"
#include "message/AppMessageHandler.h"

#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <vector>
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

// 接收缓冲区大小 (4MB)
static constexpr size_t MAX_PACKET_SIZE = 4 * 1024 * 1024;
// LSP 头部最小长度 (Magic + Ver + Type + Len = 12 bytes)
static constexpr size_t LSP_HEADER_MIN_LEN = 12;

AppSession::AppSession(int fd, std::shared_ptr<AppMessageHandler> handler) 
    : mFd(fd), mRunning(false), mHandler(handler) {
    LOG(INFO) << "AppSession created, fd=" << mFd;
}

AppSession::~AppSession() {
    stop();
    LOG(INFO) << "AppSession destroyed, fd=" << mFd;
}

void AppSession::start() {
    std::lock_guard<std::mutex> lock(mLifecycleMutex);
    
    if (mRunning) {
        LOG(INFO) << "AppSession already running, fd=" << mFd;
        return;
    }

    if (mFd < 0) {
        LOG(ERROR) << "AppSession start failed: invalid fd=" << mFd;
        return; // 这里 fd < 0 没问题，因为 socket() 失败返回 -1
    }

    mRunning = true;

    // [修正 1]: 使用 shared_from_this() 保活
    // 捕获 self，使引用计数 +1。只要线程不退出，AppSession 对象就不会被析构。
    auto self = shared_from_this();

    // 1. 启动读线程
    mReadThread = std::thread([self]() {
        self->readLoop();
    });

    // 2. 启动写线程
    mWriteThread = std::thread([self]() {
        self->writeLoop();
    });
}

void AppSession::stop() {
    std::lock_guard<std::mutex> lock(mLifecycleMutex);

    mRunning = false;

    // [修正 4]: fd 判断改为 >= 0
    int fd = mFd;
    if (fd >= 0) {
        shutdown(fd, SHUT_RDWR);
        close(fd);
        mFd = -1;
    }

    mQueueCv.notify_all();

    if (mReadThread.joinable()) {
        if (std::this_thread::get_id() != mReadThread.get_id()) mReadThread.join();
        else mReadThread.detach();
    }

    if (mWriteThread.joinable()) {
        if (std::this_thread::get_id() != mWriteThread.get_id()) mWriteThread.join();
        else mWriteThread.detach();
    }
}

void AppSession::readLoop() {
    pthread_setname_np(pthread_self(), "AppSessionReader");

    std::vector<uint8_t> buffer(MAX_PACKET_SIZE);

    while (mRunning) {
        // [修正 2]: 增加 MSG_TRUNC 标志检测截断
        // 如果消息长度 > buffer.size()，MSG_TRUNC 会让 recv 返回实际长度，而不是截断后的长度
        ssize_t n = recv(mFd, buffer.data(), buffer.size(), MSG_NOSIGNAL | MSG_TRUNC);

        if (n < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) continue;
            PLOG(ERROR) << "AppSession recv failed";
            break;
        }

        if (n == 0) {
            LOG(INFO) << "AppSession peer closed connection";
            break;
        }

        // [修正 2]: 处理截断包
        if (static_cast<size_t>(n) > buffer.size()) {
            LOG(ERROR) << "AppSession: Packet truncated! Real size: " << n 
                       << ", Buffer size: " << buffer.size() << ". Dropping connection.";
            break; // 遇到超大包直接断开，防止协议错乱
        }

        // [修正 3]: 基础协议头校验 (Sanity Check)
        if (static_cast<size_t>(n) < LSP_HEADER_MIN_LEN) {
            LOG(ERROR) << "AppSession: Packet too short (" << n << " bytes). Dropping.";
            break; 
        }

        // [修正 3]: 校验 TotalLen 一致性
        // 使用 LspCodec 的标准逻辑读取，不再手写 offset
        uint32_t totalLen = LspCodec::peekTotalLength(buffer); // 或者 buffer 对应的 vector
        if (totalLen != static_cast<size_t>(n)) {
            LOG(ERROR) << "AppSession: Protocol violation. Header len (" << totalLen 
                       << ") != Received len (" << n << ").";
            break;
        }

        // 构造数据包并回调
        std::vector<uint8_t> packetData(buffer.begin(), buffer.begin() + n);

        if (mHandler) {
            mHandler->onMessage(packetData, shared_from_this());
        }
    }

    mRunning = false;
    mQueueCv.notify_all();
    LOG(INFO) << "AppSession readLoop exited";
}

void AppSession::sendResult(std::shared_ptr<CommandResult> result) {
    if (!result) return;
    std::vector<uint8_t> data = LspCodec::encodeResp(*result);
    // sendRaw 现在是非阻塞的，可以直接调用
    sendRaw(data);
}

// [生产者] 将数据压入队列
void AppSession::sendRaw(const std::vector<uint8_t>& data) {
    if (!mRunning || data.empty()) {
        LOG(WARNING) << "AppSession: Attempted to send empty or stopped session data";
        return;
    }

    {
        std::lock_guard<std::mutex> lock(mQueueMutex);
        
        // [背压保护] 如果队列太满，丢弃旧数据，防止 OOM
        if (mSendQueue.size() >= MAX_QUEUE_SIZE) {
            LOG(WARNING) << "AppSession: Send queue full (" << MAX_QUEUE_SIZE << "), dropping old packet.";
            mSendQueue.pop_front(); 
        }

        // 压入队列 (发生拷贝)
        mSendQueue.push_back(data);
    }

    // 唤醒消费者
    mQueueCv.notify_one();
}

// [消费者] 从队列取出并发送
void AppSession::writeLoop() {
    pthread_setname_np(pthread_self(), "AppSessionWrite");

    while (mRunning) {
        std::vector<uint8_t> packet;

        // 1. 获取数据 (阻塞等待)
        {
            std::unique_lock<std::mutex> lock(mQueueMutex);
            
            // 等待条件：队列不为空 或 停止运行
            mQueueCv.wait(lock, [this] { 
                return !mSendQueue.empty() || !mRunning; 
            });

            // 如果被 stop 唤醒且队列空，则退出
            if (!mRunning && mSendQueue.empty()) break;

            // 取出队首数据
            packet = mSendQueue.front();
            mSendQueue.pop_front();
        }

        // 2. 发送数据 (IO 操作在锁外进行)
        if (mFd > 0) {
            // MSG_NOSIGNAL 防止对端断开触发 SIGPIPE
            ssize_t sent = send(mFd, packet.data(), packet.size(), MSG_NOSIGNAL);
            
            if (sent < 0) {
                // EPIPE (Broken pipe) 是正常的断开
                if (errno != EPIPE && errno != ECONNRESET) {
                    PLOG(ERROR) << "AppSession send failed";
                }
                // 发送失败通常意味着连接断开，可以选择在这里 break 退出写线程
                // 或者依赖 readLoop 检测断开来设置 mRunning = false
            }
        }
    }

    LOG(INFO) << "AppSession writeLoop exited";
}

} // namespace polaris
} // namespace voyah