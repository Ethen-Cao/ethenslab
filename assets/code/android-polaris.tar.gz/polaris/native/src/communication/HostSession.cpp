#include "communication/HostSession.h"
#include "message/HostMessageHandler.h"
#include "protocol/PlpCodec.h"      
#include "protocol/utils/JsonUtils.h" 
#include <json/json.h> 
#include <sys/socket.h>
#include <unistd.h>
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

// 缓冲区最大限制 (例如 16MB)，防止恶意数据导致 OOM
static constexpr size_t MAX_BUFFER_SIZE = 16 * 1024 * 1024;

HostSession::HostSession(int fd, std::shared_ptr<HostMessageHandler> handler)
    : mFd(fd), mHandler(handler), mRunning(false) {}

HostSession::~HostSession() {
    stop();
}

void HostSession::start() {
    std::lock_guard<std::mutex> lock(mLifecycleMutex);
    
    if (mRunning) return;
    
    if (mFd < 0) {
        LOG(ERROR) << "HostSession: Cannot start with invalid FD";
        return;
    }

    mRunning = true;
    mReadThread = std::thread(&HostSession::readLoop, this);
    LOG(INFO) << "HostSession started on FD " << mFd;
}

void HostSession::stop() {
    std::lock_guard<std::mutex> lock(mLifecycleMutex);

    // [关键修复] 移除原来的 "if (!mRunning && mFd < 0) return;"
    // 即使业务标志位已停止，只要线程还在 joinable 状态，就必须执行 join 逻辑。
    
    mRunning = false;

    // 1. 关闭 Socket (幂等操作)
    if (mFd > 0) {
        LOG(INFO) << "HostSession: Closing FD " << mFd;
        // shutdown 确保 recv 立即返回，防止死锁
        shutdown(mFd, SHUT_RDWR);
        close(mFd);
        mFd = -1;
    }

    // 2. [关键] 必须无条件检查线程是否需要 Join
    if (mReadThread.joinable()) {
        // 防止在 readLoop 线程内部调用 stop (虽然本架构不会出现，但作为防御性编程)
        if (std::this_thread::get_id() != mReadThread.get_id()) {
            mReadThread.join();
        } else {
            // 自杀场景只能 detach，否则死锁
            LOG(WARNING) << "HostSession: Self-stopping thread, detaching.";
            mReadThread.detach();
        }
    }
}

void HostSession::readLoop() {
    pthread_setname_np(pthread_self(), "HostSessionReader");
    
    std::vector<uint8_t> recvBuf(4096);
    std::vector<uint8_t> pendingData;
    pendingData.reserve(8192);

    while (mRunning) {
        ssize_t n = recv(mFd, recvBuf.data(), recvBuf.size(), 0);
        
        if (n <= 0) {
            // 只有当 mRunning 为 true 时打印警告，避免主动 stop 时的误报
            if (mRunning) {
                LOG(WARNING) << "HostSession: Remote disconnected or read error (errno=" << errno << ")";
            }
            break;
        }

        if (pendingData.size() + n > MAX_BUFFER_SIZE) {
            LOG(ERROR) << "HostSession: Buffer overflow! Dropping connection.";
            break;
        }

        pendingData.insert(pendingData.end(), recvBuf.begin(), recvBuf.begin() + n);

        while (mRunning) {
            if (pendingData.size() < PlpCodec::PLP_HEADER_LEN) break;

            PlpCodec::Header header;
            if (!PlpCodec::decodeHeader(pendingData, header)) {
                LOG(ERROR) << "HostSession: Protocol Header violation. Aborting.";
                mRunning = false;
                break;
            }

            size_t totalLen = PlpCodec::PLP_HEADER_LEN + header.payloadLen;

            if (pendingData.size() < totalLen) {
                if (pendingData.capacity() < totalLen) {
                    pendingData.reserve(totalLen + 1024); 
                }
                break;
            }

            std::vector<uint8_t> packet(pendingData.begin(), pendingData.begin() + totalLen);
            pendingData.erase(pendingData.begin(), pendingData.begin() + totalLen);

            if (mHandler) {
                mHandler->onMessage(packet, shared_from_this());
            }
        }
    }

    // [关键修复] readLoop 退出时，只设置标志位，不关闭 FD，不设 FD 为 -1。
    // 将资源清理工作完全交给 stop() 统一处理，避免竞态条件。
    // 这样能保证 stop() 中的 "if (mFd > 0)" 判断依然有效（虽然本修复主要靠移除 stop 的 early return）。
    
    mRunning = false;
    LOG(INFO) << "HostSession readLoop exited";
    
    // 注意：不要在这里 detach 或做任何线程相关的清理
    // 等待 HostTransport 触发析构 -> 调用 stop() -> join()
}

void HostSession::sendRaw(const std::vector<uint8_t>& data) {
    // 加锁保护 mFd 的使用，防止在 send 过程中 mFd 被 stop 关闭
    // 注意：这里用 mLifecycleMutex 会导致读写锁竞争太大，
    // 建议使用单独的 mSendMutex，并在 stop 中即使关了 FD 也没关系（send 会返回错误）
    // 只要判断 mFd > 0 即可。
    
    if (!mRunning || mFd < 0) return;
    
    std::lock_guard<std::mutex> lock(mSendMutex);
    
    // 双重检查
    if (mFd < 0) return;

    ssize_t sent = send(mFd, data.data(), data.size(), MSG_NOSIGNAL);
    
    if (sent < 0) {
        // EPIPE (32) = Broken pipe，通常意味着对方挂了
        if (errno != EAGAIN && errno != EWOULDBLOCK) {
             LOG(ERROR) << "HostSession: send failed errno=" << errno;
        }
    }
}

void HostSession::sendResult(std::shared_ptr<CommandResult> result) {
    if (!result) return;

    std::vector<uint8_t> packet = PlpCodec::encodeResp(*result);

    if (packet.empty()) {
        LOG(ERROR) << "HostSession: Failed to encode result for reqId=" << result->reqId;
        return;
    }

    sendRaw(packet);
}

} // namespace polaris
} // namespace voyah