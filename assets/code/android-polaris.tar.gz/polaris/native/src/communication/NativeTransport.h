#pragma once

#include <thread>
#include <atomic>
#include <vector>

namespace voyah {
namespace polaris {

// 前置声明
class NativeEventHandler;

/**
 * @brief 负责接收 Native Client (C++) 的事件上报
 * * 机制：SOCK_DGRAM (Unix Domain Datagram)
 */
class NativeTransport {
public:
    NativeTransport();
    ~NativeTransport();

    // 禁止拷贝
    NativeTransport(const NativeTransport&) = delete;
    NativeTransport& operator=(const NativeTransport&) = delete;

    void start();
    void stop();

private:
    void readLoop();

    int mSocketFd;
    std::atomic<bool> mRunning;
    std::thread mReadThread;
};

} // namespace polaris
} // namespace voyah