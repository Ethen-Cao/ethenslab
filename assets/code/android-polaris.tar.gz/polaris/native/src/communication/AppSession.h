#pragma once

#include "polarisd/IResponder.h"
#include "polarisd/CommandResult.h"

#include <memory>
#include <thread>
#include <atomic>
#include <vector>
#include <mutex>
#include <deque>              // [新增] 队列容器
#include <condition_variable> // [新增] 线程同步

namespace voyah {
namespace polaris {

// 前置声明，避免循环引用
class AppMessageHandler;

/**
 * @brief App 会话管理类
 * * 职责：
 * 1. 维护与 PolarisAgent 的 Socket 连接生命周期。
 * 2. [读] 独立线程接收数据，并回调 Handler 处理。
 * 3. [写] 独立线程+缓存队列发送数据，保证发送操作非阻塞。
 */
class AppSession : public IResponder, public std::enable_shared_from_this<AppSession> {
public:
    /**
     * @brief 构造函数
     * @param fd 已连接的客户端 Socket FD
     * @param handler 消息处理器 (依赖注入)
     */
    AppSession(int fd, std::shared_ptr<AppMessageHandler> handler);
    virtual ~AppSession();

    // 禁止拷贝，Session 必须是独占资源
    AppSession(const AppSession&) = delete;
    AppSession& operator=(const AppSession&) = delete;

    /**
     * @brief 启动读写线程
     * 线程安全
     */
    void start();

    /**
     * @brief 停止会话并释放资源
     * 线程安全，支持多次调用 (幂等)
     */
    void stop();

    // IResponder 接口实现
    void sendResult(std::shared_ptr<CommandResult> result) override;

    /**
     * @brief 发送原始二进制数据 (生产者)
     * * 将数据压入发送队列后立即返回。
     * 该方法是非阻塞的，不会卡顿调用者线程。
     * * @param data 要发送的数据 (会发生一次内存拷贝)
     */
    void sendRaw(const std::vector<uint8_t>& data);

    /**
     * @brief 检查会话是否存活
     */
    bool isAlive() const { return mRunning; }

private:
    // 读线程循环 (Socket -> Handler)
    void readLoop();

    // [新增] 写线程循环 (Queue -> Socket)
    void writeLoop();

    int mFd;
    std::atomic<bool> mRunning;

    // 线程句柄
    std::thread mReadThread;
    std::thread mWriteThread; // [新增]

    // 生命周期互斥锁 (保护 start/stop 的原子性)
    std::mutex mLifecycleMutex;

    // 业务处理器
    std::shared_ptr<AppMessageHandler> mHandler;

    // [新增] 发送队列相关
    std::deque<std::vector<uint8_t>> mSendQueue;
    std::mutex mQueueMutex;
    std::condition_variable mQueueCv;

    // 队列最大积压限制 (防止 OOM)
    static constexpr size_t MAX_QUEUE_SIZE = 1000; 
};

} // namespace polaris
} // namespace voyah