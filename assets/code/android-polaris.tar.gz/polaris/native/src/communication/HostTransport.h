#pragma once

#include "communication/HostSession.h"
#include "message/HostMessageHandler.h"
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>

namespace voyah {
namespace polaris {

class HostTransport {
public:
    static HostTransport* getInstance();

    HostTransport();
    ~HostTransport();

    void start();
    void stop();

    // 依赖注入
    void setMessageHandler(std::shared_ptr<HostMessageHandler> handler);

    // 广播 (实际发给唯一的 Host 连接)
    void broadcast(const std::vector<uint8_t>& data);

private:
    /**
     * @brief 客户端连接循环
     * 不断尝试连接 Host (CID 2)，如果断开则自动重连
     */
    void connectLoop();

    // 检查 Session 是否有效，无效则清理
    void checkAndResetSession();

    std::shared_ptr<HostMessageHandler> mHandler;
    
    // Guest -> Host 通常只有一条链路
    std::shared_ptr<HostSession> mSession;
    std::mutex mSessionMutex;
    
    std::atomic<bool> mRunning;
    std::thread mConnectThread;
};

} // namespace polaris
} // namespace voyah