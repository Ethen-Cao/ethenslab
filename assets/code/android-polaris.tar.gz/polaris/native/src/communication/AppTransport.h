#pragma once

#include "AppSession.h"
#include <thread>
#include <atomic>
#include <vector>
#include <mutex>
#include <memory>

namespace voyah {
namespace polaris {

// [修复 1]: 前置声明，解决编译错误
class AppMessageHandler;

class AppTransport {
public:
    static AppTransport* getInstance();

    // [修复 2]: 删除拷贝构造，单例标准写法
    AppTransport(const AppTransport&) = delete;
    AppTransport& operator=(const AppTransport&) = delete;

    void start();
    void stop();
    void setMessageHandler(std::shared_ptr<AppMessageHandler> handler);
    void broadcast(const std::vector<uint8_t>& data);

private:
    // [修复 2]: 构造函数私有化
    AppTransport();
    ~AppTransport();

    void acceptLoop();
    void cleanDeadSessions();

    int mServerSocketFd;
    std::atomic<bool> mRunning;
    std::thread mAcceptThread;

    std::vector<std::shared_ptr<AppSession>> mSessions;
    std::mutex mSessionsMutex;
    std::shared_ptr<AppMessageHandler> mHandler;
};

} // namespace polaris
} // namespace voyah