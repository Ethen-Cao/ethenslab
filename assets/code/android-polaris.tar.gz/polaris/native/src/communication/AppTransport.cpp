#include "communication/AppTransport.h"
#include <cutils/sockets.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <poll.h> // [修复 3]: 引入 poll
#include <android-base/logging.h>
#include <algorithm>

namespace voyah {
namespace polaris {

AppTransport* AppTransport::getInstance() {
    static AppTransport instance;
    return &instance;
}

AppTransport::AppTransport() : mServerSocketFd(-1), mRunning(false) {}

AppTransport::~AppTransport() {
    stop();
}

void AppTransport::start() {
    static std::mutex startMutex;
    std::lock_guard<std::mutex> lock(startMutex);

    if (mRunning) return;

    // 1. 获取 socket
    mServerSocketFd = android_get_control_socket("polaris_bridge");
    if (mServerSocketFd < 0) {
        PLOG(ERROR) << "Failed to get control socket 'polaris_bridge'.";
        return;
    }

    // ============================================================
    // [核心修复]: 显式调用 listen()
    // 参数 10 是 backlog (挂起的连接队列最大长度)
    // 即使 init 已经 listen 过，再次调用也是安全的（通常返回 0）
    // 但如果 init 没 listen，这一步是必须的！
    // ============================================================
    if (listen(mServerSocketFd, 10) < 0) {
        // 如果失败，打印日志帮助排查 (例如 EOPNOTSUPP 或 EBADF)
        PLOG(WARNING) << "AppTransport: listen() failed. (FD=" << mServerSocketFd << ")";
    } else {
        LOG(INFO) << "AppTransport: listen() success. Socket is strictly listening now.";
    }

    LOG(INFO) << "AppTransport obtained socket fd=" << mServerSocketFd;

    mRunning = true;
    mAcceptThread = std::thread(&AppTransport::acceptLoop, this);
}

void AppTransport::stop() {
    mRunning = false; // 标志位先行

    // 关闭 Socket，唤醒 poll
    if (mServerSocketFd >= 0) {
        shutdown(mServerSocketFd, SHUT_RDWR);
        close(mServerSocketFd);
        mServerSocketFd = -1;
    }

    if (mAcceptThread.joinable()) {
        mAcceptThread.join();
    }

    // 停止并清空所有 Session
    std::lock_guard<std::mutex> lock(mSessionsMutex);
    for (auto& session : mSessions) {
        if (session) session->stop();
    }
    mSessions.clear();
    LOG(INFO) << "AppTransport stopped.";
}

void AppTransport::setMessageHandler(std::shared_ptr<AppMessageHandler> handler) {
    mHandler = handler;
}

void AppTransport::acceptLoop() {
    pthread_setname_np(pthread_self(), "AppTransport");
    LOG(INFO) << "AppTransport accept loop started";

    struct pollfd pfd;
    pfd.fd = mServerSocketFd;
    pfd.events = POLLIN;

    while (mRunning) {
        // [核心修复 4]: 优先清理僵尸 Session
        // 放在 poll 之前，确保每次循环都能回收资源
        cleanDeadSessions();

        // [核心修复 5]: 使用 poll 替代阻塞 accept
        // timeout 设置为 2000ms (2秒)
        // 这样即使没有新连接，每 2 秒也会醒来一次，进行 cleanDeadSessions 和 check mRunning
        int pollRet = poll(&pfd, 1, 2000);

        if (pollRet < 0) {
            if (errno == EINTR) continue;
            PLOG(ERROR) << "AppTransport poll failed";
            break; 
        }

        if (pollRet == 0) {
            // 超时，无新连接，进入下一次循环 (去 cleanDeadSessions)
            continue;
        }

        // 有事件发生 (POLLIN)
        if (pfd.revents & POLLIN) {
            struct sockaddr_un clientAddr;
            socklen_t clientAddrLen = sizeof(clientAddr);

            int clientFd = accept(mServerSocketFd, (struct sockaddr*)&clientAddr, &clientAddrLen);
            if (clientFd < 0) {
                if (mRunning) PLOG(WARNING) << "AppTransport accept failed";
                continue;
            }

            LOG(INFO) << "AppTransport accepted connection, fd=" << clientFd;

            // 创建并启动 Session
            auto session = std::make_shared<AppSession>(clientFd, mHandler);
            session->start();

            {
                std::lock_guard<std::mutex> lock(mSessionsMutex);
                mSessions.push_back(session);
            }
        }
    }

    LOG(INFO) << "AppTransport accept loop exited";
}

void AppTransport::cleanDeadSessions() {
    std::lock_guard<std::mutex> lock(mSessionsMutex);
    
    // 统计之前的数量
    size_t before = mSessions.size();

    // 移除已结束的 Session
    auto it = std::remove_if(mSessions.begin(), mSessions.end(), 
        [](const std::shared_ptr<AppSession>& s) {
            // isAlive 返回 false 说明连接已断开
            return s == nullptr || !s->isAlive(); 
        });

    if (it != mSessions.end()) {
        // 注意：remove_if 只是把死元素移到了末尾，erase 才是真正的销毁
        // 销毁时会调用 shared_ptr 的析构 -> AppSession::~AppSession -> stop -> join
        mSessions.erase(it, mSessions.end());
        size_t after = mSessions.size();
        LOG(INFO) << "Cleaned up " << (before - after) << " dead sessions. Active: " << after;
    }
}

void AppTransport::broadcast(const std::vector<uint8_t>& data) {
    if (data.empty()) return;

    // [优化 6]: 缩小锁的粒度 (Copy-on-write 思想)
    // 防止 sendRaw 耗时导致 mSessionsMutex 被长时间占用，阻塞 acceptLoop
    std::vector<std::shared_ptr<AppSession>> sessionsCopy;
    {
        std::lock_guard<std::mutex> lock(mSessionsMutex);
        // 过滤掉无效的，只拷贝活着的
        for (const auto& session : mSessions) {
            if (session && session->isAlive()) {
                sessionsCopy.push_back(session);
            }
        }
    }

    // 在锁外发送
    for (const auto& session : sessionsCopy) {
        session->sendRaw(data);
    }
}

} // namespace polaris
} // namespace voyah