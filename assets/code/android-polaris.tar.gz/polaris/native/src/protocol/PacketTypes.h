#pragma once
#include <cstdint>

namespace voyah {
namespace polaris {


// LSP v1 MsgTypes
constexpr uint16_t LSP_TYPE_EVENT_REPORT = 0x0001;
constexpr uint16_t LSP_TYPE_CMD_REQ      = 0x0020;
constexpr uint16_t LSP_TYPE_CMD_RESP     = 0x0021;

// PLP v1 MsgTypes
constexpr uint16_t PLP_TYPE_HEARTBEAT    = 0x0001;

// Host -> Guest
constexpr uint16_t PLP_TYPE_EVENT_H2G    = 0x0010;
constexpr uint16_t PLP_CMD_RESP_H2G      = 0x0011;
constexpr uint16_t PLP_CMD_REQ_H2G       = 0x0012;

// Guest -> Host
constexpr uint16_t PLP_CMD_REQ_G2H       = 0x0020;
constexpr uint16_t PLP_CMD_RESP_G2H      = 0x0021;
// [新增] Guest 上报事件给 Host
constexpr uint16_t PLP_TYPE_EVENT_G2H    = 0x0022;

} // namespace polaris
} // namespace voyah
