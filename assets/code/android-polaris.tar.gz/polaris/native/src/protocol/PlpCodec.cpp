#include "protocol/PlpCodec.h"
#include "protocol/PacketTypes.h"
#include "protocol/utils/JsonUtils.h"
#include <android-base/logging.h>
#include <cstring>
#include <array>
#include <json/json.h>

namespace voyah {
namespace polaris {

// ==========================================
// CRC32 Helper
// ==========================================
namespace {
    constexpr std::array<uint32_t, 256> generateCrc32Table() {
        std::array<uint32_t, 256> table{};
        for (uint32_t i = 0; i < 256; ++i) {
            uint32_t crc = i;
            for (int j = 0; j < 8; ++j) {
                if (crc & 1) crc = (crc >> 1) ^ 0xEDB88320;
                else crc >>= 1;
            }
            table[i] = crc;
        }
        return table;
    }

    static constexpr auto kCrc32Table = generateCrc32Table();

    uint32_t calculateCrc32(const uint8_t* data, size_t length) {
        uint32_t crc = 0xFFFFFFFF;
        for (size_t i = 0; i < length; ++i) {
            uint8_t byte = data[i];
            uint32_t lookupIndex = (crc ^ byte) & 0xFF;
            crc = (crc >> 8) ^ kCrc32Table[lookupIndex];
        }
        return ~crc;
    }
}

// ==========================================
// Implementation
// ==========================================

std::vector<uint8_t> PlpCodec::encode(uint16_t type, uint32_t seqId, uint16_t flags, 
                                      const std::vector<uint8_t>& payload) {
    if (payload.size() > MAX_PAYLOAD_SIZE) {
        LOG(ERROR) << "PLP Encode: Payload too large (" << payload.size() << ")";
        return {};
    }

    size_t totalSize = PLP_HEADER_LEN + payload.size();
    std::vector<uint8_t> buffer(totalSize);

    // 1. 准备 Header
    Header header;
    header.magic = PLP_MAGIC;
    header.version = PLP_VERSION;
    header.headerLen = PLP_HEADER_LEN;
    header.payloadLen = static_cast<uint32_t>(payload.size());
    header.type = type;
    header.flags = flags;
    header.seqId = seqId;
    header.crc32 = calculateCrc32(payload.data(), payload.size());

    // 2. 写入 Header (使用 memcpy 安全写入)
    std::memcpy(buffer.data(), &header, PLP_HEADER_LEN);

    // 3. 写入 Payload
    if (!payload.empty()) {
        std::memcpy(buffer.data() + PLP_HEADER_LEN, payload.data(), payload.size());
    }

    return buffer;
}

bool PlpCodec::decodeHeader(const std::vector<uint8_t>& data, Header& outHeader) {
    if (data.size() < PLP_HEADER_LEN) {
        return false;
    }

    // [优化]: 使用 memcpy 安全读取，避免 reinterpret_cast 对齐问题
    Header h;
    std::memcpy(&h, data.data(), PLP_HEADER_LEN);

    // 1. 魔数校验
    if (h.magic != PLP_MAGIC) {
        // LOG(VERBOSE) << "PLP Decode: Waiting for Magic..."; 
        // 只有 debug 模式才打印，否则噪音太大
        return false;
    }

    // 2. 版本校验
    if (h.version != PLP_VERSION) {
        LOG(WARNING) << "PLP Decode: Version mismatch (" << h.version << ")";
        return false;
    }

    // 3. 头部长度校验
    if (h.headerLen != PLP_HEADER_LEN) {
        LOG(ERROR) << "PLP Decode: Invalid Header Len " << h.headerLen;
        return false;
    }
    
    // 4. [新增]: Payload 长度风控
    if (h.payloadLen > MAX_PAYLOAD_SIZE) {
        LOG(ERROR) << "PLP Decode: Payload len too large (" << h.payloadLen << ")";
        return false;
    }

    outHeader = h;
    return true;
}

bool PlpCodec::decode(const std::vector<uint8_t>& data, 
                      Header& outHeader, 
                      std::vector<uint8_t>& outPayload) {
    // 1. 解析头部
    if (!decodeHeader(data, outHeader)) {
        return false;
    }

    // 2. 长度完整性校验
    // 注意：这里要防止加法溢出，虽然有 MAX_PAYLOAD_SIZE 保护，但严谨起见
    size_t expectedTotalLen = static_cast<size_t>(PLP_HEADER_LEN) + outHeader.payloadLen;
    if (data.size() != expectedTotalLen) {
        LOG(ERROR) << "PLP Decode: Size mismatch. Header=" << outHeader.payloadLen 
                   << ", Total=" << expectedTotalLen << ", Actual=" << data.size();
        return false;
    }

    // 3. 提取 Payload & CRC 校验
    if (outHeader.payloadLen > 0) {
        const uint8_t* payloadPtr = data.data() + PLP_HEADER_LEN;
        
        // CRC 校验
        uint32_t calculatedCrc = calculateCrc32(payloadPtr, outHeader.payloadLen);
        if (calculatedCrc != outHeader.crc32) {
            LOG(ERROR) << "PLP Decode: CRC32 Failed! Header=" << std::hex << outHeader.crc32 
                       << ", Calc=" << calculatedCrc;
            return false;
        }

        // 拷贝数据
        outPayload.assign(payloadPtr, payloadPtr + outHeader.payloadLen);
    } else {
        outPayload.clear();
    }

    return true;
}

// =================================================================
// [新增] 业务接口实现
// =================================================================

std::vector<uint8_t> PlpCodec::encodeResp(const CommandResult& result) {
    // 1. 构建 JSON 对象
    Json::Value root;
    root["reqId"] = result.reqId;
    root["code"]  = result.code;
    root["msg"]   = result.msg;

    // data 字段处理: 尝试解析为 JSON 对象以避免转义，失败则作为字符串
    if (!result.data.empty()) {
        Json::Value dataObj;
        if (JsonUtils::fromString(result.data, dataObj)) {
            root["data"] = dataObj;
        } else {
            root["data"] = result.data;
        }
    }

    // 2. 序列化 Payload (JSON -> String -> Bytes)
    std::string jsonStr = JsonUtils::toString(root);
    std::vector<uint8_t> payload(jsonStr.begin(), jsonStr.end());

    // 3. 打包 PLP
    // Type: PLP_CMD_RESP_G2H (0x0021) - 表示这是 Guest 回复给 Host 的
    // SeqID: 必须回填请求的 reqId，以便 Host 进行匹配
    // Flags: 标记为 JSON
    return encode(PLP_CMD_RESP_G2H, result.reqId, FLAG_IS_JSON, payload);
}

bool PlpCodec::decodeRequest(const std::vector<uint8_t>& data, CommandRequest& outReq) {
    Header header;
    std::vector<uint8_t> payload;

    // 1. 基础解码 (二进制拆包)
    if (!decode(data, header, payload)) {
        return false;
    }

    // 2. 类型校验 (必须是 Host 发给 Guest 的请求)
    // 注意：PLP_CMD_REQ_H2G 需要在 PacketTypes.h 中定义 (0x0012)
    if (header.type != PLP_CMD_REQ_H2G) {
        LOG(WARNING) << "PlpCodec: Unexpected MsgType 0x" << std::hex << header.type 
                     << " (Expected CMD_REQ_H2G)";
        return false;
    }

    // 3. JSON 格式检查
    if (!(header.flags & FLAG_IS_JSON)) {
        LOG(ERROR) << "PlpCodec: Payload is not JSON";
        return false;
    }

    // 4. 反序列化 Payload
    std::string jsonStr(payload.begin(), payload.end());
    Json::Value root;
    if (!JsonUtils::fromString(jsonStr, root)) {
        LOG(ERROR) << "PlpCodec: Invalid JSON payload: " << jsonStr;
        return false;
    }

    // 5. 填充 CommandRequest 对象
    // [关键]: PLP 的 SeqID 映射为 CommandRequest 的 reqId
    outReq.reqId = header.seqId; 
    outReq.target = CommandTarget::LOCAL; // Host 发来的，当然是本地执行

    outReq.action = root.get("action", "").asString();
    
    // args 处理
    if (root["args"].isObject() || root["args"].isArray()) {
        outReq.args = JsonUtils::toString(root["args"]);
    } else {
        outReq.args = root.get("args", "").asString();
    }

    // timeout 处理
    outReq.timeout = root.get("timeout", 0).asUInt();

    if (outReq.action.empty()) {
        LOG(ERROR) << "PlpCodec: Missing 'action' field";
        return false;
    }

    return true;
}

} // namespace polaris
} // namespace voyah