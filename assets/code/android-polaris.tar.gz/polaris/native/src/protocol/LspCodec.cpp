#include "protocol/LspCodec.h"
#include "protocol/PacketTypes.h"
#include "protocol/utils/JsonUtils.h"

#include <android-base/logging.h>
#include <cstring> // memcpy
#include <json/json.h>

namespace voyah {
namespace polaris {

// ==========================================
// Internal Helpers
// ==========================================

std::vector<uint8_t> LspCodec::pack(uint16_t msgType, uint32_t reqId, const std::string& payload) {
    size_t totalSize = HEADER_LEN + payload.size();

    std::vector<uint8_t> buffer(totalSize);

    // [优化]: 使用局部变量构造 Header，然后 memcpy 写入 buffer
    // 避免 reinterpret_cast 带来的 strict aliasing 和对齐风险
    Header header;
    header.totalLen = static_cast<uint32_t>(totalSize);
    header.msgType = msgType;
    header.reserved = 0;
    header.reqId = reqId;

    // 安全写入 Header
    std::memcpy(buffer.data(), &header, HEADER_LEN);

    // 写入 Payload
    if (!payload.empty()) {
        std::memcpy(buffer.data() + HEADER_LEN, payload.data(), payload.size());
    }

    return buffer;
}

// ==========================================
// Encoding Implementation (保持逻辑不变，仅展示结构)
// ==========================================

std::vector<uint8_t> LspCodec::encodeEvent(const PolarisEvent& event) {
    Json::Value root;
    root["eventId"] = (Json::UInt64)event.eventId;
    root["timestamp"] = (Json::UInt64)event.timestamp;
    root["pid"] = event.pid;
    root["processName"] = event.processName;
    root["processVer"] = event.processVer;
    
    // params 尝试作为 JSON 对象嵌入
    if (!event.params.empty()) {
        Json::Value paramsObj;
        if (JsonUtils::fromString(event.params, paramsObj)) {
            root["params"] = paramsObj;
        } else {
            root["params"] = event.params;
        }
    }

    if (!event.logf.empty()) {
        root["logf"] = event.logf;
    }

    return pack(LSP_TYPE_EVENT_REPORT, 0, JsonUtils::toString(root));
}

std::vector<uint8_t> LspCodec::encodeResp(const CommandResult& result) {
    Json::Value root;
    root["reqId"] = result.reqId;
    root["code"] = result.code;
    root["msg"] = result.msg;

    if (!result.data.empty()) {
        Json::Value dataObj;
        if (JsonUtils::fromString(result.data, dataObj)) {
            root["data"] = dataObj;
        } else {
            root["data"] = result.data;
        }
    }

    return pack(LSP_TYPE_CMD_RESP, result.reqId, JsonUtils::toString(root));
}

// ==========================================
// Decoding Implementation
// ==========================================

bool LspCodec::decodeHeader(const std::vector<uint8_t>& data, 
                            uint16_t& outMsgType, 
                            uint32_t& outReqId, 
                            size_t& outPayloadLen) {
    // 1. 最小长度检查
    if (data.size() < HEADER_LEN) {
        return false;
    }

    // [优化]: 使用 memcpy 安全读取 Header
    Header header;
    std::memcpy(&header, data.data(), HEADER_LEN);

    // 2. 完整性检查
    if (header.totalLen != data.size()) {
        LOG(ERROR) << "LSP Decode: Size mismatch. Header=" << header.totalLen 
                   << ", Actual=" << data.size();
        return false;
    }

    // 3. [鲁棒性]: 防止 totalLen 小于 Header 导致的下溢
    if (header.totalLen < HEADER_LEN) {
        LOG(ERROR) << "LSP Decode: Invalid totalLen " << header.totalLen;
        return false;
    }

    outMsgType = header.msgType;
    outReqId = header.reqId;
    outPayloadLen = header.totalLen - HEADER_LEN;

    return true;
}

bool LspCodec::decodeRequest(const std::vector<uint8_t>& data, CommandRequest& outReq) {
    uint16_t msgType;
    uint32_t reqId;
    size_t payloadLen;

    if (!decodeHeader(data, msgType, reqId, payloadLen)) {
        return false;
    }

    if (msgType != LSP_TYPE_CMD_REQ) {
        LOG(ERROR) << "LSP Decode: Expected CMD_REQ, got 0x" << std::hex << msgType;
        return false;
    }

    Json::Value root;
    if (payloadLen > 0) {
        // [优化]: 零拷贝解析 (Zero-copy parsing)
        const char* begin = reinterpret_cast<const char*>(data.data() + HEADER_LEN);
        const char* end = begin + payloadLen;
        
        Json::CharReaderBuilder builder;
        std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
        std::string errs;
        
        if (!reader->parse(begin, end, &root, &errs)) {
            LOG(ERROR) << "LSP Decode: JSON parse failed: " << errs;
            return false;
        }
    } else {
        // 允许空 Payload 吗？如果业务不允许，这里应该报错。暂时允许。
        // LOG(WARNING) << "LSP Decode: Empty payload";
    }

    // 字段映射
    if (root.isMember("reqId")) {
        outReq.reqId = root["reqId"].asUInt();
    } else {
        outReq.reqId = reqId; // Fallback to header reqId
    }

    std::string targetStr = root.get("target", "LOCAL").asString();
    outReq.target = (targetStr == "HOST") ? CommandTarget::HOST : CommandTarget::LOCAL;
    
    outReq.action = root.get("action", "").asString();
    outReq.timeout = root.get("timeout", 3000).asUInt();

    if (root.isMember("args")) {
        Json::Value argsNode = root["args"];
        if (argsNode.isObject() || argsNode.isArray()) {
            outReq.args = JsonUtils::toString(argsNode);
        } else {
            outReq.args = argsNode.asString();
        }
    } else {
        outReq.args = "";
    }

    return true;
}

} // namespace polaris
} // namespace voyah