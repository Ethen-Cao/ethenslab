#pragma once

#include <string>
#include <json/json.h> // 依赖 libjsoncpp
#include "polarisd/PolarisEvent.h" // 引用标准实

namespace voyah {
namespace polaris {

class JsonUtils {
public:
    /**
     * @brief 将 Json::Value 对象序列化为紧凑的字符串 (无换行/空格)
     * @param root JSON 对象
     * @return 序列化后的字符串
     */
    static std::string toString(const Json::Value& root);

    /**
     * @brief 将 JSON 字符串解析为 Json::Value 对象
     * @param jsonStr 输入的 JSON 字符串
     * @param outRoot 输出的 JSON 对象
     * @return true 解析成功, false 解析失败
     */
    static bool fromString(const std::string& jsonStr, Json::Value& outRoot);

    // [新增] 统一的 PolarisEvent 解析工厂
    // 输入: 已解析好的 Json::Value
    // 输出: 填充好的 PolarisEvent 对象
    static std::shared_ptr<PolarisEvent> parsePolarisEvent(const Json::Value& root);

    // 序列化：PolarisEvent -> Json::Value
    static Json::Value toJson(const PolarisEvent& event);
};

} // namespace polaris
} // namespace voyah