#include "protocol/utils/JsonUtils.h"
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

std::string JsonUtils::toString(const Json::Value& root) {
    // 使用 StreamWriterBuilder 工厂模式
    Json::StreamWriterBuilder builder;
    
    // 关键配置：设置缩进为空字符串，实现“紧凑模式”
    // 默认情况下 jsoncpp 可能会输出带换行的 Pretty Print，这会浪费 Socket 带宽
    builder["indentation"] = ""; 

    return Json::writeString(builder, root);
}

bool JsonUtils::fromString(const std::string& jsonStr, Json::Value& outRoot) {
    if (jsonStr.empty()) {
        return false;
    }

    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    std::string errs;

    // 解析逻辑
    bool success = reader->parse(jsonStr.data(), jsonStr.data() + jsonStr.size(), &outRoot, &errs);
    
    if (!success) LOG(ERROR) << "JSON Parse error: " << errs;

    return success;
}

std::shared_ptr<PolarisEvent> JsonUtils::parsePolarisEvent(const Json::Value& root) {
    auto evt = std::make_shared<PolarisEvent>();

    // 1. 必填字段解析
    evt->eventId     = root.get("eventId", 0).asUInt64();
    evt->timestamp   = root.get("timestamp", 0).asUInt64();
    evt->pid         = root.get("pid", 0).asInt();
    evt->processName = root.get("processName", "unknown").asString();
    evt->processVer  = root.get("processVer", "1.0").asString();

    // 2. 选填字段 - logf
    if (root.isMember("logf")) {
        evt->logf = root["logf"].asString();
    }

    // 3. 选填字段 - params (统一转 String)
    if (root.isMember("params")) {
        const Json::Value& paramsNode = root["params"];
        if (paramsNode.isObject() || paramsNode.isArray()) {
            // 复用 toString，无需重复造轮子 (FastWriter + 去换行)
            evt->params = toString(paramsNode);
        } else {
            evt->params = paramsNode.asString();
        }
    }

    // 4. 基础校验 (Guard)
    if (evt->eventId == 0 || evt->processName.empty()) {
        // 这里可以选择打印日志，或者返回 nullptr 让调用者处理
        LOG(WARNING) << "JsonUtils: Invalid Event Data (id=0 or no procName)";
        return nullptr;
    }

    return evt;
}

Json::Value JsonUtils::toJson(const PolarisEvent& event) {
    Json::Value root;
    root["eventId"]     = (Json::UInt64)event.eventId;
    root["timestamp"]   = (Json::UInt64)event.timestamp;
    root["pid"]         = event.pid;
    root["processName"] = event.processName;
    root["processVer"]  = event.processVer;

    if (!event.logf.empty()) {
        root["logf"] = event.logf;
    }

    // 智能处理 params：尝试还原为 JSON 对象，还原失败则存为字符串
    // 这样 Host 端收到的就是 {"params": {"cpu": 1}} 而不是 {"params": "{\"cpu\": 1}"}
    if (!event.params.empty()) {
        Json::Value paramsObj;
        if (fromString(event.params, paramsObj)) {
            root["params"] = paramsObj;
        } else {
            root["params"] = event.params;
        }
    }
    return root;
}

} // namespace polaris
} // namespace voyah