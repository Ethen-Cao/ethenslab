#pragma once

#include <vector>
#include <cstdint>
#include <string>

#include "polarisd/PolarisEvent.h"
#include "polarisd/CommandRequest.h"
#include "polarisd/CommandResult.h"

namespace voyah {
namespace polaris {

/**
 * @brief LSP v1 编解码器
 * 注意：本协议使用 Host Byte Order (通常为 Little Endian)，仅限本机 IPC 使用。
 * 若需跨网络/跨架构传输，需增加字节序转换。
 */
class LspCodec {
public:
    static std::vector<uint8_t> encodeEvent(const PolarisEvent& event);
    static std::vector<uint8_t> encodeResp(const CommandResult& result);

    static bool decodeHeader(const std::vector<uint8_t>& data, 
                             uint16_t& outMsgType, 
                             uint32_t& outReqId, 
                             size_t& outPayloadLen);

    static bool decodeRequest(const std::vector<uint8_t>& data, CommandRequest& outReq);

    // [新增] 静态辅助函数，安全地提取长度
    static uint32_t peekTotalLength(const std::vector<uint8_t>& buffer) {
        if (buffer.size() < sizeof(uint32_t)) return 0;
        // 直接强转读取，保证与 struct 定义一致
        // 注意：这是本机 Socket，不用管 ntohl，直接读内存
        return *reinterpret_cast<const uint32_t*>(buffer.data());
    }

private:
    // 显式取消结构体填充，确保跨编译器一致性
    struct Header {
        uint32_t totalLen;
        uint16_t msgType;
        uint16_t reserved;
        uint32_t reqId;
    } __attribute__((packed));

    static constexpr size_t HEADER_LEN = sizeof(Header);

    static std::vector<uint8_t> pack(uint16_t msgType, uint32_t reqId, const std::string& payload);
};

} // namespace polaris
} // namespace voyah