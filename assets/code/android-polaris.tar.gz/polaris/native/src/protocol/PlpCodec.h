#pragma once

#include <vector>
#include <cstdint>
#include <vector>
#include "polarisd/CommandResult.h"  // [新增]
#include "polarisd/CommandRequest.h" // [新增]

namespace voyah {
namespace polaris {

/**
 * @brief PLP (Polaris Link Protocol) 编解码器
 * 用于 Host (Linux) 与 Guest (Android) 之间的 VSOCK 通信
 * * 注意：本协议假定双方均为 Little Endian 字节序。
 * 如果涉及跨字节序通信，需增加 swap 处理。
 */
class PlpCodec {
public:
    static constexpr uint32_t PLP_MAGIC = 0x504C5253; // "PLRS"
    static constexpr uint16_t PLP_VERSION = 1;
    static constexpr uint16_t PLP_HEADER_LEN = 24;

    // 限制最大包大小 (例如 16MB)，防止恶意 OOM
    static constexpr size_t MAX_PAYLOAD_SIZE = 16 * 1024 * 1024;

    static constexpr uint16_t FLAG_IS_JSON = 1 << 0;
    static constexpr uint16_t FLAG_GZIP    = 1 << 1;

    struct Header {
        uint32_t magic;      
        uint16_t version;    
        uint16_t headerLen;  
        uint32_t payloadLen; 
        uint16_t type;       
        uint16_t flags;      
        uint32_t seqId;      
        uint32_t crc32;      
    } __attribute__((packed));

    static std::vector<uint8_t> encode(uint16_t type, uint32_t seqId, uint16_t flags, 
                                       const std::vector<uint8_t>& payload);

    static bool decode(const std::vector<uint8_t>& data, 
                       Header& outHeader, 
                       std::vector<uint8_t>& outPayload);

    static bool decodeHeader(const std::vector<uint8_t>& data, Header& outHeader);

    // =================================================================
    // [新增业务接口] - 针对 Host 通信场景
    // =================================================================

    /**
     * @brief [G2H] 编码命令执行结果 (Android -> Host)
     * 将 CommandResult 序列化为 JSON，并打包成 PLP_CMD_RESP_G2H
     */
    static std::vector<uint8_t> encodeResp(const CommandResult& result);

    /**
     * @brief [H2G] 解码命令请求 (Host -> Android)
     * 解析 PLP 包，校验类型是否为 CMD_REQ，并反序列化 JSON 到 CommandRequest
     */
    static bool decodeRequest(const std::vector<uint8_t>& data, CommandRequest& outReq);
};

} // namespace polaris
} // namespace voyah