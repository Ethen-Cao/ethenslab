#include "core/EventQueue.h"
#include <android-base/logging.h>

namespace voyah {
namespace polaris {

EventQueue* EventQueue::getInstance() {
    static EventQueue instance;
    return &instance;
}

void EventQueue::push(std::shared_ptr<PolarisManagerEvent> event) {
    if (!event) return;

    {
        std::lock_guard<std::mutex> lock(mMutex);

        // [量产标准]: 容量保护
        if (mQueue.size() >= MAX_QUEUE_SIZE) {
            // 策略：丢弃队首 (最旧的) 事件，腾出空间
            // 这种策略适合实时系统，优先处理最新消息
            // 也可以选择丢弃新事件 (return)，视业务需求而定
            mQueue.pop_front();
            
            // 降频打印日志，避免日志风暴 (每丢弃 100 个打印一次，或者只打印 Warning)
            // 这里简单处理，生产环境建议使用计数器限流打印
            static int dropCount = 0;
            if (++dropCount % 100 == 0) {
                LOG(WARNING) << "EventQueue: Full (" << MAX_QUEUE_SIZE 
                             << "), dropping oldest events. Total dropped: " << dropCount;
            }
        }

        mQueue.push_back(event);
    }
    
    // 唤醒消费者
    mCv.notify_one();
}

std::shared_ptr<PolarisManagerEvent> EventQueue::pop() {
    std::unique_lock<std::mutex> lock(mMutex);
    
    // 阻塞等待
    mCv.wait(lock, [this] { return !mQueue.empty(); });

    // 取出队首
    auto event = mQueue.front();
    mQueue.pop_front();

    return event;
}

void EventQueue::clear() {
    std::lock_guard<std::mutex> lock(mMutex);
    mQueue.clear();
    LOG(INFO) << "EventQueue: Cleared.";
}

size_t EventQueue::size() {
    std::lock_guard<std::mutex> lock(mMutex);
    return mQueue.size();
}

} // namespace polaris
} // namespace voyah