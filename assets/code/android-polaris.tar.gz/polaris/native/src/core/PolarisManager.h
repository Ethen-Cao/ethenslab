#pragma once

#include "polarisd/PolarisManagerEvent.h"
#include <thread>
#include <atomic>
#include <memory>

namespace voyah {
namespace polaris {

/**
 * @brief 系统核心管理器 (单例)
 * * 职责：
 * 1. 启动主事件循环线程
 * 2. 从 EventQueue 阻塞获取事件
 * 3. 根据事件类型执行策略 (Policy Dispatch)
 * - App 命令 -> 转发给 Executor
 * - 执行结果 -> 通过 Responder 回调
 * - Native 事件 -> 触发联动策略 (如抓 Log)
 */
class PolarisManager {
public:
    // 删除拷贝构造
    PolarisManager(const PolarisManager&) = delete;
    PolarisManager& operator=(const PolarisManager&) = delete;

    static PolarisManager* getInstance();

    /**
     * @brief 启动管理器线程
     */
    void start();

    /**
     * @brief 停止并等待线程退出
     */
    void join();

    /**
     * @brief 停止标志位 (但不一定能立即打断阻塞的 pop)
     */
    void stop();

private:
    PolarisManager() = default;
    ~PolarisManager();

    /**
     * @brief 主线程循环函数
     */
    void runLoop();

    /**
     * @brief 核心策略分发
     */
    void processEvent(std::shared_ptr<PolarisManagerEvent> event);

    /**
     * @brief 处理 App 下发的命令请求
     */
    void handleAppCmdReq(std::shared_ptr<PolarisManagerEvent> event);

    /**
     * @brief 处理命令执行结果 (闭环)
     */
    void handleCmdResult(std::shared_ptr<PolarisManagerEvent> event);

    /**
     * @brief 处理 Native 上报的事件 (策略联动)
     */
    void handleNativeEvent(std::shared_ptr<PolarisManagerEvent> event);

    void handleHostEvent(std::shared_ptr<PolarisManagerEvent> event);

    std::thread mLoopThread;
    std::atomic<bool> mRunning{false};
};

} // namespace polaris
} // namespace voyah