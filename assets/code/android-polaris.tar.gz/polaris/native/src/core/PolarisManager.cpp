#include "core/PolarisManager.h"
#include "core/EventQueue.h"
#include "infrastructure/CommandExecutor.h" 
#include "message/AppMessageHandler.h"
#include <android-base/logging.h>
#include <unistd.h>

namespace voyah {
namespace polaris {

PolarisManager::~PolarisManager() {
    stop();
}

PolarisManager* PolarisManager::getInstance() {
    static PolarisManager instance;
    return &instance;
}

void PolarisManager::start() {
    // 使用 exchange 防止多线程并发调用 start 导致重复启动
    bool expected = false;
    if (!mRunning.compare_exchange_strong(expected, true)) {
        LOG(WARNING) << "PolarisManager is already running.";
        return;
    }
    
    LOG(INFO) << "PolarisManager: Starting main loop...";
    mLoopThread = std::thread(&PolarisManager::runLoop, this);
}

void PolarisManager::stop() {
    // 1. 原子操作检查状态，防止重复 stop
    bool expected = true;
    if (!mRunning.compare_exchange_strong(expected, false)) {
        return;
    }

    LOG(INFO) << "PolarisManager: Stopping...";

    // 2. [关键修复] 发送 "毒丸" (Exit Event) 唤醒阻塞的消费者线程
    auto exitEvent = std::make_shared<PolarisManagerEvent>();
    exitEvent->type = PolarisManagerEvent::TYPE_SYSTEM_EXIT;
    
    // 必须推送到队列，否则 runLoop 里的 pop() 永远不会返回
    EventQueue::getInstance()->push(exitEvent);
}

void PolarisManager::join() {
    if (mLoopThread.joinable()) {
        mLoopThread.join();
        LOG(INFO) << "PolarisManager: Thread joined.";
    }
}

void PolarisManager::runLoop() {
    pthread_setname_np(pthread_self(), "PolarisCore");

    while (true) {
        // 1. 阻塞等待
        auto event = EventQueue::getInstance()->pop();

        // 鲁棒性检查
        if (!event) {
            if (!mRunning) break; // 如果已停止且取到空，退出
            continue;
        }

        // 2. [关键修复] 检测退出信号
        // 即使 mRunning 为 true，如果收到 EXIT 事件也必须退出
        // 这确保了队列中剩余的事件处理策略（当前策略：立即退出，丢弃剩余事件）
        if (event->type == PolarisManagerEvent::TYPE_SYSTEM_EXIT) {
            LOG(INFO) << "PolarisManager: Received EXIT signal. Breaking loop.";
            break;
        }

        // 3. 处理业务事件
        processEvent(event);
        
        // 双重检查：如果处理过程中被 stop，尽早退出
        if (!mRunning) break; 
    }
    
    mRunning = false;
    LOG(INFO) << "PolarisManager: Main loop exited.";
}

void PolarisManager::processEvent(std::shared_ptr<PolarisManagerEvent> event) {
    switch (event->type) {
        case PolarisManagerEvent::TYPE_APP_CMD_REQ:
            handleAppCmdReq(event);
            break;

        case PolarisManagerEvent::TYPE_CMD_EXEC_RESULT:
            handleCmdResult(event);
            break;

        case PolarisManagerEvent::TYPE_NATIVE_EVENT:
            handleNativeEvent(event);
            break;

        case PolarisManagerEvent::TYPE_HOST_EVENT:
            handleHostEvent(event);
            break;

        case PolarisManagerEvent::TYPE_HOST_CMD_REQ:
            LOG(INFO) << "PolarisManager: Received HOST CMD (Not implemented yet)";
            break;
        
        case PolarisManagerEvent::TYPE_SYSTEM_EXIT:
            // 理论上 runLoop 已经处理了，这里作为防御
            LOG(INFO) << "PolarisManager: Process event received EXIT signal";
            break;

        default:
            LOG(WARNING) << "PolarisManager: Unknown event type " << (int)event->type;
            break;
    }
}

void PolarisManager::handleAppCmdReq(std::shared_ptr<PolarisManagerEvent> event) {
    if (!event->cmdData) return;
    auto req = event->cmdData;
    LOG(INFO) << "PolarisManager: Handling App CMD [" << req->action 
              << "]";
    // 转发给 Executor
    CommandExecutor::getInstance()->execute(event->cmdData, event->responder); 
    // 注意：CommandExecutor::execute 的第二个参数现在接受 weak_ptr，
    // 你需要确保 CommandExecutor 的头文件里 execute 签名也是 weak_ptr
}

void PolarisManager::handleCmdResult(std::shared_ptr<PolarisManagerEvent> event) {
    if (!event->resultData) {
        LOG(ERROR) << "PolarisManager: CMD_RESULT payload is null";
        return;
    }

    // [修改]: 提升 weak_ptr 为 shared_ptr
    // 这是一个原子操作，线程安全。
    auto strongResponder = event->responder.lock();

    if (strongResponder) {
        // 提升成功：说明 AppSession 依然存活，连接正常
        strongResponder->sendResult(event->resultData);
    } else {
        // 提升失败：说明 AppSession 已经被销毁了
        // 此时我们直接丢弃结果，不进行任何 Socket 操作，非常干净。
        LOG(WARNING) << "PolarisManager: Client disconnected. Dropping result for ReqID: " 
                     << event->resultData->reqId;
    }
}

void PolarisManager::handleNativeEvent(std::shared_ptr<PolarisManagerEvent> event) {
    if (!event->eventData) return;

    auto& data = event->eventData;
    LOG(INFO) << "PolarisManager: Native Event [" << data->eventId 
              << "] from " << data->processName;

    // 广播给 App
    AppMessageHandler::broadcastEvent(data);

    // 策略联动示例
    if (data->eventId == 9001) {
        LOG(INFO) << ">> POLICY: Triggering Logcat Capture for Crash...";
        // CommandExecutor::getInstance()->execute(...);
    }
}

void PolarisManager::handleHostEvent(std::shared_ptr<PolarisManagerEvent> event) {
    if (!event->eventData) return;

    auto& data = event->eventData;
    LOG(INFO) << "PolarisManager: Host Event [" << data->eventId 
              << "] from " << data->processName;

    // 1. Broadcast to Android Apps (via AppMessageHandler)
    // This allows Android apps to subscribe to Host events seamlessly
    AppMessageHandler::broadcastEvent(data);

    // 2. (Optional) Policy Linkage
    // Example: If Host reports "System Overheat" (ID 1001), Android might show a dialog
    if (data->eventId == 1001) {
        LOG(INFO) << ">> POLICY: Host Overheat! Warning user...";
    }
}

} // namespace polaris
} // namespace voyah