#pragma once

#include "polarisd/PolarisManagerEvent.h"

#include <deque>
#include <memory>
#include <mutex>
#include <condition_variable>

namespace voyah {
namespace polaris {

/**
 * @brief 系统核心事件队列 (Thread-Safe Blocking Queue)
 * * 量产级特性：
 * 1. 线程安全
 * 2. 阻塞读取
 * 3. [新增] 容量限制 (Ring Buffer 策略，防止 OOM)
 */
class EventQueue {
public:
    EventQueue(const EventQueue&) = delete;
    EventQueue& operator=(const EventQueue&) = delete;

    static EventQueue* getInstance();

    /**
     * @brief 推送事件入队 (生产者)
     * * 策略：如果队列已满，将丢弃最旧的事件 (Drop Oldest)
     * 这样能保证系统总是处理最新的状态，且不会内存溢出。
     */
    void push(std::shared_ptr<PolarisManagerEvent> event);

    /**
     * @brief 阻塞获取事件 (消费者)
     */
    std::shared_ptr<PolarisManagerEvent> pop();

    /**
     * @brief 清空队列
     */
    void clear();

    size_t size();

private:
    EventQueue() = default;
    ~EventQueue() = default;

    // 限制最大积压 2000 条事件
    // 假设每条事件 1KB，最大占用约 2MB 内存，非常安全
    static constexpr size_t MAX_QUEUE_SIZE = 2000;

    std::deque<std::shared_ptr<PolarisManagerEvent>> mQueue;
    std::mutex mMutex;
    std::condition_variable mCv;
};

} // namespace polaris
} // namespace voyah