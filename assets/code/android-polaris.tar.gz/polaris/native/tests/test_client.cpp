#include <iostream>
#include <thread>
#include <chrono>
#include <string>
#include <vector>
#include <atomic>

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <cerrno>

#include <android-base/logging.h>

// 引入项目中的头文件
#include "polarisd/PolarisEvent.h"
#include "protocol/LspCodec.h"

using namespace voyah::polaris;

// 定义目标 Socket 路径 (与 .rc 文件和 NativeTransport 一致)
static const char* REPORT_SOCKET_PATH = "/dev/socket/polaris_report";

int main(int argc, char** argv) {
    // 初始化日志
    android::base::InitLogging(argv, android::base::LogdLogger(android::base::SYSTEM));

    LOG(INFO) << "Starting polaris test_client...";

    // 1. 创建 DGRAM Socket (无连接)
    int sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        PLOG(ERROR) << "Failed to create socket";
        return -1;
    }

    // 2. 设置目标地址
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, REPORT_SOCKET_PATH, sizeof(addr.sun_path) - 1);

    long seq = 0;

    while (true) {
        seq++;

        // 3. 构造 PolarisEvent
        PolarisEvent event;
        event.eventId = 10000 + seq; // 模拟 ID
        event.timestamp = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()) * 1000;
        event.pid = getpid();
        event.processName = "test_client";
        event.processVer = "1.0.0";
        event.logf = "/data/local/tmp/dummy.log";
        
        // 构造 JSON params
        event.params = "{\"cpu_usage\": 15, \"status\": \"testing\", \"seq\": " + std::to_string(seq) + "}";

        // 4. 编码 (使用 LspCodec)
        std::vector<uint8_t> data = LspCodec::encodeEvent(event);

        // 5. 发送
        ssize_t sent = sendto(sockfd, data.data(), data.size(), 0, 
                              (struct sockaddr*)&addr, sizeof(addr));

        if (sent < 0) {
            PLOG(ERROR) << "Failed to send event " << seq;
        } else {
            LOG(INFO) << "Sent Event[" << seq << "] size=" << sent 
                      << " to " << REPORT_SOCKET_PATH;
        }

        // 6. 休眠 1 秒
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    close(sockfd);
    return 0;
}