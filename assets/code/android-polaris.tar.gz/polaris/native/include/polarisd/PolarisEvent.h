#pragma once
#include <string>
#include <cstdint>
#include <vector>

namespace voyah {
namespace polaris {


/**
 * @brief Standard Data Contract for Events (Section 2.1)
 */
struct PolarisEvent {
    uint64_t eventId;
    uint64_t timestamp;
    int32_t pid;
    std::string processName;
    std::string processVer;
    std::string params; // JSON string
    std::string logf;   // Attachment path

    PolarisEvent() : eventId(0), timestamp(0), pid(0) {}
};

} // namespace polaris
} // namespace voyah
