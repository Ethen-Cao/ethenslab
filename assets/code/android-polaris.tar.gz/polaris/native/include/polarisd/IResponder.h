#pragma once
#include <memory>
#include "polarisd/CommandResult.h"

namespace voyah {
namespace polaris {


/**
 * @brief Interface for response callbacks (Section 6.2)
 * Allows Context Pass-through in the ManagerEvent
 */
struct IResponder {
    virtual ~IResponder() = default;
    virtual void sendResult(std::shared_ptr<CommandResult> result) = 0;
};

} // namespace polaris
} // namespace voyah
