#pragma once
#include <string>
#include <cstdint>

namespace voyah {
namespace polaris {


/**
 * @brief Standard Data Contract for Command Results (Section 2.3)
 */
struct CommandResult {
    uint32_t reqId;
    int32_t code;     // 0 = Success
    std::string msg;
    std::string data; // JSON string payload

    static CommandResult makeSuccess(uint32_t id, const std::string& data = "{}") {
        return {id, 0, "success", data};
    }

    static CommandResult makeError(uint32_t id, int32_t code, const std::string& msg) {
        return {id, code, msg, "{}"} ;
    }
};

} // namespace polaris
} // namespace voyah
