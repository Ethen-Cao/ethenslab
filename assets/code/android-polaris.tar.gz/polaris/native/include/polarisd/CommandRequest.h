#pragma once
#include <string>
#include <cstdint>

namespace voyah {
namespace polaris {


enum class CommandTarget {
    LOCAL = 0,
    HOST = 1
};

/**
 * @brief Standard Data Contract for Command Requests (Section 2.2)
 */
struct CommandRequest {
    uint32_t reqId;
    CommandTarget target;
    std::string action;
    std::string args; // JSON string
    uint32_t timeout; // ms
};

} // namespace polaris
} // namespace voyah
