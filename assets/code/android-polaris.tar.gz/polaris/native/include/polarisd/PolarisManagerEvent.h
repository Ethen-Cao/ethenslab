#pragma once
#include <memory>
#include "polarisd/PolarisEvent.h"
#include "polarisd/CommandRequest.h"
#include "polarisd/CommandResult.h"
#include "polarisd/IResponder.h"

namespace voyah {
namespace polaris {


/**
 * @brief Internal Bus Object (Section 6.1)
 */
struct PolarisManagerEvent {
    enum Type {
        TYPE_NATIVE_EVENT,      // Source: Native (LSP)
        TYPE_HOST_EVENT,        // Source: Host (PLP)
        TYPE_APP_CMD_REQ,       // Source: App (LSP Command)
        TYPE_HOST_CMD_REQ,      // Source: Host (PLP Command)
        TYPE_CMD_EXEC_RESULT,    // Source: Infrastructure
        // [新增] 系统退出信号 (用于唤醒阻塞队列)
        TYPE_SYSTEM_EXIT = 999
    };

    Type type;
    
    // Data Payloads
    std::shared_ptr<PolarisEvent> eventData;
    std::shared_ptr<CommandRequest> cmdData;
    std::shared_ptr<CommandResult> resultData;

    // Context for callback (Smart Pointer for lifecycle safety)
    std::weak_ptr<IResponder> responder;
};

} // namespace polaris
} // namespace voyah
