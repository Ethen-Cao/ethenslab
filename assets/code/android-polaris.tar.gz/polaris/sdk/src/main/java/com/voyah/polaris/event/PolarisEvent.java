package com.voyah.polaris.event;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Universal Event Container.
 * Represents struct PolarisEvent in Native C++.
 *
 * <p>This class implements Parcelable for IPC transfer via AIDL.
 * It also handles the conversion between Bundle (Java-friendly) and JSON String (Native-friendly).</p>
 */
public class PolarisEvent implements Parcelable {
    private static final String TAG = "PolarisEvent";

    // --- Fields (Must match Native struct definition) ---
    public long eventId;
    public long timestamp;
    public int pid;
    public String processName;
    public String processVer;   // [Added] Version info
    public String params;       // JSON String representation of parameters
    public String logf;         // [Fixed] Renamed from logFilePath to match Native struct

    // --- Constructors ---

    public PolarisEvent() {
        this.timestamp = System.currentTimeMillis();
        this.params = "{}";
        this.processVer = "";
        this.processName = "";
        this.logf = "";
    }

    public PolarisEvent(long eventId) {
        this();
        this.eventId = eventId;
    }

    /**
     * Recommended constructor for App/SDK usage.
     * Automatically captures timestamp and current PID.
     */
    public PolarisEvent(long eventId, String processName, String processVer) {
        this.eventId = eventId;
        this.processName = (processName != null) ? processName : "";
        this.processVer = (processVer != null) ? processVer : "";
        this.timestamp = System.currentTimeMillis();
        this.params = "{}";
        this.logf = "";
        // Auto-fill PID for convenience and tracing
        this.pid = Process.myPid();
    }

    // --- Parcelable Implementation ---

    protected PolarisEvent(Parcel in) {
        // [Critical] Reading order MUST match writing order
        eventId = in.readLong();
        timestamp = in.readLong();
        pid = in.readInt();
        processName = in.readString();
        processVer = in.readString(); // [Added]
        params = in.readString();
        logf = in.readString();       // [Fixed] field name
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        // [Critical] Writing order MUST match reading order
        dest.writeLong(eventId);
        dest.writeLong(timestamp);
        dest.writeInt(pid);
        dest.writeString(processName);
        dest.writeString(processVer); // [Added]
        dest.writeString(params);
        dest.writeString(logf);       // [Fixed] field name
    }

    public static final Creator<PolarisEvent> CREATOR = new Creator<PolarisEvent>() {
        @Override
        public PolarisEvent createFromParcel(Parcel in) {
            return new PolarisEvent(in);
        }

        @Override
        public PolarisEvent[] newArray(int size) {
            return new PolarisEvent[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    // --- Helper Methods: Bundle <-> JSON ---

    /**
     * Converts a Bundle into a JSON String for storage in 'params'.
     * Used by SDK clients to set event parameters.
     */
    public void setParams(Bundle bundle) {
        if (bundle == null) {
            this.params = "{}";
            return;
        }

        JSONObject json = new JSONObject();
        try {
            for (String key : bundle.keySet()) {
                Object value = bundle.get(key);
                if (value == null) continue;

                // JSON supports basic types. For complex objects, use toString() as fallback.
                if (value instanceof String || value instanceof Number || value instanceof Boolean) {
                    json.put(key, value);
                } else {
                    json.put(key, String.valueOf(value));
                }
            }
            this.params = json.toString();
        } catch (JSONException e) {
            Log.e(TAG, "Failed to convert Bundle to JSON", e);
            this.params = "{}";
        }
    }

    /**
     * Parses the JSON String in 'params' back into a Bundle.
     * Used by SDK clients to read event parameters.
     */
    public Bundle getParams() {
        Bundle bundle = new Bundle();
        if (TextUtils.isEmpty(params)) {
            return bundle;
        }

        try {
            JSONObject json = new JSONObject(params);
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (json.isNull(key)) continue;

                Object value = json.get(key);

                if (value instanceof String) {
                    bundle.putString(key, (String) value);
                } else if (value instanceof Integer) {
                    bundle.putInt(key, (Integer) value);
                } else if (value instanceof Long) {
                    bundle.putLong(key, (Long) value);
                } else if (value instanceof Double) {
                    bundle.putDouble(key, (Double) value);
                } else if (value instanceof Boolean) {
                    bundle.putBoolean(key, (Boolean) value);
                } else {
                    bundle.putString(key, value.toString());
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Failed to parse JSON to Bundle: " + params, e);
        }
        return bundle;
    }

    /**
     * [Factory Method] Parse JSON string from Native layer into PolarisEvent object.
     * Ensure Keys match C++ JsonUtils::toJson().
     */
    public static PolarisEvent fromJson(String jsonStr) {
        if (TextUtils.isEmpty(jsonStr)) {
            return null;
        }

        try {
            JSONObject obj = new JSONObject(jsonStr);
            PolarisEvent event = new PolarisEvent();

            // 1. 基础字段
            event.eventId = obj.optLong("eventId");
            event.timestamp = obj.optLong("timestamp");
            event.pid = obj.optInt("pid");
            
            // 2. 字符串字段 (处理 null)
            event.processName = obj.optString("processName", "");
            event.processVer = obj.optString("processVer", "");
            
            // 3. Params (Native 传来的可能是 JSON Object，optString 会自动转 string)
            event.params = obj.optString("params", "{}");

            // 4. [Critical] 对应 C++ 的 "logf"
            event.logf = obj.optString("logf", "");

            return event;
        } catch (JSONException e) {
            Log.e(TAG, "Failed to parse JSON to PolarisEvent: " + jsonStr, e);
            return null;
        }
    }

    @Override
    public String toString() {
        return "PolarisEvent{" +
                "id=" + eventId +
                ", time=" + timestamp +
                ", pid=" + pid +
                ", ver='" + processVer + '\'' +
                ", name='" + processName + '\'' +
                ", params='" + params + '\'' +
                ", logf='" + logf + '\'' +
                '}';
    }
}