package com.voyah.polaris.utils;

/**
 * [流控] 客户端限流器
 */
public final class RateLimiter {
    private final int maxPerWindow;
    private final long windowMs;
    private int count;
    private long windowStart;

    public RateLimiter(int maxPerWindow, long windowMs) {
        this.maxPerWindow = maxPerWindow;
        this.windowMs = windowMs;
        this.windowStart = System.currentTimeMillis();
    }

    public synchronized boolean tryAcquire() {
        long now = System.currentTimeMillis();
        if (now - windowStart >= windowMs) {
            windowStart = now;
            count = 0;
        }
        if (count >= maxPerWindow) return false;
        count++;
        return true;
    }
}

