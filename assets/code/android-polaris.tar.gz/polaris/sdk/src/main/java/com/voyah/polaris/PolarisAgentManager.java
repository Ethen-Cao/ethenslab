package com.voyah.polaris;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.voyah.polaris.event.PolarisEvent;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * PolarisAgentManager
 * <p>
 * The main entry point for Android Apps to interact with the Polaris System.
 * It manages the AIDL connection to the PolarisAgentService.
 */
public class PolarisAgentManager {
    private static final String TAG = "PolarisAgentManager";

    // Service Action & Package (Need to match AndroidManifest.xml of PolarisApp)
    private static final String SERVICE_ACTION = "com.voyah.polaris.agent.BIND";
    private static final String SERVICE_PACKAGE = "com.voyah.polaris.agent";

    private static volatile PolarisAgentManager sInstance;

    private Context mContext;
    private IPolarisAgentService mService;
    private final AtomicBoolean mIsBound = new AtomicBoolean(false);

    private PolarisAgentManager() {
        // Private constructor
    }

    /**
     * Get the singleton instance.
     */
    public static PolarisAgentManager getInstance() {
        if (sInstance == null) {
            synchronized (PolarisAgentManager.class) {
                if (sInstance == null) {
                    sInstance = new PolarisAgentManager();
                }
            }
        }
        return sInstance;
    }

    /**
     * Initialize the manager and bind to the service.
     * Should be called in Application.onCreate().
     *
     * @param context Context (will be converted to ApplicationContext)
     */
    public void init(Context context) {
        if (mIsBound.get()) {
            Log.w(TAG, "Already initialized/bound.");
            return;
        }

        if (context == null) {
            Log.e(TAG, "Context cannot be null.");
            return;
        }

        // Prevent memory leaks by holding Application Context
        mContext = context.getApplicationContext();
        bindService();
    }

    /**
     * Report an event to the Polaris system.
     *
     * @param event The event to report.
     */
    public void reportEvent(PolarisEvent event) {
        if (event == null) {
            Log.e(TAG, "Cannot report null event.");
            return;
        }

        IPolarisAgentService service = getService();
        if (service == null) {
            Log.w(TAG, "Service not connected. Event dropped: " + event.eventId);
            // Optional: Implement a retry buffer here if strict delivery is required.
            // For now, try to re-bind for future events.
            bindService();
            return;
        }

        try {
            service.reportEvent(event);
            Log.d(TAG, "Reported event: " + event.eventId);
        } catch (RemoteException e) {
            Log.e(TAG, "RemoteException reporting event: " + event.eventId, e);
        }
    }

    /**
     * Release resources and unbind service.
     */
    public void release() {
        if (mIsBound.compareAndSet(true, false)) {
            if (mContext != null) {
                try {
                    mContext.unbindService(mConnection);
                } catch (Exception e) {
                    Log.w(TAG, "Error unbinding service: " + e.getMessage());
                }
            }
            mService = null;
        }
    }

    // --- Internal Helpers ---

    private synchronized void bindService() {
        if (mContext == null) return;

        // Double check if already connected
        if (mService != null && mService.asBinder().isBinderAlive()) {
            return;
        }

        Intent intent = new Intent(SERVICE_ACTION);
        intent.setPackage(SERVICE_PACKAGE);

        try {
            boolean result = mContext.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
            if (!result) {
                Log.e(TAG, "Bind service failed. Package: " + SERVICE_PACKAGE);
                mIsBound.set(false);
            } else {
                mIsBound.set(true);
            }
        } catch (Exception e) {
            Log.e(TAG, "Exception binding service", e);
            mIsBound.set(false);
        }
    }

    private synchronized IPolarisAgentService getService() {
        return mService;
    }

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i(TAG, "Connected to PolarisAgentService");
            synchronized (PolarisAgentManager.this) {
                mService = IPolarisAgentService.Stub.asInterface(service);
                
                // Set Death Recipient to handle service crash
                try {
                    mService.asBinder().linkToDeath(mDeathRecipient, 0);
                } catch (RemoteException e) {
                    Log.e(TAG, "Failed to link to death", e);
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.w(TAG, "Disconnected from PolarisAgentService (Unexpectedly)");
            synchronized (PolarisAgentManager.this) {
                mService = null;
            }
            // Note: Android system will automatically try to reconnect, 
            // so we don't necessarily need to call bindService() here manually.
        }
        
        @Override
        public void onBindingDied(ComponentName name) {
             Log.e(TAG, "Binding died.");
             synchronized (PolarisAgentManager.this) {
                mService = null;
            }
            // Trigger re-bind manually
            bindService();
        }
    };

    private final IBinder.DeathRecipient mDeathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            Log.w(TAG, "Binder Died! Service crashed?");
            synchronized (PolarisAgentManager.this) {
                if (mService != null) {
                    mService.asBinder().unlinkToDeath(this, 0);
                    mService = null;
                }
            }
            // Try to reconnect immediately
            bindService();
        }
    };
}