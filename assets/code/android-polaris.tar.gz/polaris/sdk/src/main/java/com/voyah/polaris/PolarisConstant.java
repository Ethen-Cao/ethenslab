package com.voyah.polaris;

/**
 * [常量] 通用配置 (如 Service Package Name)
 */
public final class PolarisConstant {
    public static final String SERVICE_PACKAGE = "com.voyah.polaris.agent";

    private PolarisConstant() {}
}

