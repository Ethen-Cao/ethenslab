package com.voyah.polaris.agent.db;

public class EventDao {
    // TODO
}

