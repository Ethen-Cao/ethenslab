package com.voyah.polaris.agent.core.protocol;

import android.util.Log;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class LspDecoder {
    private static final String TAG = "LspDecoder";
    private ByteBuffer mBuffer;

    public LspDecoder() {
        // 分配 4MB 缓冲区，使用 Little Endian (与 C++ Host 一致)
        mBuffer = ByteBuffer.allocate(LspConstants.MAX_PACKET_SIZE);
        mBuffer.order(ByteOrder.LITTLE_ENDIAN);
    }

    /**
     * 将新收到的数据写入缓冲区，并尝试解析出完整的数据包
     * @param data 新收到的字节数组
     * @param length 有效长度
     * @param callback 解析成功的回调
     */
    public void decode(byte[] data, int length, Callback callback) {
        if (mBuffer.remaining() < length) {
            Log.e(TAG, "Buffer overflow! Clearing buffer.");
            mBuffer.clear();
        }
        
        mBuffer.put(data, 0, length);
        mBuffer.flip(); // 切换为读模式

        while (mBuffer.remaining() >= LspConstants.HEADER_LEN) {
            mBuffer.mark(); // 标记当前位置

            // 1. 读取头部 (参考 C++ LspCodec::Header)
            int totalLen = mBuffer.getInt();      // 0-3: totalLen
            short msgType = mBuffer.getShort();   // 4-5: msgType
            short reserved = mBuffer.getShort();  // 6-7: reserved
            int reqId = mBuffer.getInt();         // 8-11: reqId

            // 2. 校验长度合法性
            if (totalLen < LspConstants.HEADER_LEN || totalLen > LspConstants.MAX_PACKET_SIZE) {
                Log.e(TAG, "Invalid totalLen: " + totalLen + ", dropping buffer.");
                mBuffer.clear(); // 丢弃所有数据，重新同步
                return;
            }

            // 3. 检查是否半包 (剩余数据不足以构成一个包)
            if (mBuffer.remaining() + LspConstants.HEADER_LEN /*因为刚读了12字节*/ < totalLen) { // wait for more data
                mBuffer.reset(); // 回退到 mark 的位置 (Header 开始处)
                mBuffer.compact(); // 切换回写模式，保留未读数据
                return; 
            }

            // 4. 读取 Payload
            int payloadLen = totalLen - LspConstants.HEADER_LEN;
            String payloadJson = "";
            if (payloadLen > 0) {
                byte[] payloadBytes = new byte[payloadLen];
                mBuffer.get(payloadBytes);
                payloadJson = new String(payloadBytes, StandardCharsets.UTF_8);
            }

            // 5. 回调上层
            callback.onPacketDecoded(msgType, reqId, payloadJson);
        }

        mBuffer.compact(); // 处理完所有完整包后，整理缓冲区，切换为写模式
    }

    public interface Callback {
        void onPacketDecoded(int msgType, int reqId, String payloadJson);
    }
}