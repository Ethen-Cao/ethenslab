package com.voyah.polaris.agent.core.transport;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.util.Log;

import com.voyah.polaris.agent.core.protocol.CommandResult;
import com.voyah.polaris.agent.core.protocol.LspConstants;
import com.voyah.polaris.agent.core.protocol.LspDecoder;
import com.voyah.polaris.event.PolarisEvent;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 核心传输层 (Dumb Pipe)
 * 职责：
 * 1. 维护 Unix Domain Socket 连接 (SOCKET_SEQPACKET)
 * 2. 负责字节流的 Read/Write
 * 3. 使用 LspDecoder 处理粘包
 * 4. 将解析后的 Payload 分发给对应的 Listener (Event 或 Response)
 * * 注意：本类不包含任何业务逻辑 (如 Ping/Pong 或 ReqId 生成)，只负责搬运数据。
 */
public class CoreTransport {
    private static final String TAG = "CoreTransport";
    private static final String SOCKET_NAME = "polaris_bridge"; // 必须与 .rc 文件一致

    private LocalSocket mSocket;
    private InputStream mInputStream;
    private OutputStream mOutputStream;
    
    private final AtomicBoolean mRunning = new AtomicBoolean(false);
    
    // 专门用于发送数据的单线程池 (串行化发送，避免并发写 Socket 导致错乱)
    private final ExecutorService mWriteExecutor = Executors.newSingleThreadExecutor();
    
    // 专门用于读取/连接的独立线程
    private Thread mReadThread;
    
    private final LspDecoder mDecoder = new LspDecoder();
    
    // 监听器
    private EventListener mEventListener;
    private ResponseListener mResponseListener;
    private ConnectionListener mConnectionListener;

    private static volatile CoreTransport sInstance;

    // ----------------------------------------------------
    // Interfaces
    // ----------------------------------------------------

    // 监听 Native 主动上报的事件
    public interface EventListener {
        void onEvent(PolarisEvent event);
    }

    // 监听 Native 对命令的回复
    public interface ResponseListener {
        void onResponse(CommandResult result);
    }

    // ----------------------------------------------------
    // Public API
    // ----------------------------------------------------

    public static CoreTransport getInstance() {
        if (sInstance == null) {
            synchronized (CoreTransport.class) {
                if (sInstance == null) {
                    sInstance = new CoreTransport();
                }
            }
        }
        return sInstance;
    }

    public void setConnectionListener(ConnectionListener listener) {
        this.mConnectionListener = listener;
    }

    public void setEventListener(EventListener listener) {
        this.mEventListener = listener;
    }

    public void setResponseListener(ResponseListener listener) {
        this.mResponseListener = listener;
    }

    public void start() {
        if (mRunning.get()) return;
        mRunning.set(true);

        mReadThread = new Thread(this::connectionLoop);
        mReadThread.setName("Polaris-CoreTransport-Read");
        mReadThread.start();
    }

    public void stop() {
        mRunning.set(false);
        closeSocket();
        // 注意：mWriteExecutor 通常跟随应用生命周期，不建议频繁 shutdown/restart
    }

    /**
     * [核心变更] 发送原始字节包
     * @param packetData 已经打包好的二进制数据 (Header + Payload)
     * @return true 表示已提交发送任务 (连接正常)，false 表示未连接
     */
    public boolean sendRaw(byte[] packetData) {
        if (!mRunning.get() || mOutputStream == null) {
            Log.e(TAG, "sendRaw failed: Socket not connected");
            return false;
        }

        mWriteExecutor.execute(() -> {
            synchronized (this) { // 简单保护，虽然 WriteExecutor 已经是单线程
                if (mOutputStream == null) return;
                try {
                    mOutputStream.write(packetData);
                    mOutputStream.flush();
                } catch (IOException e) {
                    Log.e(TAG, "Write to socket failed", e);
                    // 写入失败通常意味着连接断开，ReadLoop 会感知并触发重连
                    closeSocket(); 
                }
            }
        });
        return true;
    }

    // ----------------------------------------------------
    // Connection & Read Loop
    // ----------------------------------------------------

    private void connectionLoop() {
        while (mRunning.get()) {
            try {
                connect();
                
                if (mConnectionListener != null) {
                    mConnectionListener.onConnected();
                }

                // 阻塞读取 (直到断开)
                readLoop();

            } catch (Exception e) {
                Log.e(TAG, "Connection loop error: " + e.getMessage());
            } finally {
                if (mSocket != null && mConnectionListener != null) {
                    mConnectionListener.onDisconnected();
                }
                closeSocket();
            }

            if (mRunning.get()) {
                Log.i(TAG, "Retrying connection in 5s...");
                try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
            }
        }
    }

    private void connect() throws IOException {
        Log.i(TAG, "Connecting to socket: " + SOCKET_NAME);
        mSocket = new LocalSocket(LocalSocket.SOCKET_SEQPACKET);
        mSocket.connect(new LocalSocketAddress(SOCKET_NAME, LocalSocketAddress.Namespace.RESERVED));
        mInputStream = mSocket.getInputStream();
        mOutputStream = mSocket.getOutputStream();
        Log.i(TAG, "Connected to polarisd.");
    }

    private void readLoop() throws IOException {
        byte[] buffer = new byte[8192];
        int len;
        while (mRunning.get() && (len = mInputStream.read(buffer)) != -1) {
            // LspDecoder 负责处理粘包/半包，解析出完整的一帧后回调 dispatchMessage
            mDecoder.decode(buffer, len, this::dispatchMessage);
        }
    }

    private void closeSocket() {
        try {
            if (mSocket != null) {
                mSocket.close();
                mSocket = null;
            }
            if (mInputStream != null) mInputStream.close();
            if (mOutputStream != null) mOutputStream.close();
        } catch (IOException e) { /* ignore */ }
    }

    // ----------------------------------------------------
    // Dispatch Logic
    // ----------------------------------------------------

    /**
     * 将解码后的消息分发给对应的监听器
     */
    private void dispatchMessage(int msgType, int reqId, String payloadJson) {
        try {
            switch (msgType) {
                // ----------------------------------------------------
                // 场景 A: 收到 Native 主动上报的事件
                // ----------------------------------------------------
                case LspConstants.MSG_TYPE_EVENT_REPORT:
                    PolarisEvent event = PolarisEvent.fromJson(payloadJson);
        
                    if (event != null) {
                        if (mEventListener != null) {
                            mEventListener.onEvent(event);
                        } else {
                            Log.w(TAG, "No EventListener registered, dropping event: " + event.toString());
                        }
                    } else {
                        Log.e(TAG, "Dropped invalid JSON event");
                    }
                    break;

                // ----------------------------------------------------
                // 场景 B: 收到 Native 对命令的回复
                // ----------------------------------------------------
                case LspConstants.MSG_TYPE_CMD_RESP:
                    if (mResponseListener != null) {
                        // 使用标准数据结构解析
                        CommandResult result = CommandResult.fromJson(payloadJson);
                        
                        // 健壮性修正：如果 JSON 解析失败，result.reqId 可能无效
                        // 强制使用 Header 中的 reqId (这是最可信的)
                        if (result.reqId != reqId) {
                            // 这种情况理论上不应发生，除非 Payload 损坏
                            // 我们重新构造一个 Result 确保上层能匹配到 ReqID
                            result = new CommandResult(reqId, result.code, result.msg, result.data);
                        }

                        mResponseListener.onResponse(result);
                    }
                    break;
                
                default:
                    Log.w(TAG, "Unknown msgType: " + msgType);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to dispatch message type=" + msgType, e);
        }
    }
}