package com.voyah.polaris.agent.core.command;

import android.util.Log;

import com.voyah.polaris.agent.core.protocol.CommandResult;
import com.voyah.polaris.agent.core.protocol.LspConstants;
import com.voyah.polaris.agent.core.transport.CoreTransport;

import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 核心命令管理器
 * 职责：
 * 1. 生成全局唯一的 ReqID
 * 2. 封装协议包 (Header + JSON Body)
 * 3. 维护 PendingRequest 队列 (处理超时)
 * 4. 提供 Sync/Async 统一接口
 */
public class CommandManager implements CoreTransport.ResponseListener {
    private static final String TAG = "CommandManager";
    private static volatile CommandManager sInstance;

    // 默认超时时间 (5秒)
    private static final long DEFAULT_TIMEOUT_MS = 5000;

    // 1. 请求ID生成器 (线程安全)
    private final AtomicInteger mReqIdGen = new AtomicInteger(1);

    // 2. 挂起请求队列 <ReqId, Future>
    // 使用 CompletableFuture 既可以做 Callback 也可以做 Sync Blocking
    private final Map<Integer, CompletableFuture<CommandResult>> mPendingMap = new ConcurrentHashMap<>();

    // 3. 超时调度器 (比 Handler 更适合后台线程，且不依赖 Looper)
    private final ScheduledExecutorService mTimeoutScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "Polaris-CmdTimeout");
        t.setDaemon(true);
        return t;
    });

    // 单例模式
    public static CommandManager getInstance() {
        if (sInstance == null) {
            synchronized (CommandManager.class) {
                if (sInstance == null) {
                    sInstance = new CommandManager();
                }
            }
        }
        return sInstance;
    }

    private CommandManager() {
        // 注册自己监听 CoreTransport 的回包
        CoreTransport.getInstance().setResponseListener(this);
    }

    /**
     * [异步接口] 发送命令
     * @param action 动作 (e.g. "ping")
     * @param args 参数 (JSON String, 可选)
     * @return Future 对象，调用者通过 .thenAccept() 处理结果
     */
    public CompletableFuture<CommandResult> sendAsync(String action, String args) {
        return sendAsync(action, args, DEFAULT_TIMEOUT_MS);
    }

    /**
     * [异步接口] 发送命令 (带自定义超时)
     */
    public CompletableFuture<CommandResult> sendAsync(String action, String args, long timeoutMs) {
        // 1. 生成 ID
        final int reqId = mReqIdGen.getAndIncrement();
        
        // 2. 创建 Future
        CompletableFuture<CommandResult> future = new CompletableFuture<>();

        // 3. 放入 Pending 队列
        mPendingMap.put(reqId, future);

        // 4. 启动超时看门狗
        // 如果 timeoutMs 时间到了 future 还没结束，强制抛出异常并清理 Map
        ScheduledFuture<?> timeoutTask = mTimeoutScheduler.schedule(() -> {
            CompletableFuture<CommandResult> pending = mPendingMap.remove(reqId);
            if (pending != null) {
                Log.w(TAG, "Command Timeout: action=" + action + ", id=" + reqId);
                pending.completeExceptionally(new TimeoutException("Request timed out after " + timeoutMs + "ms"));
            }
        }, timeoutMs, TimeUnit.MILLISECONDS);

        // 5. 当 Future 完成时(无论成功失败)，取消超时任务，节省资源
        future.whenComplete((res, ex) -> {
            if (!timeoutTask.isDone()) {
                timeoutTask.cancel(false);
            }
        });

        // 6. 序列化并发送
        try {
            byte[] packet = packRequest(reqId, action, args);
            boolean sent = CoreTransport.getInstance().sendRaw(packet);
            
            if (!sent) {
                // 发送失败 (Socket 未连接等)，立即报错
                mPendingMap.remove(reqId);
                future.completeExceptionally(new IllegalStateException("Socket not connected or send failed"));
                timeoutTask.cancel(false); // 取消超时任务
            }
        } catch (Exception e) {
            mPendingMap.remove(reqId);
            future.completeExceptionally(e);
            timeoutTask.cancel(false);
        }

        return future;
    }

    /**
     * [同步接口] 阻塞等待结果
     * 注意：不要在主线程调用，否则会 ANR
     */
    public CommandResult sendSync(String action, String args) {
        try {
            // 复用 sendAsync 的逻辑，直接阻塞等待
            return sendAsync(action, args).get(DEFAULT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            return new CommandResult(-1, -1, "Timeout", "{}");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new CommandResult(-1, -1, "Interrupted", "{}");
        } catch (ExecutionException e) {
            return new CommandResult(-1, -1, "Execution Error: " + e.getCause().getMessage(), "{}");
        } catch (Exception e) {
            return new CommandResult(-1, -1, "Unknown Error: " + e.getMessage(), "{}");
        }
    }

    // ------------------------------------------------------------------------
    // 来自 CoreTransport 的回调 (在 CoreTransport 读取线程中被调用)
    // ------------------------------------------------------------------------
    @Override
    public void onResponse(CommandResult result) {
        // 1. 查表并移除 (Atomic 操作，确保不会被 Timeout 线程并发移除)
        CompletableFuture<CommandResult> future = mPendingMap.remove(result.reqId);

        if (future != null) {
            // 2. 唤醒等待者
            // Log.v(TAG, "Matching response found for id=" + result.reqId);
            future.complete(result);
        } else {
            // 3. 没找到 (可能是超时了已经被移除了，或者是 Native 发了重复包)
            Log.w(TAG, "Dropped orphan response: id=" + result.reqId + " (Likely timed out)");
        }
    }

    // ------------------------------------------------------------------------
    // 私有辅助方法：协议打包 (将 CoreTransport 的打包逻辑移到这里)
    // ------------------------------------------------------------------------
    private byte[] packRequest(int reqId, String action, String args) throws Exception {
        // 1. 构建 JSON Payload
        JSONObject root = new JSONObject();
        root.put("reqId", reqId);
        root.put("action", action);
        root.put("target", "LOCAL"); // 默认发给 Local Native
        if (args != null) {
            root.put("args", args);
        }
        
        byte[] payloadBytes = root.toString().getBytes(StandardCharsets.UTF_8);
        int payloadLen = payloadBytes.length;
        int totalLen = LspConstants.HEADER_LEN + payloadLen;

        // 2. 构建二进制包 (Little Endian)
        ByteBuffer buffer = ByteBuffer.allocate(totalLen);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // Header (12 bytes)
        buffer.putInt(totalLen);                       // 0-3: Total Len
        buffer.putShort((short) LspConstants.MSG_TYPE_CMD_REQ); // 4-5: Type
        buffer.putShort((short) 0);                    // 6-7: Reserved
        buffer.putInt(reqId);                          // 8-11: ReqID
        
        // Body
        buffer.put(payloadBytes);                      // 12+: JSON

        return buffer.array();
    }
}