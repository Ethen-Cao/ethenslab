package com.voyah.polaris.agent;

import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * App 生命周期管理
 * 职责：
 * 1. 作为 App 进程的入口。
 * 2. 负责拉起核心驻留服务 (PolarisAgentService)。
 */
public class PolarisAgentApplication extends Application {
    
    private static final String TAG = "PolarisAgentApp";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "PolarisAgentApplication created. Process ID: " + android.os.Process.myPid());

        // 启动核心服务
        startCoreService();
    }

    private void startCoreService() {
        try {
            Intent intent = new Intent(this, PolarisAgentService.class);
            startService(intent);
            Log.i(TAG, "Started PolarisAgentService.");
        } catch (Exception e) {
            // 捕获 IllegalStateException (如：App 在后台时不允许启动 Service)
            Log.e(TAG, "Failed to start PolarisAgentService", e);
        }
    }
}