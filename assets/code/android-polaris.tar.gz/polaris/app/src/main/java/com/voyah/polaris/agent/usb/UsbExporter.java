package com.voyah.polaris.agent.usb;

public class UsbExporter {
    public void start() {
        // TODO: listen mount broadcast and dump DB
    }
}

