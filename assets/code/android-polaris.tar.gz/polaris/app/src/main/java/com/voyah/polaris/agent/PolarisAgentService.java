package com.voyah.polaris.agent;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

// 1. 引入 SDK 中的 AIDL 和数据实体
import com.voyah.polaris.IPolarisAgentService;
import com.voyah.polaris.event.PolarisEvent;

// 2. 引入 Core 模块
import com.voyah.polaris.agent.core.transport.CoreTransport;
import com.voyah.polaris.agent.core.transport.ConnectionListener;
import com.voyah.polaris.agent.core.command.CommandManager; // [新增]
import com.voyah.polaris.agent.core.protocol.CommandResult; // [新增]

/**
 * [Service] Polaris 核心服务
 */
public class PolarisAgentService extends Service {

    private static final String TAG = "PolarisAgentService";

    // --- 1. AIDL Stub 实现 (Binder 实体) ---
    private final IPolarisAgentService.Stub mBinder = new IPolarisAgentService.Stub() {
        @Override
        public void reportEvent(PolarisEvent event) throws RemoteException {
            if (event == null) {
                Log.w(TAG, "Received null event via AIDL, ignoring.");
                return;
            }
            Log.d(TAG, "Received AIDL Event: " + event.toString());
            // TODO: EventProcessor.getInstance().process(event);
        }
    };

    // --- 2. 生命周期管理 ---

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "PolarisAgentService creating...");

        try {
            initModules();
        } catch (Exception e) {
            Log.e(TAG, "FATAL: Failed to initialize modules", e);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand flags=" + flags + " startId=" + startId);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "Client binding to PolarisAgentService");
        return mBinder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "PolarisAgentService destroying...");
        CoreTransport.getInstance().stop();
    }

    // --- 3. 模块初始化 ---

    private void initModules() {
        // 1. 初始化 Native 通信模块
        Log.i(TAG, "Initializing CoreTransport...");
        CoreTransport transport = CoreTransport.getInstance();
        
        // 显式初始化 CommandManager (虽然它是懒加载单例，但这里调用一下确保 ResponseListener 注册成功)
        CommandManager.getInstance();

        // 设置连接状态监听
        transport.setConnectionListener(new ConnectionListener() {
            @Override
            public void onConnected() {
                Log.i(TAG, ">>> Linked to polarisd (Native Daemon) <<<");
                
                // [测试代码入口]: 只有连接成功了，才能发 Ping
                testPingCommand();
            }

            @Override
            public void onDisconnected() {
                Log.w(TAG, ">>> Lost connection to polarisd <<<");
            }
        });

        // 注册 EventListener (负责接收 Native Event)
        transport.setEventListener(new CoreTransport.EventListener() {
            @Override
            public void onEvent(PolarisEvent event) {
                // 收到 Native 事件！
                Log.i(TAG, "RECEIVED EVENT: "+event.toString());
            }
        });

        // 启动连接线程 (异步)
        transport.start();

        Log.i(TAG, "All modules initialized successfully.");
    }

    /**
     * [测试方法] 发送异步 Ping 并打印结果
     */
    private void testPingCommand() {
        Log.i(TAG, "Starting Async PING test...");

        // 调用 CommandManager 发送命令
        // action: "ping", args: null
        CommandManager.getInstance().sendAsync("ping", null)
            .thenAccept(result -> {
                // [成功收到回包]
                // 注意：此回调运行在 CoreTransport 的 Read 线程中
                if (result.isSuccess()) {
                    Log.i(TAG, ">>> PONG Received! <<<");
                    Log.i(TAG, "    ReqId: " + result.reqId);
                    Log.i(TAG, "    Data : " + result.data); // 期望是 "pong" 或 JSON
                } else {
                    Log.e(TAG, ">>> PING Failed (Logic Error) <<<");
                    Log.e(TAG, "    Code : " + result.code);
                    Log.e(TAG, "    Msg  : " + result.msg);
                }
            })
            .exceptionally(ex -> {
                // [发生异常] (超时 或 Socket断开)
                Log.e(TAG, ">>> PING Exception (Timeout or Network Error) <<<", ex);
                return null;
            });
    }
}