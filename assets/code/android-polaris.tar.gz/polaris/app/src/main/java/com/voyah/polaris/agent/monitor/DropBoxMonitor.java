package com.voyah.polaris.agent.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.DropBoxManager;

import com.voyah.polaris.event.EventID;

public class DropBoxMonitor extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (DropBoxManager.ACTION_DROPBOX_ENTRY_ADDED.equals(intent.getAction())) {
            String tag = intent.getStringExtra(DropBoxManager.EXTRA_TAG);
            long time = intent.getLongExtra(DropBoxManager.EXTRA_TIME, 0);
        }
    }

    private long mapTagToId(String tag) {
        if ("system_server_anr".equals(tag)) return EventID.GVM_SYS_FW_ANR;
        if ("system_server_crash".equals(tag)) return EventID.GVM_SYS_FW_CRASH;
        // ...
        return -1;
    }
}

