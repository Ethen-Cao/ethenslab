package com.voyah.polaris.agent.core.protocol;

import org.json.JSONObject;

/**
 * 命令执行结果实体类
 * <p>
 * 对应 Native 端: native/include/polarisd/CommandResult.h
 * 结构契约: Section 2.3
 */
public class CommandResult {
    
    /** * 请求序列号 
     * 必须与 CommandRequest.reqId 一致，用于异步匹配回调 
     */
    public final int reqId;
    
    /** * 状态码 
     * 0 = Success 
     * 非0 = Error Code (如 System Exit Code, Timeout 等)
     */
    public final int code;
    
    /** * 可读消息 
     * e.g., "Success", "Timeout", "Fork Failed" 
     */
    public final String msg;
    
    /** * 执行产物 (Payload)
     * 通常是一个 JSON 字符串，例如 "{\"cpu\": \"15%\"}" 或者 "pong"
     * 如果 Native 没有返回 data，默认为 "{}"
     */
    public final String data;

    /**
     * 全参构造
     */
    public CommandResult(int reqId, int code, String msg, String data) {
        this.reqId = reqId;
        this.code = code;
        this.msg = (msg == null) ? "" : msg;
        this.data = (data == null) ? "{}" : data;
    }

    /**
     * 判断命令是否执行成功
     */
    public boolean isSuccess() {
        return code == 0;
    }

    /**
     * 工厂方法：从 JSON 字符串解析对象
     * * @param jsonStr Native 发来的原始 JSON Payload
     * @return 解析后的 CommandResult 对象。如果解析失败，返回包含错误信息的 Result 对象。
     */
    public static CommandResult fromJson(String jsonStr) {
        try {
            if (jsonStr == null || jsonStr.isEmpty()) {
                return new CommandResult(-1, -1, "Empty Response Payload", "{}");
            }

            JSONObject obj = new JSONObject(jsonStr);
            
            int reqId = obj.optInt("reqId", -1);
            int code = obj.optInt("code", -1);
            String msg = obj.optString("msg", "Unknown Error");
            
            // data 字段在 Native 端可能是 JSON Object，也可能是 String
            // optString 会自动处理这两种情况，将其转为字符串
            String data = obj.optString("data", "{}");

            return new CommandResult(reqId, code, msg, data);

        } catch (Exception e) {
            // 解析挂了，返回一个特殊的 Error Result，防止上层 crash
            return new CommandResult(-1, -1, "JSON Parse Error: " + e.getMessage(), "{}");
        }
    }

    @Override
    public String toString() {
        return "CommandResult{" +
                "reqId=" + reqId +
                ", code=" + code +
                ", msg='" + msg + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}