package com.voyah.polaris.agent.core.protocol;

public class LspConstants {
    // 协议头长度 (Magic + Ver + Type + Reserved + ReqId + Len) 
    // 注意：C++ struct Header { uint32 totalLen; uint16 msgType; ... }
    // 我们需要严格对齐 C++ 端的 LspCodec::Header 结构
    public static final int HEADER_LEN = 12; 

    // 消息类型 (与 Native 端 PacketTypes.h 一致)
    public static final int MSG_TYPE_EVENT_REPORT = 0x0001; // Native -> App (Event)
    public static final int MSG_TYPE_CMD_RESP     = 0x0021; // Native -> App (Result)
    public static final int MSG_TYPE_CMD_REQ      = 0x0020; // App -> Native (Request)

    public static final int MAX_PACKET_SIZE = 4 * 1024 * 1024; // 4MB
}