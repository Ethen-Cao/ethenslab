package com.voyah.polaris.agent.core.transport;

/**
 * @brief 传输层连接状态监听器
 * 用于通知上层模块 (Service/UI) 与 Native Daemon (polarisd) 的连接状态变化
 */
public interface ConnectionListener {

    /**
     * 当 Socket 连接建立成功时回调
     * 此时可以开始发送数据
     */
    void onConnected();

    /**
     * 当 Socket 连接断开时回调
     * 通常是因为 Native 进程崩溃、被杀或 Socket 异常
     * Transport 层会自动尝试重连，上层模块可在此处更新状态或重置缓存
     */
    void onDisconnected();
}