#!/usr/bin/env python3
# [脚本] 自动生成 EventID.java 和 polaris_event.h

import csv
from pathlib import Path

try:
    from jinja2 import Template
except ImportError:
    raise SystemExit("Missing dependency: jinja2. Run: pip install -r requirements.txt")

ROOT = Path(__file__).resolve().parents[2]
CSV_PATH = ROOT / "protocol/registry/global_events.csv"
JAVA_TMPL = ROOT / "protocol/templates/EventID.java.tmpl"
JAVA_OUT = ROOT / "sdk/src/main/java/com/voyah/polaris/event/EventID.java"
H_OUT = ROOT / "native/include/polaris_event.h"


def load_events():
    events = []
    with CSV_PATH.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            eid = int(row["EventID"].strip())
            name = row["Name"].strip()
            events.append({"id": eid, "name": name})
    return events


def gen_java(events):
    tmpl = Template(JAVA_TMPL.read_text(encoding="utf-8"))
    JAVA_OUT.parent.mkdir(parents=True, exist_ok=True)
    JAVA_OUT.write_text(tmpl.render(events=events), encoding="utf-8")


def gen_header(events):
    lines = []
    lines.append("// Auto-generated. DO NOT EDIT.\n")
    lines.append("#pragma once\n\n")
    lines.append("namespace polaris {\n")
    lines.append("namespace event_id {\n")
    for e in events:
        lines.append(f"static constexpr long {e[name]} = {e[id]}L;\\n\")\n    lines.append(\"}  // namespace event_id\\n\")\n    lines.append(\"}  // namespace polaris\\n\")\n    H_OUT.parent.mkdir(parents=True, exist_ok=True)\n    H_OUT.write_text(\"\".join(lines), encoding=\"utf-8\")\n\n\ndef main():\n    events = load_events()\n    gen_java(events)\n    gen_header(events)\n    print(\"Generated:\")\n    print(\" -\", JAVA_OUT)\n    print(\" -\", H_OUT)\n\n\nif __name__ == \"__main__\":\n    main()\n
