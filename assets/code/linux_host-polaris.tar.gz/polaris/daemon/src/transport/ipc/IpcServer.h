#pragma once

#include <memory>
#include <thread>
#include <atomic>
#include <map>
#include <mutex>
#include <vector>

namespace voyah {
namespace polaris {

class ClientSession; // 前置声明

/**
 * @brief IPC 服务端 (Reactor 模型)
 * 负责监听 Unix Domain Socket，接受连接，并分发 IO 事件。
 */
class IpcServer {
public:
    IpcServer();
    ~IpcServer();

    /**
     * @brief 启动服务
     * 初始化 Socket, Epoll, 并在新线程中运行事件循环。
     * @return true 成功, false 失败 (查看日志)
     */
    bool start();

    /**
     * @brief 停止服务 (同步阻塞)
     * 发送退出信号 -> 唤醒 Epoll -> 等待线程退出 -> 释放所有资源。
     * 线程安全，可重入。
     */
    void stop();

    bool isRunning() const { return mRunning; }

private:
    // --- Reactor Event Loop ---
    void threadLoop();

    // --- Handlers ---
    // 处理新连接
    void handleAccept();
    
    // 处理退出信号 (EventFD)
    void handleWakeup();
    
    // 处理客户端 IO (Read/Write)
    void handleClientEvent(int fd, uint32_t events);

    // --- Helpers ---
    // 移除并销毁 Session
    void removeSession(int fd);

    // 根据 Session 的写队列状态，更新 Epoll 关注集 (仅 Reactor 线程调用)
    void updateClientEpollInterest(int fd, bool wantWrite);

    // 停止时由 Reactor 线程执行的清理，确保 close()/epoll_ctl 在同一线程
    void cleanupInReactorThread();
    
    // 创建服务端 Socket (bind, listen)
    int createServerSocket();
    
    // 创建唤醒用的 eventfd
    int createWakeupFd();
    
    // 设置 Socket 非阻塞
    static int setNonBlocking(int fd);

private:
    // Socket 路径: /run/polaris/polaris_bridge.sock
    static const char* SOCKET_PATH;
    static const char* SOCKET_DIR;
    // 最大连接数限制 (防资源耗尽)
    static const int MAX_CONNECTIONS = 128;
    // Epoll 最大事件数
    static const int MAX_EVENTS = 64;

    std::atomic<bool> mRunning{false};
    std::thread mThread;

    int mListenFd = -1;
    int mEpollFd = -1;
    int mWakeupFd = -1;

    // Session 管理容器
    // Key: Client FD, Value: Session
    // 仅在 Reactor 线程中访问，无需加锁
    std::map<int, std::shared_ptr<ClientSession>> mSessions;
};

} // namespace polaris
} // namespace voyah