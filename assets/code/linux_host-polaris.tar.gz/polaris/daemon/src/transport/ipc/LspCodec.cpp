#include "transport/ipc/LspCodec.h"

#include "utils/JsonUtils.h"
#include "utils/Log.h"

#include <endian.h>
#include <cstring>

namespace voyah {
namespace polaris {

namespace {
std::string truncateForLog(const std::string& s, size_t maxLen) {
    if (s.size() <= maxLen) return s;
    return s.substr(0, maxLen) + "...";
}
} // namespace

// ============================================================================
// 1. 粘包处理 (Framing)
// ============================================================================

bool LspCodec::decodeFrame(std::vector<uint8_t>& buffer, Header& outHeader, std::string& outPayload) {
    size_t readPos = 0;
    const DecodeStatus st = decodeFrame(static_cast<const std::vector<uint8_t>&>(buffer), readPos, outHeader, outPayload);
    if (st == DecodeStatus::OK) {
        buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(readPos));
        return true;
    }
    if (st == DecodeStatus::ERROR) {
        // 旧接口无法表达“协议错误必须断连”的语义，为了避免状态机卡死，这里仍然清 buffer。
        buffer.clear();
    }
    return false;
}

LspCodec::DecodeStatus LspCodec::decodeFrame(const std::vector<uint8_t>& buffer,
                                            size_t& readPos,
                                            Header& outHeader,
                                            std::string& outPayload) {
    if (readPos > buffer.size()) {
        LOGE("LspCodec: readPos out of range (readPos=%zu, size=%zu)", readPos, buffer.size());
        return DecodeStatus::ERROR;
    }

    const size_t available = buffer.size() - readPos;
    if (available < HEADER_SIZE) {
        return DecodeStatus::NEED_MORE;
    }

    const uint8_t* ptr = buffer.data() + readPos;

    uint32_t totalLenLe = 0;
    uint16_t msgTypeLe = 0;
    uint16_t reservedLe = 0;
    uint32_t reqIdLe = 0;

    // 使用 memcpy 避免未对齐访问 (ARM/RISC-V 安全)
    std::memcpy(&totalLenLe, ptr + 0, sizeof(totalLenLe));
    std::memcpy(&msgTypeLe,  ptr + 4, sizeof(msgTypeLe));
    std::memcpy(&reservedLe, ptr + 6, sizeof(reservedLe));
    std::memcpy(&reqIdLe,    ptr + 8, sizeof(reqIdLe));

    outHeader.totalLen = le32toh(totalLenLe);
    outHeader.msgType  = le16toh(msgTypeLe);
    outHeader.reserved = le16toh(reservedLe);
    outHeader.reqId    = le32toh(reqIdLe);

    // Sanity checks
    if (outHeader.totalLen < HEADER_SIZE) {
        LOGE("LspCodec: Invalid totalLen=%u (<HEADER_SIZE)", outHeader.totalLen);
        return DecodeStatus::ERROR;
    }
    if (outHeader.totalLen > MAX_PACKET_SIZE) {
        LOGE("LspCodec: Packet too large totalLen=%u (max=%zu)", outHeader.totalLen, MAX_PACKET_SIZE);
        return DecodeStatus::ERROR;
    }
    if (outHeader.reserved != 0) {
        LOGE("LspCodec: reserved field must be 0, got=%u", outHeader.reserved);
        return DecodeStatus::ERROR;
    }

    if (available < outHeader.totalLen) {
        return DecodeStatus::NEED_MORE;
    }

    const size_t payloadLen = outHeader.totalLen - HEADER_SIZE;
    if (payloadLen > 0) {
        outPayload.assign(reinterpret_cast<const char*>(ptr + HEADER_SIZE), payloadLen);
    } else {
        outPayload.clear();
    }

    readPos += outHeader.totalLen;
    return DecodeStatus::OK;
}

// ============================================================================
// 2. 编码逻辑 (Serialization)
// ============================================================================

std::vector<uint8_t> LspCodec::encode(uint16_t type, uint32_t reqId, const std::string& jsonPayload) {
    std::vector<uint8_t> packet;

    const size_t totalLen = HEADER_SIZE + jsonPayload.size();
    if (totalLen > UINT32_MAX) {
        LOGE("LspCodec: Payload too large to encode (totalLen=%zu)", totalLen);
        return packet;
    }

    packet.resize(totalLen);
    uint8_t* out = packet.data();

    const uint32_t totalLenLe = htole32(static_cast<uint32_t>(totalLen));
    const uint16_t typeLe     = htole16(type);
    const uint16_t reservedLe = htole16(0);
    const uint32_t reqIdLe    = htole32(reqId);

    std::memcpy(out + 0, &totalLenLe, sizeof(totalLenLe));
    std::memcpy(out + 4, &typeLe,     sizeof(typeLe));
    std::memcpy(out + 6, &reservedLe, sizeof(reservedLe));
    std::memcpy(out + 8, &reqIdLe,    sizeof(reqIdLe));

    if (!jsonPayload.empty()) {
        std::memcpy(out + HEADER_SIZE, jsonPayload.data(), jsonPayload.size());
    }

    return packet;
}

std::vector<uint8_t> LspCodec::encodeEvent(const PolarisEvent& event) {
    Json::Value root = JsonUtils::toJson(event);
    std::string jsonPayload = JsonUtils::toString(root);
    return encode(LSP_TYPE_EVENT_REPORT, 0, jsonPayload);
}

// ============================================================================
// 3. 反序列化 (Deserialization)
// ============================================================================

std::shared_ptr<PolarisEvent> LspCodec::decodeEvent(const std::string& jsonPayload) {
    if (jsonPayload.empty()) {
        LOGW("LspCodec: decodeEvent called with empty payload");
        return nullptr;
    }

    Json::Value root;
    if (!JsonUtils::fromString(jsonPayload, root)) {
        // 限制日志长度，避免刷屏/泄露隐私
        LOGE("LspCodec: Malformed JSON payload (len=%zu): %s",
                  jsonPayload.size(), truncateForLog(jsonPayload, 128).c_str());
        return nullptr;
    }

    return JsonUtils::parsePolarisEvent(root);
}

} // namespace polaris
} // namespace voyah
