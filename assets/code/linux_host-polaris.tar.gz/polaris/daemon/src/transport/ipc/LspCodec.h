#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>
#include <string>
#include <memory>

#include "polaris/protocol/LspDef.h" 
#include "polaris/defs/PolarisEvent.h"

namespace voyah {
namespace polaris {

/**
 * @class LspCodec
 * @brief LSP (Local Socket Protocol) 编解码器
 *
 * Protocol Structure (v1) - Total Header Size: 12 Bytes
 * Byte Order: Little Endian
 *
 * +----------------+----------------+----------------+----------------+
 * |    Total Len   |    Msg Type    |    Reserved    |     Req ID     |
 * |    (4 Bytes)   |    (2 Bytes)   |    (2 Bytes)   |    (4 Bytes)   |
 * +----------------+----------------+----------------+----------------+
 * |                                                                   |
 * |                    JSON Payload (N Bytes)                         |
 * |                                                                   |
 * +----------------+----------------+----------------+----------------+
 */
class LspCodec {
public:
    // 使用别名指向公共定义，避免修改大量 cpp 代码
    using Header = protocol::Header;

    // 映射常量 (从 LspDef.h 获取)
    static constexpr size_t HEADER_SIZE = protocol::HEADER_SIZE;
    static constexpr size_t MAX_PACKET_SIZE = protocol::MAX_PACKET_SIZE;
    
    // 映射消息类型
    static constexpr uint16_t LSP_TYPE_EVENT_REPORT = protocol::EVENT_REPORT;
    static constexpr uint16_t LSP_TYPE_CMD_REQ      = protocol::CMD_REQ;
    static constexpr uint16_t LSP_TYPE_CMD_RESP     = protocol::CMD_RESP;
    
    static_assert(sizeof(Header) == HEADER_SIZE, "LSP header size mismatch");

    enum class DecodeStatus {
        OK,
        NEED_MORE,
        ERROR,
    };

    /**
     * @brief [兼容旧接口] 从 buffer 头部尝试解码一个完整包。
     * 成功解析后会 erase 已消费的字节。
     *
     * @return true 成功解析出一个完整包
     * @return false 数据不足或解析失败
     */
    static bool decodeFrame(std::vector<uint8_t>& buffer, Header& outHeader, std::string& outPayload);

    /**
     * @brief [推荐接口] 使用 readPos 游标进行解包，不做 O(N) 的头部 erase。
     * @param buffer  输入缓冲区（不修改内容）
     * @param readPos [in/out] 读游标，成功解包后前移
     */
    static DecodeStatus decodeFrame(const std::vector<uint8_t>& buffer,
                                    size_t& readPos,
                                    Header& outHeader,
                                    std::string& outPayload);

    /**
     * @brief [通用] 编码任意消息为二进制流
     */
    static std::vector<uint8_t> encode(uint16_t type, uint32_t reqId, const std::string& jsonPayload);

    /**
     * @brief [Client SDK 用] 编码 PolarisEvent -> 二进制包
     */
    static std::vector<uint8_t> encodeEvent(const PolarisEvent& event);

    /**
     * @brief [Server 用] 反序列化 JSON -> PolarisEvent
     */
    static std::shared_ptr<PolarisEvent> decodeEvent(const std::string& jsonPayload);
};

} // namespace polaris
} // namespace voyah
