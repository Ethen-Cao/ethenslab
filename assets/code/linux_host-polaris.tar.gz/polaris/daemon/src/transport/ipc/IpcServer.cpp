#include "transport/ipc/IpcServer.h"

#include "transport/ipc/ClientSession.h"
#include "utils/Log.h"

#include <sys/socket.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/stat.h>

#include <unistd.h>
#include <fcntl.h>

#include <cerrno>
#include <cstring>
#include <chrono>
#include <thread>
#include <vector>

namespace voyah {
namespace polaris {

const char* IpcServer::SOCKET_DIR  = "/run/polaris";
const char* IpcServer::SOCKET_PATH = "/run/polaris/polaris_bridge.sock";

IpcServer::IpcServer() = default;

IpcServer::~IpcServer() {
    stop();
}

bool IpcServer::start() {
    if (mRunning) {
        LOGW("IpcServer is already running.");
        return true;
    }

    LOGI("Starting IpcServer...");

    // 1) Wakeup FD (用于 stop() / 跨线程通知)
    mWakeupFd = createWakeupFd();
    if (mWakeupFd < 0) {
        LOGE("Failed to create wakeupFd.");
        return false;
    }

    // 2) Listen socket
    mListenFd = createServerSocket();
    if (mListenFd < 0) {
        close(mWakeupFd);
        mWakeupFd = -1;
        LOGE("Failed to create server socket.");
        return false;
    }

    // 3) Epoll
    mEpollFd = epoll_create1(EPOLL_CLOEXEC);
    if (mEpollFd < 0) {
        LOGE("Failed to create epoll: %s", strerror(errno));
        close(mListenFd);
        close(mWakeupFd);
        mListenFd = -1;
        mWakeupFd = -1;
        return false;
    }

    // 4) Add listen + wakeup to epoll
    struct epoll_event ev;
    std::memset(&ev, 0, sizeof(ev));

    ev.events = EPOLLIN; // Listener 用 LT 即可
    ev.data.fd = mListenFd;
    if (epoll_ctl(mEpollFd, EPOLL_CTL_ADD, mListenFd, &ev) < 0) {
        LOGE("Epoll add listenFd failed: %s", strerror(errno));
        close(mEpollFd);
        close(mListenFd);
        close(mWakeupFd);
        mEpollFd = -1;
        mListenFd = -1;
        mWakeupFd = -1;
        return false;
    }

    ev.events = EPOLLIN;
    ev.data.fd = mWakeupFd;
    if (epoll_ctl(mEpollFd, EPOLL_CTL_ADD, mWakeupFd, &ev) < 0) {
        LOGE("Epoll add wakeupFd failed: %s", strerror(errno));
        close(mEpollFd);
        close(mListenFd);
        close(mWakeupFd);
        mEpollFd = -1;
        mListenFd = -1;
        mWakeupFd = -1;
        return false;
    }

    // 5) Start Reactor thread
    mRunning = true;
    mThread = std::thread(&IpcServer::threadLoop, this);

    LOGI("IpcServer started successfully on %s", SOCKET_PATH);
    return true;
}

void IpcServer::stop() {
    if (!mRunning) return;

    LOGI("Stopping IpcServer...");
    mRunning = false;

    // Wake reactor
    if (mWakeupFd >= 0) {
        uint64_t one = 1;
        (void)::write(mWakeupFd, &one, sizeof(one));
    }

    if (mThread.joinable()) {
        LOGI("Joining IpcServer thread.");
        mThread.join();
    }

    // Reactor 线程退出后，Session 应该已清理完。
    mSessions.clear();

    if (mEpollFd >= 0) {
        close(mEpollFd);
        mEpollFd = -1;
    }
    if (mListenFd >= 0) {
        close(mListenFd);
        mListenFd = -1;
    }
    if (mWakeupFd >= 0) {
        close(mWakeupFd);
        mWakeupFd = -1;
    }

    unlink(SOCKET_PATH);

    LOGI("IpcServer stopped.");
}

// ============================================================================
// Reactor Event Loop
// ============================================================================

void IpcServer::threadLoop() {
    struct epoll_event events[MAX_EVENTS];

    while (mRunning) {
        int n = epoll_wait(mEpollFd, events, MAX_EVENTS, -1);

        if (n < 0) {
            if (errno == EINTR) continue;
            LOGE("Epoll wait error: %s", strerror(errno));
            mRunning = false;
            break;
        }

        for (int i = 0; i < n; ++i) {
            const int fd = events[i].data.fd;
            const uint32_t evs = events[i].events;

            if (fd == mWakeupFd) {
                handleWakeup();
            } else if (fd == mListenFd) {
                handleAccept();
            } else {
                handleClientEvent(fd, evs);
            }
        }
    }

    // 重要：保证 close()/epoll_ctl(DEL) 在 Reactor 线程完成。
    cleanupInReactorThread();
}

void IpcServer::cleanupInReactorThread() {
    if (mEpollFd < 0) {
        mSessions.clear();
        return;
    }

    std::vector<int> fds;
    fds.reserve(mSessions.size());
    for (const auto& kv : mSessions) {
        fds.push_back(kv.first);
    }
    for (int fd : fds) {
        removeSession(fd);
    }
}

// ============================================================================
// Handlers
// ============================================================================

void IpcServer::handleAccept() {
    while (true) {
        struct sockaddr_un clientAddr;
        socklen_t clientLen = sizeof(clientAddr);

        int clientFd = accept4(
            mListenFd,
            reinterpret_cast<struct sockaddr*>(&clientAddr),
            &clientLen,
            SOCK_NONBLOCK | SOCK_CLOEXEC);

        if (clientFd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return; // drained
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EMFILE || errno == ENFILE) {
                LOGE("Accept failed: Too many open files!");
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                return;
            }
            LOGW("Accept error: %s", strerror(errno));
            return;
        }

        if (mSessions.size() >= MAX_CONNECTIONS) {
            LOGW("Max connections reached (%d), rejecting client fd=%d", MAX_CONNECTIONS, clientFd);
            close(clientFd);
            continue;
        }

        auto session = std::make_shared<ClientSession>(clientFd, mWakeupFd);

        struct epoll_event ev;
        std::memset(&ev, 0, sizeof(ev));

        // Client 使用 ET
        ev.events = EPOLLIN | EPOLLET | EPOLLRDHUP | EPOLLHUP | EPOLLERR;
        ev.data.fd = clientFd;

        if (epoll_ctl(mEpollFd, EPOLL_CTL_ADD, clientFd, &ev) < 0) {
            LOGE("Failed to add client to epoll: %s", strerror(errno));
            session->shutdownAndCloseInReactor();
            continue;
        }

        mSessions[clientFd] = session;
        LOGI("Accepted client: fd=%d, active_sessions=%zu", clientFd, mSessions.size());
    }
}

void IpcServer::handleWakeup() {
    // Drain eventfd counter
    uint64_t val;
    while (true) {
        ssize_t r = ::read(mWakeupFd, &val, sizeof(val));
        if (r == sizeof(val)) continue;
        if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
        break;
    }

    // 统一在 Reactor 线程处理跨线程请求：
    // 1) close 请求
    // 2) epoll interest 更新请求
    std::vector<int> toRemove;
    toRemove.reserve(8);

    for (const auto& kv : mSessions) {
        const int fd = kv.first;
        const auto& session = kv.second;

        if (session->isCloseRequested()) {
            toRemove.push_back(fd);
            continue;
        }

        if (session->consumeInterestDirty()) {
            updateClientEpollInterest(fd, session->wantsWrite());
        }
    }

    for (int fd : toRemove) {
        removeSession(fd);
    }
}

void IpcServer::handleClientEvent(int fd, uint32_t events) {
    auto it = mSessions.find(fd);
    if (it == mSessions.end()) {
        epoll_ctl(mEpollFd, EPOLL_CTL_DEL, fd, nullptr);
        return;
    }

    const std::shared_ptr<ClientSession>& session = it->second;

    if (events & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)) {
        LOGI("Client disconnected (event 0x%x): fd=%d, pid=%d", events, fd, session->getPeerPid());
        removeSession(fd);
        return;
    }

    if (events & EPOLLIN) {
        const auto st = session->onRead();
        if (st == ClientSession::IOStatus::ERROR) {
            removeSession(fd);
            return;
        }
    }

    if (events & EPOLLOUT) {
        const auto st = session->onWrite();
        if (st == ClientSession::IOStatus::ERROR) {
            removeSession(fd);
            return;
        }
    }

    // 在 Reactor 线程内，及时更新 interest (比如写队列清空后关闭 EPOLLOUT)
    if (session->consumeInterestDirty()) {
        updateClientEpollInterest(fd, session->wantsWrite());
    }
}

void IpcServer::updateClientEpollInterest(int fd, bool wantWrite) {
    struct epoll_event ev;
    std::memset(&ev, 0, sizeof(ev));
    ev.data.fd = fd;
    ev.events = EPOLLIN | EPOLLET | EPOLLRDHUP | EPOLLHUP | EPOLLERR;
    if (wantWrite) {
        ev.events |= EPOLLOUT;
    }

    if (epoll_ctl(mEpollFd, EPOLL_CTL_MOD, fd, &ev) < 0) {
        // 常见原因：fd 已被关闭或已从 epoll 移除
        LOGW("Failed to update epoll interest for fd=%d: %s", fd, strerror(errno));
    }
}

void IpcServer::removeSession(int fd) {
    // 1) 从 epoll 移除
    if (mEpollFd >= 0) {
        epoll_ctl(mEpollFd, EPOLL_CTL_DEL, fd, nullptr);
    }

    // 2) 关闭 fd (Reactor thread only)
    auto it = mSessions.find(fd);
    if (it != mSessions.end()) {
        it->second->shutdownAndCloseInReactor();
        mSessions.erase(it);
    }

    LOGI("Session removed: fd=%d, remaining=%zu", fd, mSessions.size());
}

// ============================================================================
// Helpers
// ============================================================================

int IpcServer::createServerSocket() {
    if (mkdir(SOCKET_DIR, 0755) < 0 && errno != EEXIST) {
        LOGE("Failed to create socket dir %s: %s", SOCKET_DIR, strerror(errno));
        return -1;
    }

    // 先探测是否已有实例在运行，避免无脑 unlink 把别的进程 socket 删除。
    {
        struct sockaddr_un addr;
        std::memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        if (strlen(SOCKET_PATH) < sizeof(addr.sun_path)) {
            strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);

            int probe = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
            if (probe >= 0) {
                if (connect(probe, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) == 0) {
                    LOGE("Socket %s is already in use (another instance is running).", SOCKET_PATH);
                    close(probe);
                    return -1;
                }

                const int err = errno;
                close(probe);

                if (err == ECONNREFUSED || err == ENOENT) {
                    // stale file / no server
                    unlink(SOCKET_PATH);
                } else {
                    // 其他错误（权限 / 非 socket / 地址问题）都保守处理
                    if (access(SOCKET_PATH, F_OK) == 0) {
                        LOGE("Cannot probe existing socket %s (errno=%d: %s). Refuse to unlink.",
                                  SOCKET_PATH, err, strerror(err));
                        return -1;
                    }
                }
            }
        }
    }

    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        LOGE("Socket create failed: %s", strerror(errno));
        return -1;
    }

    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    if (strlen(SOCKET_PATH) >= sizeof(addr.sun_path)) {
        LOGE("Socket path too long");
        close(fd);
        return -1;
    }
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);

    if (bind(fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        LOGE("Bind failed: %s", strerror(errno));
        close(fd);
        return -1;
    }

    // 0660: owner/group 可访问，避免 0666 带来的本地提权面
    if (chmod(SOCKET_PATH, 0660) < 0) {
        LOGW("Failed to chmod socket: %s", strerror(errno));
    }

    if (listen(fd, MAX_CONNECTIONS) < 0) {
        LOGE("Listen failed: %s", strerror(errno));
        close(fd);
        unlink(SOCKET_PATH);
        return -1;
    }

    return fd;
}

int IpcServer::createWakeupFd() {
    int fd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    if (fd < 0) {
        LOGE("Eventfd create failed: %s", strerror(errno));
    }
    return fd;
}

int IpcServer::setNonBlocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1) return -1;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

} // namespace polaris
} // namespace voyah
