#include "transport/ipc/ClientSession.h"

#include "core/EventQueue.h"
#include "core/HostManagerEvent.h"
#include "transport/ipc/LspCodec.h"
#include "utils/Log.h"

#include <unistd.h>
#include <sys/socket.h>

#include <cerrno>
#include <cstring>

namespace voyah {
namespace polaris {

namespace {
// 轻量的 drop 计数，便于观测系统背压情况
std::atomic<uint64_t> gEventQueueDropCount{0};
std::atomic<uint64_t> gOutboundDropCount{0};

void notifyEventfd(int eventfd) {
    if (eventfd < 0) return;
    uint64_t one = 1;
    // eventfd 写入 8 字节计数器。
    // EAGAIN 表示计数器溢出(极少见)，忽略即可。
    if (::write(eventfd, &one, sizeof(one)) < 0) {
        if (errno != EAGAIN && errno != EINTR) {
            // 这里不能 LOGE 过于频繁，使用 WARN
            LOGW("ClientSession: notify eventfd failed: %s", strerror(errno));
        }
    }
}
} // namespace

// ============================================================================
// Lifecycle
// ============================================================================

ClientSession::ClientSession(int fd, int wakeupFd)
    : mFd(fd), mWakeupFd(wakeupFd) {
    fetchPeerCredentials();
    mRecvBuffer.reserve(4096);
    LOGI("ClientSession created: fd=%d, pid=%d, uid=%d", mFd, mPeerPid, mPeerUid);
}

ClientSession::~ClientSession() {
    // 理想路径：fd 会在 IpcServer(Reactor线程)的 removeSession() 中关闭。
    // 这里作为兜底，防止外部持有 shared_ptr 导致泄露。
    int fd = mFd;
    if (fd >= 0) {
        LOGW("ClientSession dtor closing fd=%d outside reactor (fallback)", fd);
        ::close(fd);
        mFd = -1;
    }
}

void ClientSession::fetchPeerCredentials() {
    struct ucred ucred {};
    socklen_t len = sizeof(struct ucred);
    if (getsockopt(mFd, SOL_SOCKET, SO_PEERCRED, &ucred, &len) == 0) {
        mPeerPid = ucred.pid;
        mPeerUid = ucred.uid;
        LOGI("ClientSession: peer credentials fetched. pid=%d, uid=%d", mPeerPid, mPeerUid);
    } else {
        LOGE("Failed to get peer credentials: %s", strerror(errno));
    }
}

// ============================================================================
// Thread-safe API (business threads)
// ============================================================================

void ClientSession::sendMsg(const std::vector<uint8_t>& data) {
    if (data.empty()) return;
    if (mState.load(std::memory_order_acquire) != State::CONNECTED) return;

    {
        std::lock_guard<std::mutex> lock(mOutboundMutex);

        // 防止业务线程无限堆积导致 OOM
        if (mOutboundBytes + data.size() > MAX_OUTBOUND_BYTES) {
            uint64_t cnt = ++gOutboundDropCount;
            if ((cnt % 100) == 1) {
                LOGW("Outbound queue overflow, drop=%llu", (unsigned long long)cnt);
            }
            return;
        }

        mOutboundQueue.push_back(data);
        mOutboundBytes += data.size();
        mHasOutbound.store(true, std::memory_order_release);
    }

    mInterestDirty.store(true, std::memory_order_release);
    notifyEventfd(mWakeupFd);
}

void ClientSession::close() {
    State expected = State::CONNECTED;
    if (mState.compare_exchange_strong(expected, State::CLOSING, std::memory_order_acq_rel)) {
        mInterestDirty.store(true, std::memory_order_release);
        notifyEventfd(mWakeupFd);
    }
}

// ============================================================================
// Reactor callbacks (reactor thread only)
// ============================================================================

ClientSession::IOStatus ClientSession::onRead() {
    if (mState.load(std::memory_order_acquire) != State::CONNECTED) return IOStatus::ERROR;

    uint8_t tmp[4096];

    while (true) {
        ssize_t n = ::recv(mFd, tmp, sizeof(tmp), 0);
        if (n > 0) {
            // [安全防御] 限制接收缓冲
            if (mRecvBuffer.size() + static_cast<size_t>(n) > MAX_RECV_BUFFER_SIZE) {
                LOGE("ClientSession: Recv buffer overflow (%zu bytes). Closing.", mRecvBuffer.size());
                return IOStatus::ERROR;
            }

            size_t oldSize = mRecvBuffer.size();
            mRecvBuffer.resize(oldSize + static_cast<size_t>(n));
            std::memcpy(mRecvBuffer.data() + oldSize, tmp, static_cast<size_t>(n));

            // 解包：可能一次 recv 解出多个包
            while (true) {
                LspCodec::Header header{};
                std::string payload;

                auto st = LspCodec::decodeFrame(mRecvBuffer, mReadPos, header, payload);
                if (st == LspCodec::DecodeStatus::OK) {
                    if (header.msgType == LspCodec::LSP_TYPE_EVENT_REPORT) {
                        auto event = LspCodec::decodeEvent(payload);
                        if (event) {
                            if (event->pid <= 0) event->pid = mPeerPid;

                            auto mgrEvent = std::make_shared<HostManagerEvent>();
                            mgrEvent->type = HostManagerEvent::TYPE_IPC_EVENT;
                            mgrEvent->eventData = event;
                            mgrEvent->session = shared_from_this();

                            if (!EventQueue::getInstance().push(mgrEvent)) {
                                uint64_t cnt = ++gEventQueueDropCount;
                                if ((cnt % 100) == 1) {
                                    LOGW("EventQueue full, dropped=%llu", (unsigned long long)cnt);
                                }
                            }
                        }
                    } else {
                        // TODO: 处理 LSP_TYPE_CMD_REQ / RESP 等消息
                        LOGW("Received unhandled msgType: 0x%04x", header.msgType);
                    }
                } else if (st == LspCodec::DecodeStatus::NEED_MORE) {
                    break; // 等待更多数据
                } else {
                    LOGE("Protocol framing error from pid=%d. Closing.", mPeerPid);
                    return IOStatus::ERROR;
                }
            }

            // 缓冲区整理：避免无限增长 & 避免频繁 memmove
            if (mReadPos >= COMPACT_THRESHOLD) {
                const size_t remaining = (mReadPos <= mRecvBuffer.size()) ? (mRecvBuffer.size() - mReadPos) : 0;
                if (remaining == 0) {
                    mRecvBuffer.clear();
                    mReadPos = 0;
                } else if (mReadPos >= (mRecvBuffer.size() / 2) || remaining < 4096) {
                    std::memmove(mRecvBuffer.data(), mRecvBuffer.data() + mReadPos, remaining);
                    mRecvBuffer.resize(remaining);
                    mReadPos = 0;
                }
            }

            // 关键：ET 模式下必须持续读到 EAGAIN，因此这里不能 break
            continue;

        } else if (n == 0) {
            // 对端关闭
            LOGI("Client closed connection: fd=%d pid=%d", mFd, mPeerPid);
            return IOStatus::ERROR;
        } else {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return IOStatus::OK; // 已读空
            }
            if (errno == EINTR) {
                continue;
            }
            LOGE("Recv error: %s (fd=%d)", strerror(errno), mFd);
            return IOStatus::ERROR;
        }
    }
}

ClientSession::IOStatus ClientSession::onWrite() {
    if (mState.load(std::memory_order_acquire) != State::CONNECTED) return IOStatus::ERROR;

    std::lock_guard<std::mutex> lock(mOutboundMutex);

    while (!mOutboundQueue.empty()) {
        std::vector<uint8_t>& chunk = mOutboundQueue.front();
        if (mOutboundOffset >= chunk.size()) {
            // 不应发生：自愈
            mOutboundOffset = 0;
        }

        const uint8_t* ptr = chunk.data() + mOutboundOffset;
        const size_t len = chunk.size() - mOutboundOffset;

        ssize_t sent = ::send(mFd, ptr, len, MSG_NOSIGNAL);

        if (sent > 0) {
            mOutboundOffset += static_cast<size_t>(sent);
            if (mOutboundOffset >= chunk.size()) {
                mOutboundBytes -= chunk.size();
                mOutboundQueue.pop_front();
                mOutboundOffset = 0;
            }
            // 继续尝试发送剩余数据，直到 EAGAIN
            continue;
        }

        if (sent == -1) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return IOStatus::AGAIN;
            }
            if (errno == EINTR) {
                continue;
            }
            LOGE("Send error: %s (fd=%d)", strerror(errno), mFd);
            return IOStatus::ERROR;
        }

        // sent == 0: 理论上不会发生(非零 len)，视为错误
        LOGE("Send returned 0 (fd=%d)", mFd);
        return IOStatus::ERROR;
    }

    // 队列空了，通知 IpcServer 关闭 EPOLLOUT
    mHasOutbound.store(false, std::memory_order_release);
    mInterestDirty.store(true, std::memory_order_release);

    return IOStatus::OK;
}

// ============================================================================
// Reactor-owned close
// ============================================================================

void ClientSession::shutdownAndCloseInReactor() {
    State prev = mState.exchange(State::CLOSED, std::memory_order_acq_rel);
    if (prev == State::CLOSED) return;

    int fd = mFd;
    if (fd >= 0) {
        ::shutdown(fd, SHUT_RDWR);
        ::close(fd);
        mFd = -1;
    }

    mRecvBuffer.clear();
    mReadPos = 0;
    {
        std::lock_guard<std::mutex> lock(mOutboundMutex);
        mOutboundQueue.clear();
        mOutboundOffset = 0;
        mOutboundBytes = 0;
    }
    mHasOutbound.store(false, std::memory_order_release);
    mInterestDirty.store(false, std::memory_order_release);
}

} // namespace polaris
} // namespace voyah
