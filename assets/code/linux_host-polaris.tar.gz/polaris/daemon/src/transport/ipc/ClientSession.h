#pragma once

#include "transport/Session.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <sys/types.h>
#include <vector>

namespace voyah {
namespace polaris {

/**
 * @brief IPC Client Session
 *
 * Thread model:
 * - Reactor thread: onRead()/onWrite()/shutdownAndCloseInReactor()
 * - Any thread: sendMsg()/close() (only enqueue + wake reactor)
 */
class ClientSession : public Session, public std::enable_shared_from_this<ClientSession> {
public:
    enum class State : uint8_t {
        CONNECTED,
        CLOSING,
        CLOSED,
    };

    enum class IOStatus : uint8_t {
        OK,
        AGAIN, // EAGAIN/EWOULDBLOCK
        ERROR,
    };

    /**
     * @param fd        Client socket fd (non-blocking)
     * @param wakeupFd  eventfd used to wake reactor thread
     */
    ClientSession(int fd, int wakeupFd);
    ~ClientSession();

    // --- Reactor thread only ---
    IOStatus onRead();
    IOStatus onWrite();

    /**
     * @brief Request the server to close the session.
     * Thread-safe; does NOT close fd directly.
     */
    void close();

    /**
     * @brief Enqueue data for sending to the peer.
     * Thread-safe and non-blocking.
     */
    void sendMsg(const std::vector<uint8_t>& data);

    /**
     * @brief Close the fd and release resources.
     * Reactor thread only.
     */
    void shutdownAndCloseInReactor();

    // --- State/Interest helpers (used by reactor) ---
    bool isCloseRequested() const { return mState.load(std::memory_order_acquire) == State::CLOSING; }
    bool isClosed() const { return mState.load(std::memory_order_acquire) == State::CLOSED; }
    bool wantsWrite() const { return mHasOutbound.load(std::memory_order_acquire); }
    bool consumeInterestDirty() { return mInterestDirty.exchange(false, std::memory_order_acq_rel); }

    // --- Getters ---
    int getFd() const { return mFd; }
    pid_t getPeerPid() const { return mPeerPid; }
    uid_t getPeerUid() const { return mPeerUid; }

private:
    void fetchPeerCredentials();
    void notifyReactor();

private:
    int mFd;
    int mWakeupFd;

    std::atomic<State> mState{State::CONNECTED};

    // For epoll interest update
    std::atomic<bool> mInterestDirty{false};
    std::atomic<bool> mHasOutbound{false};

    // Identity audit
    pid_t mPeerPid = -1;
    uid_t mPeerUid = -1;

    // --- Receive buffer (reactor thread only) ---
    std::vector<uint8_t> mRecvBuffer;
    size_t mReadPos = 0; // cursor to avoid erase()

    // --- Outbound queue (thread-safe) ---
    std::mutex mOutboundMutex;
    std::deque<std::vector<uint8_t>> mOutboundQueue;
    size_t mOutboundOffset = 0; // offset within front packet
    size_t mOutboundBytes = 0;  // total queued bytes
    std::atomic<uint64_t> mOutboundDropCount{0};

    // Limits
    static constexpr size_t MAX_RECV_BUFFER_SIZE = 4 * 1024 * 1024;
    static constexpr size_t MAX_OUTBOUND_BYTES   = 4 * 1024 * 1024;
    static constexpr size_t COMPACT_THRESHOLD    = 2048;
};

} // namespace polaris
} // namespace voyah
