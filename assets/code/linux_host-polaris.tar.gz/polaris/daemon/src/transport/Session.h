#pragma once

#include <vector>
#include <cstdint>
#include <memory>

namespace voyah {
namespace polaris {

/**
 * @class Session
 * @brief 通信会话抽象基类 (Interface)
 * * 目的：为 PolarisManager 提供统一的视图，屏蔽 IPC (Unix Domain Socket) 
 * 和 Vsock (Virtio Socket) 的底层差异。
 */
class Session {
public:
    virtual ~Session() = default;

    /**
     * @brief 发送二进制消息
     * * 这是一个纯虚函数，由 ClientSession (IPC) 或 GuestSession (Vsock) 具体实现。
     * 实现者需要负责处理非阻塞发送、EAGAIN 缓冲队列等底层细节。
     * * @param data 二进制数据包
     */
    virtual void sendMsg(const std::vector<uint8_t>& data) = 0;

    /**
     * @brief 关闭连接
     * * 显式断开底层 Socket 连接并清理资源。
     */
    virtual void close() = 0;
};

} // namespace polaris
} // namespace voyah