#include "transport/vsock/PlpCodec.h"
#include "utils/Log.h" // 假设有日志工具
#include <json/json.h> // 需要链接 jsoncpp
#include <cstring>     // memcpy
#include <sstream>

namespace voyah {
namespace polaris {

// ============================================================================
// [新增] CRC32 算法实现 (IEEE 802.3 标准)
// ============================================================================
static uint32_t calculateCrc32(const uint8_t* data, size_t length) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (int j = 0; j < 8; ++j) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xEDB88320;
            else
                crc >>= 1;
        }
    }
    return ~crc;
}

// ============================================================================
// 辅助工具：JSON 序列化/反序列化
// ============================================================================
static std::string toJsonString(const Json::Value& root) {
    Json::StreamWriterBuilder builder;
    builder["indentation"] = ""; // 紧凑模式，无换行
    return Json::writeString(builder, root);
}

static bool parseJsonString(const std::string& raw, Json::Value& outRoot) {
    Json::CharReaderBuilder builder;
    std::string errs;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    if (!reader->parse(raw.data(), raw.data() + raw.size(), &outRoot, &errs)) {
        LOGE("Json Parse Failed: %s", errs.c_str());
        return false;
    }
    return true;
}

// ============================================================================
// 接口实现
// ============================================================================
// --- 核心流式解码实现 ---
bool PlpCodec::decodeFrame(std::vector<uint8_t>& buffer, Header& outHeader, std::string& outPayload) {
    if (buffer.size() < HEADER_SIZE) return false;

    const Header* pHdr = reinterpret_cast<const Header*>(buffer.data());

    // 1. Magic Check (快速失败)
    if (pHdr->magic != PLP_MAGIC) {
        LOGE("PLP: Invalid Magic 0x%08X. Clearing buffer to recover.", pHdr->magic);
        buffer.clear(); // 遇到脏数据，暴力丢弃，等待重连恢复
        return false;
    }

    // 2. Size Sanity Check
    if (pHdr->payloadLen > MAX_PAYLOAD_SIZE) {
        LOGE("PLP: Payload too large %u. Clearing buffer.", pHdr->payloadLen);
        buffer.clear();
        return false;
    }

    // 3. Wait for full packet
    size_t totalLen = HEADER_SIZE + pHdr->payloadLen;
    if (buffer.size() < totalLen) {
        return false; // 半包，等待更多数据
    }

    // 4. Extract Data
    std::memcpy(&outHeader, pHdr, HEADER_SIZE);
    
    if (pHdr->payloadLen > 0) {
        // 安全拷贝
        outPayload.assign(reinterpret_cast<char*>(buffer.data() + HEADER_SIZE), pHdr->payloadLen);
    } else {
        outPayload.clear();
    }

    // 5. Consume Buffer (Move semantics optimized in std::vector implementation usually)
    buffer.erase(buffer.begin(), buffer.begin() + totalLen);

    return true;
}

std::vector<uint8_t> PlpCodec::encodeEvent(const PolarisEvent& event) {
    Json::Value root;
    // DTO -> JSON
    root["eventId"] = (Json::UInt64)event.eventId;
    root["timestamp"] = (Json::UInt64)event.timestamp;
    root["pid"] = event.pid;
    root["processName"] = event.processName;
    root["processVer"] = event.processVer;
    // params 本身是 JSON 字符串，为了避免双重转义，可以直接存 String，
    // 或者如果在协议中约定 params 是 Object，这里需要二次解析。
    // 为了健壮性，这里按字符串透传，由接收端决定如何解析。
    root["params"] = event.params; 
    root["logf"] = event.logf;

    std::string payload = toJsonString(root);

    // Event 不需要响应，SeqId 可以填 0 或自增计数器。
    // 这里填 0，因为是单向通知。
    return encodeFrame(TYPE_EVENT_H2G, 0, payload);
}

std::vector<uint8_t> PlpCodec::encodeCmdResp(const CommandResult& result) {
    Json::Value root;
    root["code"] = result.code;
    root["msg"] = result.msg;
    root["data"] = result.data; // data 是 Json::Value，直接嵌入
    // reqId 虽然在 Header 里有，但 Payload 里带一份方便调试
    root["reqId"] = (Json::UInt)result.reqId;

    std::string payload = toJsonString(root);

    // [关键]: ID 透传 (Loopback)
    // 将业务层的 reqId 填入 传输层的 seqId
    return encodeFrame(TYPE_CMD_RESP_H2G, result.reqId, payload);
}

bool PlpCodec::decodeCmdReq(const std::vector<uint8_t>& data, CommandRequest& outReq) {
    Header header;
    if (!decodeHeader(data, header)) {
        return false;
    }

    // 校验类型
    if (header.type != TYPE_CMD_REQ_G2H) {
        LOGE("PlpDecode: Wrong msg type 0x%04X, expected CMD_REQ_G2H", header.type);
        return false;
    }

    // 校验 Payload 长度一致性
    size_t actualPayloadSize = data.size() - sizeof(Header);
    if (actualPayloadSize != header.payloadLen) {
        LOGE("PlpDecode: Payload len mismatch. Header=%u, Actual=%zu", 
                header.payloadLen, actualPayloadSize);
        return false;
    }

    // 提取 Payload
    if (header.payloadLen == 0) {
        LOGE("PlpDecode: Empty payload for command request");
        return false;
    }

    std::string payloadStr(reinterpret_cast<const char*>(data.data() + sizeof(Header)), 
                           header.payloadLen);

    // 解析 JSON
    Json::Value root;
    if (!parseJsonString(payloadStr, root)) {
        return false;
    }

    // 填充业务对象
    // [关键]: ID 透传 - 从 Header seqId 恢复 业务 reqId
    outReq.reqId = header.seqId;
    
    outReq.action = root.get("action", "").asString();
    outReq.args = root.get("args", Json::Value(Json::objectValue)); // 默认为空对象
    outReq.timeoutMs = root.get("timeout", 5000).asUInt();
    
    // Target 判断 (根据协议约定，G2H 的目标通常是 LOCAL(Host))
    // 也可以在 JSON 里带 target 字段
    std::string tgtStr = root.get("target", "LOCAL").asString();
    outReq.target = (tgtStr == "HOST") ? CommandRequest::TARGET_HOST : CommandRequest::TARGET_LOCAL;

    return true;
}

bool PlpCodec::decodeHeader(const std::vector<uint8_t>& data, Header& outHeader) {
    if (data.size() < sizeof(Header)) {
        return false;
    }

    // [关键]: 安全内存拷贝
    // 严禁使用 reinterpret_cast<Header*>(data.data())，这在 ARM 上会导致对齐崩溃
    std::memcpy(&outHeader, data.data(), sizeof(Header));

    // 1. 魔数校验
    if (outHeader.magic != PLP_MAGIC) {
        LOGE("PlpDecode: Invalid Magic 0x%08X", outHeader.magic);
        return false;
    }

    // 2. 版本校验
    if (outHeader.version != PLP_VERSION) {
        LOGE("PlpDecode: Unsupported Version %d", outHeader.version);
        return false;
    }

    return true;
}

// ============================================================================
// 私有通用编码器
// ============================================================================
std::vector<uint8_t> PlpCodec::encodeFrame(uint16_t type, uint32_t seqId, const std::string& payloadJson) {
    // 1. 准备 Payload
    uint32_t payloadLen = static_cast<uint32_t>(payloadJson.size());

    // 2. 准备 Header
    Header header;
    std::memset(&header, 0, sizeof(Header)); // 清零

    header.magic = PLP_MAGIC;
    header.version = PLP_VERSION;
    header.headerLen = sizeof(Header);
    header.payloadLen = payloadLen;
    header.type = type;
    header.flags = FLAG_IS_JSON; 
    header.seqId = seqId;
    
    // [修复点 1] 计算 CRC32
    // 注意：只计算 Payload 部分，不包含 Header
    if (payloadLen > 0) {
        header.crc32 = calculateCrc32(
            reinterpret_cast<const uint8_t*>(payloadJson.data()), 
            payloadLen
        );
    } else {
        header.crc32 = 0;
    }

    // 3. 组装数据包 (一次性分配内存)
    std::vector<uint8_t> packet;
    packet.resize(sizeof(Header) + payloadLen);

    // [关键]: 安全拷贝
    std::memcpy(packet.data(), &header, sizeof(Header));
    
    if (payloadLen > 0) {
        std::memcpy(packet.data() + sizeof(Header), payloadJson.data(), payloadLen);
    }

    return packet;
}

bool PlpCodec::parseCommandRequest(const std::string& payload, CommandRequest& outReq) {
    Json::Value root;
    if (!parseJsonString(payload, root)) {
        return false;
    }

    outReq.action = root.get("action", "").asString();
    
    // args 可能是一个对象，也可能没传
    if (root.isMember("args")) {
        // 如果 args 是字符串，尝试再次解析？还是直接作为 json value？
        // 通常协议约定 args 是个 Object
        outReq.args = root["args"];
    } else {
        outReq.args = Json::Value(Json::objectValue);
    }
    
    outReq.timeoutMs = root.get("timeout", 5000).asUInt();
    
    std::string tgtStr = root.get("target", "LOCAL").asString();
    outReq.target = (tgtStr == "HOST") ? CommandRequest::TARGET_HOST : CommandRequest::TARGET_LOCAL;

    // 注意：reqId 无法在这里获取，因为它在 Header 里。
    // 调用者 (GuestSession) 负责将 Header.seqId 填入 outReq.reqId
    
    return true;
}

} // namespace polaris
} // namespace voyah