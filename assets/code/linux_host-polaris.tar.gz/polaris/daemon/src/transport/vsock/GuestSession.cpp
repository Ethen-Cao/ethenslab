#include "transport/vsock/GuestSession.h"
#include "transport/vsock/HostVsockServer.h"
#include "transport/vsock/PlpCodec.h"
#include "core/EventQueue.h"           // [关键] 引入事件队列
#include "core/HostManagerEvent.h"  // [关键] 引入信封
#include "utils/Log.h"

#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>

namespace voyah {
namespace polaris {

GuestSession::GuestSession(int fd, HostVsockServer* server) 
    : mFd(fd), mServer(server) {
    mRxBuffer.reserve(4096); // 预分配
    LOGI("GuestSession created, fd=%d", mFd);
}

GuestSession::~GuestSession() {
    close();
}

void GuestSession::close() {
    if (mFd > 0) {
        ::close(mFd);
        mFd = -1;
        LOGI("GuestSession closed");
    }
    // Server 的清理逻辑由 HostVsockServer::onSessionClosed 触发，
    // 这里只负责关闭 FD 和释放自身内存
}

// [Session Interface Implementation]
void GuestSession::sendMsg(const std::vector<uint8_t>& data) {
    if (mFd < 0 || data.empty()) return;

    {
        std::lock_guard<std::mutex> lock(mTxMutex);
        mTxQueue.push_back(data);
    }

    // 唤醒 Epoll 线程去处理发送 (EPOLLOUT 或 EventFd)
    if (mServer) {
        mServer->notify();
    }
}

bool GuestSession::onRead() {
    if (mFd < 0) return false;

    // 1. 读取数据到 mRxBuffer
    size_t oldSize = mRxBuffer.size();
    size_t readSize = 4096;
    mRxBuffer.resize(oldSize + readSize);

    ssize_t n = ::recv(mFd, mRxBuffer.data() + oldSize, readSize, MSG_DONTWAIT);

    if (n > 0) {
        mRxBuffer.resize(oldSize + n); // 修正 buffer 大小

        // 2. 循环解码 (处理粘包/拆包)
        PlpCodec::Header header;
        std::string payload;

        while (PlpCodec::decodeFrame(mRxBuffer, header, payload)) {
            // 解码成功，构造事件信封
            auto envelope = std::make_shared<HostManagerEvent>();
            
            // 绑定 Session (用于回包)
            envelope->session = shared_from_this();

            // 根据类型分发
            if (header.type == PlpCodec::TYPE_CMD_REQ_G2H) {
                // Guest 请求 Host 执行命令
                auto req = std::make_shared<CommandRequest>();
                if (PlpCodec::parseCommandRequest(payload, *req)) {
                    req->reqId = header.seqId; // 透传 ID
                    envelope->type = HostManagerEvent::TYPE_GUEST_CMD_REQ;
                    envelope->cmdRequest = req;
                    
                    // 推送队列
                    EventQueue::getInstance().push(envelope);
                }
            }
            // TODO: 处理 TYPE_CMD_RESP_G2H (Guest 回复 Host 的结果)
        }
        return true;

    } else if (n == 0) {
        LOGI("Guest disconnected (EOF)");
        return false;
    } else {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            mRxBuffer.resize(oldSize); // 无数据，回退大小
            return true;
        }
        LOGE("Guest recv error: %s", strerror(errno));
        return false;
    }
}

bool GuestSession::onWrite() {
    std::lock_guard<std::mutex> lock(mTxMutex);
    
    while (!mTxQueue.empty()) {
        auto& packet = mTxQueue.front();
        uint8_t* ptr = packet.data() + mTxCurrentOffset;
        size_t len = packet.size() - mTxCurrentOffset;
        
        // 使用 MSG_NOSIGNAL 防止 SIGPIPE
        ssize_t sent = ::send(mFd, ptr, len, MSG_NOSIGNAL | MSG_DONTWAIT);
        
        if (sent < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return true; // 内核满，稍后再发
            LOGE("Guest send failed: %s", strerror(errno));
            return false;
        }
        
        mTxCurrentOffset += sent;
        if (mTxCurrentOffset >= packet.size()) {
            mTxQueue.pop_front();
            mTxCurrentOffset = 0;
        } else {
            return true; // Partial write, wait for next cycle
        }
    }
    return true;
}

} // namespace polaris
} // namespace voyah