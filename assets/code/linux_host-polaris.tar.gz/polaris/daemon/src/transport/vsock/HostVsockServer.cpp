#include "transport/vsock/HostVsockServer.h"
#include "transport/vsock/GuestSession.h"
#include "transport/vsock/PlpCodec.h"
#include "utils/Log.h"

#include <sys/socket.h>
#include <linux/vm_sockets.h>
#include <sys/eventfd.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>

namespace voyah {
namespace polaris {

static void setNonBlocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

HostVsockServer::HostVsockServer() {
    mEpollFd = epoll_create1(EPOLL_CLOEXEC);
    mEventFd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = mEventFd;
    epoll_ctl(mEpollFd, EPOLL_CTL_ADD, mEventFd, &ev);
}

HostVsockServer::~HostVsockServer() {
    stop();
    if (mEventFd > 0) close(mEventFd);
    if (mEpollFd > 0) close(mEpollFd);
}

bool HostVsockServer::start(int port) {
    if (mRunning) return true;

    mListenFd = socket(AF_VSOCK, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (mListenFd < 0) {
        LOGE("Failed to create VSOCK socket");
        return false;
    }

    struct sockaddr_vm addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.svm_family = AF_VSOCK;
    addr.svm_cid = VMADDR_CID_ANY;
    addr.svm_port = port;

    if (bind(mListenFd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        LOGE("VSOCK Bind failed: %s", strerror(errno));
        close(mListenFd);
        return false;
    }

    if (listen(mListenFd, 5) < 0) {
        LOGE("VSOCK Listen failed");
        close(mListenFd);
        return false;
    }

    setNonBlocking(mListenFd);
    
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = mListenFd;
    epoll_ctl(mEpollFd, EPOLL_CTL_ADD, mListenFd, &ev);

    mRunning = true;
    mThread = std::thread(&HostVsockServer::threadLoop, this);
    LOGI("VSOCK Server listening on port %d...", port);
    return true;
}

void HostVsockServer::stop() {
    if (!mRunning) return;
    mRunning = false;
    notify(); 
    if (mThread.joinable()) mThread.join();
    if (mListenFd > 0) close(mListenFd);
    
    // Stop 时外部调用，需要加锁
    destroySession();
}

void HostVsockServer::notify() {
    uint64_t u = 1;
    write(mEventFd, &u, sizeof(u));
}

// [修正] 公开版本：先加锁，再调内部实现
void HostVsockServer::destroySession() {
    std::lock_guard<std::mutex> lock(mSessionMutex);
    destroySessionLocked();
}

// [新增] 内部版本：假设锁已持有
void HostVsockServer::destroySessionLocked() {
    if (mGuestSession) {
        LOGI("Cleaning up GuestSession fd=%d", mGuestSession->getFd());
        epoll_ctl(mEpollFd, EPOLL_CTL_DEL, mGuestSession->getFd(), nullptr);
        mGuestSession->close();
        mGuestSession.reset();
    }
}

void HostVsockServer::sendEvent(std::shared_ptr<PolarisEvent> event) {
    if (!event) return;
    auto data = PlpCodec::encodeEvent(*event);

    std::lock_guard<std::mutex> lock(mSessionMutex);

    if (mGuestSession) {
        mGuestSession->sendMsg(data);
    } else {
        if (mOfflineCache.size() >= MAX_OFFLINE_CACHE_SIZE) {
            mOfflineCache.pop_front();
        }
        mOfflineCache.push_back(std::move(data));
        
        if (mOfflineCache.size() == 1) {
            LOGW("Guest disconnected. Caching events in memory...");
        }
    }
}

void HostVsockServer::handleNewConnection() {
    struct sockaddr_vm clientAddr;
    socklen_t len = sizeof(clientAddr);
    int clientFd = accept4(mListenFd, (struct sockaddr*)&clientAddr, &len, SOCK_NONBLOCK | SOCK_CLOEXEC);
    if (clientFd < 0) return;

    LOGI("Guest connected! CID=%u. Processing offline cache...", clientAddr.svm_cid);

    // 先销毁旧连接（外部调用，会自动加锁）
    destroySession();

    std::lock_guard<std::mutex> lock(mSessionMutex);
    mGuestSession = std::make_shared<GuestSession>(clientFd, this);

    flushOfflineCache();

    struct epoll_event ev;
    ev.events = EPOLLIN | EPOLLHUP | EPOLLERR;
    ev.data.fd = clientFd;
    epoll_ctl(mEpollFd, EPOLL_CTL_ADD, clientFd, &ev);
}

void HostVsockServer::flushOfflineCache() {
    if (mOfflineCache.empty()) return;
    LOGI("Flushing %zu offline events to Guest...", mOfflineCache.size());
    for (const auto& packet : mOfflineCache) {
        if (mGuestSession) mGuestSession->sendMsg(packet);
    }
    mOfflineCache.clear();
}

void HostVsockServer::threadLoop() {
    struct epoll_event events[16];
    while (mRunning) {
        int nfds = epoll_wait(mEpollFd, events, 16, -1);
        if (nfds < 0 && errno == EINTR) continue;

        for (int i = 0; i < nfds; ++i) {
            int fd = events[i].data.fd;
            
            if (fd == mEventFd) {
                // [WAKEUP]
                uint64_t u;
                read(mEventFd, &u, sizeof(u));
                
                std::lock_guard<std::mutex> lock(mSessionMutex); // <--- 加锁
                // [修正] 使用 Locked 版本，避免死锁
                if (mGuestSession && !mGuestSession->onWrite()) destroySessionLocked();
            } 
            else if (fd == mListenFd) {
                // [ACCEPT]
                handleNewConnection();
            } 
            else {
                // [IO]
                std::lock_guard<std::mutex> lock(mSessionMutex); // <--- 加锁
                if (mGuestSession && fd == mGuestSession->getFd()) {
                    bool alive = true;
                    if (events[i].events & EPOLLIN) if (!mGuestSession->onRead()) alive = false;
                    if (alive && (events[i].events & EPOLLOUT)) if (!mGuestSession->onWrite()) alive = false;
                    
                    // [修正] 使用 Locked 版本，避免死锁
                    if (!alive) destroySessionLocked();
                }
            }
        }
    }
}

} // namespace polaris
} // namespace voyah