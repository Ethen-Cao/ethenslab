#pragma once
#include <thread>
#include <atomic>
#include <mutex>
#include <memory>
#include <deque>
#include <vector>
#include <sys/epoll.h>

namespace voyah {
namespace polaris {

class GuestSession;
class PolarisEvent;

class HostVsockServer {
public:
    HostVsockServer();
    ~HostVsockServer();

    bool start(int port);
    void stop();
    
    void notify(); 
    void sendEvent(std::shared_ptr<PolarisEvent> event);

private:
    void threadLoop();
    void handleNewConnection();
    
    // 公开给 Stop/HandleConnection 使用（会自动加锁）
    void destroySession(); 
    // [新增] 内部专用，假设已加锁
    void destroySessionLocked();
    
    void flushOfflineCache();

private:
    int mListenFd = -1;
    int mEpollFd = -1;
    int mEventFd = -1;
    
    std::atomic<bool> mRunning{false};
    std::thread mThread;
    
    std::mutex mSessionMutex;
    std::shared_ptr<GuestSession> mGuestSession;

    std::deque<std::vector<uint8_t>> mOfflineCache;
    static constexpr size_t MAX_OFFLINE_CACHE_SIZE = 500; 
};

}
}