#pragma once

#include "transport/Session.h" // 必须包含基类
#include <memory>
#include <vector>
#include <deque>
#include <mutex>

namespace voyah {
namespace polaris {

class HostVsockServer; // Forward declaration

// [修改] 继承 Session
class GuestSession : public Session, public std::enable_shared_from_this<GuestSession> {
public:
    GuestSession(int fd, HostVsockServer* server);
    ~GuestSession() override;

    // [实现 Session 接口]
    // 供 PolarisManager 调用，发送通用二进制数据 (Header + Payload)
    void sendMsg(const std::vector<uint8_t>& data) override;
    
    // [实现 Session 接口]
    void close() override;

    // IO 回调
    bool onRead();  // 返回 false 表示连接断开
    bool onWrite(); // 返回 false 表示写入出错

    int getFd() const { return mFd; }

private:
    int mFd;
    HostVsockServer* mServer; // 用于通知 IO 线程 (epoll/notify)
    
    // 发送队列
    std::mutex mTxMutex;
    std::deque<std::vector<uint8_t>> mTxQueue;
    size_t mTxCurrentOffset = 0;

    // [新增] 接收缓冲区 (处理粘包)
    std::vector<uint8_t> mRxBuffer;
};

} // namespace polaris
} // namespace voyah