#pragma once

#include <vector>
#include <string>
#include <cstdint>
#include <memory>

// 引入业务数据模型
#include "polaris/defs/PolarisEvent.h"
#include "polaris/defs/CommandRequest.h"
#include "polaris/defs/CommandResult.h"

namespace voyah {
namespace polaris {

/**
 * @brief PLP (Polaris Link Protocol) 编解码器
 * 负责将业务对象序列化为二进制网络包 (VSOCK)
 * * 协议特性:
 * - Little Endian 字节序
 * - 24字节固定头部
 * - Payload 支持 JSON
 */
class PlpCodec {
public:
    // ==========================================
    // 协议常量定义
    // ==========================================
    static constexpr uint32_t PLP_MAGIC = 0x504C5253; // "PLRS" (Little Endian: P, L, R, S)
    static constexpr uint16_t PLP_VERSION = 1;
    static constexpr uint16_t PLP_HEADER_LEN = 24;

    // 限制最大包大小 (16MB)，防止恶意 OOM
    static constexpr size_t MAX_PAYLOAD_SIZE = 16 * 1024 * 1024;

    static constexpr size_t   HEADER_SIZE = 24;

    // 标志位
    static constexpr uint16_t FLAG_IS_JSON = 1 << 0;
    static constexpr uint16_t FLAG_GZIP    = 1 << 1;

    // 消息类型定义 (与文档一致)
    enum MsgType : uint16_t {
        TYPE_HEARTBEAT    = 0x0001,
        // H2G (Host -> Guest)
        TYPE_EVENT_H2G    = 0x0010,
        TYPE_CMD_RESP_H2G = 0x0011,
        TYPE_CMD_REQ_H2G  = 0x0012,
        // G2H (Guest -> Host)
        TYPE_CMD_REQ_G2H  = 0x0020,
        TYPE_CMD_RESP_G2H = 0x0021
    };

    // ==========================================
    // 头部结构体 (强制 1 字节对齐)
    // ==========================================
    #pragma pack(push, 1)
    struct Header {
        uint32_t magic;      // 0x504C5253
        uint16_t version;    // 1
        uint16_t headerLen;  // 24
        uint32_t payloadLen; // Body Length
        uint16_t type;       // MsgType
        uint16_t flags;      // BitMask
        uint32_t seqId;      // Link ID
        uint32_t crc32;      // Payload CRC (Optional)
    };
    #pragma pack(pop)

    // 编译期检查：确保 Header 大小严格为 24 字节
    static_assert(sizeof(Header) == 24, "PlpCodec::Header size mismatch!");

    // ==========================================
    // 公开接口
    // ==========================================
    // --- Core Decoding Logic (Stream based) ---
    /**
     * @brief 从流式缓冲区中解码一个完整帧
     * @param buffer [in/out] 输入缓冲区，成功解码后会移除已消费的数据
     * @param outHeader [out] 解析出的头部
     * @param outPayload [out] 解析出的 Payload 数据
     * @return true 成功解析一帧; false 数据不足，需继续读取
     */
    static bool decodeFrame(std::vector<uint8_t>& buffer, Header& outHeader, std::string& outPayload);
    /**
     * @brief [H2G] 编码事件 (Host -> Android)
     * 将 PolarisEvent 序列化为 JSON，SeqId 自增或为0
     */
    static std::vector<uint8_t> encodeEvent(const PolarisEvent& event);

    /**
     * @brief [H2G] 编码命令响应 (Host -> Android)
     * 关键：使用 result.reqId 填充 Header.seqId
     */
    static std::vector<uint8_t> encodeCmdResp(const CommandResult& result);

    /**
     * @brief [G2H] 解码命令请求 (Android -> Host)
     * 关键：将 Header.seqId 赋值给 request.reqId
     * @return true 成功, false 失败(魔数错/长度错/JSON非法)
     */
    static bool decodeCmdReq(const std::vector<uint8_t>& data, CommandRequest& outReq);

    /**
     * @brief 辅助：仅解码头部 (用于分帧检查)
     * 安全地从字节流中提取头部
     */
    static bool decodeHeader(const std::vector<uint8_t>& data, Header& outHeader);

    static bool parseCommandRequest(const std::string& payload, CommandRequest& outReq);

private:
    // 通用编码底层函数
    static std::vector<uint8_t> encodeFrame(uint16_t type, uint32_t seqId, const std::string& payloadJson);
};

} // namespace polaris
} // namespace voyah