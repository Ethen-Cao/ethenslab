#include "core/PolarisManager.h"
#include "utils/Log.h"

#include <csignal>
#include <unistd.h>
#include <iostream>
#include <vector>
#include <cstring> // for strerror

// ==========================================
// 量产级 Main (No Exceptions Version)
// ==========================================

using namespace voyah::polaris;

int main(int argc, char* argv[]) {
    // 1. 初始化日志
    POLARIS_LOG_INIT("polarisd");

    // 2. 屏蔽信号 (Block Signals)
    // 必须在创建任何线程之前完成
    sigset_t signal_mask;
    sigemptyset(&signal_mask);
    sigaddset(&signal_mask, SIGINT);  // Ctrl+C
    sigaddset(&signal_mask, SIGTERM); // systemctl stop
    sigaddset(&signal_mask, SIGPIPE); // 忽略管道破裂

    // 使用 pthread_sigmask 而不是 sigprocmask
    int ret = pthread_sigmask(SIG_BLOCK, &signal_mask, nullptr);
    if (ret != 0) {
        LOGE("Failed to set signal mask: %s", strerror(ret));
        return EXIT_FAILURE;
    }

    LOGI("========================================");
    LOGI("   Polaris Daemon (Linux Host) v1.2   ");
    LOGI("   PID: %d", getpid());
    LOGI("========================================");

    // 3. 启动核心业务
    // 移除 try-catch，直接依赖返回值
    if (!PolarisManager::getInstance().start()) {
        LOGE("Failed to start PolarisManager. Exiting.");
        POLARIS_LOG_DEINIT();
        return EXIT_FAILURE;
    }

    LOGI("Polaris Daemon is running. Waiting for signals...");

    // 4. 同步等待信号 (主循环)
    int sig = 0;
    while (true) {
        // sigwait 是 C 语言系统调用，不会抛出 C++ 异常
        ret = sigwait(&signal_mask, &sig);
        if (ret != 0) {
            LOGE("sigwait failed: %s", strerror(ret));
            // 如果 sigwait 失败，这是一个严重错误，应该退出重启
            break;
        }

        if (sig == SIGINT || sig == SIGTERM) {
            LOGI("Received signal %d (%s). Starting shutdown...", 
                 sig, strsignal(sig));
            break; // 正常退出
        }
        
        if (sig == SIGPIPE) {
            LOGW("Received SIGPIPE, ignored.");
            continue; // 继续等待
        }
        
        LOGW("Received unexpected signal %d", sig);
    }

    // 5. 执行退出逻辑
    LOGI("Stopping PolarisManager...");
    PolarisManager::getInstance().stop();

    LOGI("Polaris Daemon exited gracefully.");
    POLARIS_LOG_DEINIT();
    
    return EXIT_SUCCESS;
}