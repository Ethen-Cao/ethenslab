// IAction.h (placeholder)
#pragma once
#include <string>

struct CommandRequest;
struct CommandResult;

class IAction {
public:
  virtual ~IAction() = default;
  virtual CommandResult run(const CommandRequest& req) = 0;
};
