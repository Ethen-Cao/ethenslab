#pragma once

#include <memory>
#include <thread>
#include <atomic>
#include <vector>

#include "HostManagerEvent.h"
#include "transport/ipc/IpcServer.h"

// 前置声明 (解耦编译依赖)
namespace voyah {
namespace polaris {
    class CommandExecutor;
    class HostVsockServer;
}
}

namespace voyah {
namespace polaris {

class PolarisManager {
public:
    // 单例模式
    static PolarisManager& getInstance() {
        static PolarisManager instance;
        return instance;
    }

    PolarisManager(const PolarisManager&) = delete;
    PolarisManager& operator=(const PolarisManager&) = delete;

    /**
     * @brief 初始化并启动所有子模块
     * 1. 启动 IPC Server
     * 2. 启动 Vsock Server
     * 3. 启动 Command Executor
     * 4. 启动 Manager 自身的事件处理线程
     */
    bool start();

    /**
     * @brief 停止服务
     * 按反向顺序停止所有模块，确保资源释放
     */
    void stop();

    /**
     * @brief 等待主线程结束 (阻塞)
     * 用于 main 函数保持运行
     */
    void join();

private:
    PolarisManager();
    ~PolarisManager();

    // 核心业务循环 (Thread 2)
    void dispatchLoop();

    // --- 事件处理 ---
    void processEvent(std::shared_ptr<HostManagerEvent> event);
    
    // 处理来自 IPC 的事件 (Client -> Host)
    void handleIpcEvent(std::shared_ptr<HostManagerEvent> event);
    
    // 处理来自 Guest 的命令 (Android -> Host)
    void handleGuestCmd(std::shared_ptr<HostManagerEvent> event);

    // 处理策略执行结果 (Executor -> Host)
    void handleStrategyComplete(std::shared_ptr<HostManagerEvent> event);

private:
    std::atomic<bool> mRunning{false};
    std::thread mDispatchThread;

    // 子模块 (使用 unique_ptr 管理生命周期)
    std::unique_ptr<IpcServer> mIpcServer;
    std::unique_ptr<HostVsockServer> mVsockServer;
    // std::unique_ptr<CommandExecutor> mExecutor;    // 稍后集成
};

} // namespace polaris
} // namespace voyah