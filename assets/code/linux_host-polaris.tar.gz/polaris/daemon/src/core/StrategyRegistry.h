// StrategyRegistry.h (placeholder)
#pragma once
#include <cstdint>

class StrategyRegistry {
public:
  bool hasStrategy(uint64_t eventId) const {
    (void)eventId;
    return false; // TODO
  }
};
