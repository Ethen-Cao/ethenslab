// IStrategy.h (placeholder)
#pragma once
#include <cstdint>

struct HostManagerEvent;

class IStrategy {
public:
  virtual ~IStrategy() = default;
  virtual void execute(HostManagerEvent& env) = 0;
};
