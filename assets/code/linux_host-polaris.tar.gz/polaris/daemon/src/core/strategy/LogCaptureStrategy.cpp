// LogCaptureStrategy.cpp (placeholder)
#include "IStrategy.h"

// TODO: implement capture log strategy
