#pragma once

#include <queue>
#include <mutex>
#include <condition_variable>
#include <memory>
#include <atomic>
#include <chrono>

#include "HostManagerEvent.h"

namespace voyah {
namespace polaris {

/**
 * @class EventQueue
 * @brief 线程安全的高性能事件队列 (Singleton)。
 * * 特性：
 * 1. 线程安全：支持多线程并发 Push，单线程/多线程 Pop。
 * 2. 流量控制：固定容量 (Capacity)，满则丢弃 (Drop-tail)，防止 OOM。
 * 3. 优雅退出：Pop 支持超时返回，允许工作线程定期检查退出标志。
 * 4. 监控统计：内置原子计数器用于性能分析。
 */
class EventQueue {
public:
    // 默认容量 2048。
    // 假设每个 Event 占用 1KB 内存，满载约占用 2MB 堆内存，非常安全。
    static constexpr size_t DEFAULT_CAPACITY = 2048;

    struct Stats {
        std::atomic<uint64_t> totalPushed{0};   // 累计入队
        std::atomic<uint64_t> totalDropped{0};  // 累计丢弃
        std::atomic<uint64_t> peakSize{0};      // 历史最大深度
        std::atomic<size_t>   currentSize{0};   // 当前深度
    };

public:
    // 单例访问
    static EventQueue& getInstance() {
        static EventQueue instance;
        return instance;
    }

    // 禁止拷贝和赋值
    EventQueue(const EventQueue&) = delete;
    EventQueue& operator=(const EventQueue&) = delete;

    /**
     * @brief 推送事件 (非阻塞)
     * 供 IPC/Monitor 线程调用。
     * * @param event 事件智能指针
     * @return true 推送成功
     * @return false 队列已满，事件被丢弃 (调用者应记录 WARN 日志)
     */
    bool push(std::shared_ptr<HostManagerEvent> event) {
        if (!event) return false;

        {
            std::lock_guard<std::mutex> lock(mMutex);
            
            // 1. 背压检查 (Backpressure Check)
            if (mQueue.size() >= mCapacity) {
                mStats.totalDropped++;
                return false; 
            }

            // 2. 入队
            mQueue.push(std::move(event));
            
            // 3. 更新统计
            size_t size = mQueue.size();
            mStats.currentSize = size;
            mStats.totalPushed++;
            
            // 更新峰值 (非强一致性，只做参考)
            uint64_t peak = mStats.peakSize.load(std::memory_order_relaxed);
            if (size > peak) {
                mStats.peakSize.store(size, std::memory_order_relaxed);
            }
        }

        // 4. 唤醒消费者
        // notify_one 放在锁外可以减少惊群效应，但对于 queue 操作通常放在锁内更安全
        // 这里的逻辑很简单，放在锁外只有极微小的性能优势，放在锁内更稳健。
        mCondVar.notify_one(); 
        return true;
    }

    /**
     * @brief 获取事件 (阻塞带超时)
     * 供 PolarisManager 主线程调用。
     * * @param timeoutMs 等待超时时间 (毫秒)
     * @return std::shared_ptr<HostManagerEvent> 成功返回事件，超时返回 nullptr
     */
    std::shared_ptr<HostManagerEvent> pop(int timeoutMs = 100) {
        std::unique_lock<std::mutex> lock(mMutex);

        // 等待条件：队列不为空 OR 超时
        // 使用 wait_for 防止线程死锁无法退出
        bool hasEvent = mCondVar.wait_for(lock, std::chrono::milliseconds(timeoutMs), [this] {
            return !mQueue.empty();
        });

        if (!hasEvent) {
            return nullptr; // 超时返回空
        }

        // 取出数据
        auto event = mQueue.front();
        mQueue.pop();
        
        // 更新统计
        mStats.currentSize = mQueue.size();

        return event;
    }

    /**
     * @brief 唤醒所有等待者 (用于 Shutdown)
     */
    void breakAllWaiters() {
        std::lock_guard<std::mutex> lock(mMutex);
        mCondVar.notify_all();
    }

    /**
     * @brief 清空队列
     */
    void clear() {
        std::lock_guard<std::mutex> lock(mMutex);
        std::queue<std::shared_ptr<HostManagerEvent>> empty;
        std::swap(mQueue, empty);
        mStats.currentSize = 0;
    }

    // --- Getters / Setters ---

    void setCapacity(size_t cap) {
        std::lock_guard<std::mutex> lock(mMutex);
        mCapacity = cap;
    }

    // 获取统计信息的引用 (只读)
    const Stats& getStats() const {
        return mStats;
    }

    bool isEmpty() const {
        std::lock_guard<std::mutex> lock(mMutex);
        return mQueue.empty();
    }

private:
    EventQueue() : mCapacity(DEFAULT_CAPACITY) {}
    ~EventQueue() { clear(); }

private:
    size_t mCapacity;
    Stats mStats;

    std::queue<std::shared_ptr<HostManagerEvent>> mQueue;
    mutable std::mutex mMutex;
    std::condition_variable mCondVar;
};

} // namespace polaris
} // namespace voyah