#pragma once

#include <memory>
#include <string>

// [关键] 包含正确的定义，确保在 voyah::polaris 命名空间下可见
#include "polaris/defs/PolarisEvent.h"
#include "polaris/defs/CommandRequest.h"
#include "polaris/defs/CommandResult.h"

// 前置声明基类
namespace voyah {
namespace polaris {
    class Session;
}
}

namespace voyah {
namespace polaris {

/**
 * @brief 内部状态机信封 (Envelope)
 * 用于在 IpcServer, Manager, Executor 之间流转数据。
 */
struct HostManagerEvent {
    enum Type {
        // [Ingress]
        TYPE_IPC_EVENT,         // 来自 Linux 本地 Client
        TYPE_MONITOR_EVENT,     // 来自 SystemMonitor
        
        // [Command]
        TYPE_GUEST_CMD_REQ,     // 来自 Android 的命令请求
        TYPE_CMD_EXEC_RESULT,   // 本地命令执行完毕的结果
        
        // [Strategy]
        TYPE_STRATEGY_COMPLETE  // 策略（如Log抓取）执行完毕
    };

    Type type;

    // 业务数据 (Optional, depends on type)
    std::shared_ptr<PolarisEvent> eventData;
    
    // 命令请求 (Optional)
    std::shared_ptr<CommandRequest> cmdRequest;
    
    // 命令结果 (Optional)
    std::shared_ptr<CommandResult> cmdResult;

    // 回包上下文 (Optional)
    // 使用 weak_ptr 防止循环引用 (Session 持有 Manager 引用的话)
    // 同时也为了处理 Session 此时已断开的情况
    std::weak_ptr<Session> session;
};

} // namespace polaris
} // namespace voyah