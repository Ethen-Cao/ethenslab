#include "PolarisManager.h"
#include "EventQueue.h"
#include "transport/ipc/IpcServer.h"
#include "transport/vsock/HostVsockServer.h"
#include "utils/Log.h"

#include <chrono>

namespace voyah {
namespace polaris {

// [关键修正] VSOCK 监听端口
// 必须与 Android 端 (HostTransport.cpp) 的 HOST_PORT = 9001 严格一致！
static constexpr int VSOCK_PORT = 9001;

PolarisManager::PolarisManager() {
    // 构造函数只做基础变量初始化
}

PolarisManager::~PolarisManager() {
    stop();
}

bool PolarisManager::start() {
    if (mRunning) {
        LOGW("PolarisManager is already running.");
        return true;
    }

    LOGI("PolarisManager starting...");

    // =========================================================
    // 1. 初始化 IPC Server (Linux Local)
    // =========================================================
    mIpcServer = std::make_unique<IpcServer>();
    if (!mIpcServer->start()) {
        LOGE("Failed to start IpcServer (Critical). Exiting.");
        return false;
    }

    // =========================================================
    // 2. 初始化 Vsock Server (East-West Traffic)
    // =========================================================
    mVsockServer = std::make_unique<HostVsockServer>();
    
    // 启动监听 9001 端口
    if (!mVsockServer->start(VSOCK_PORT)) {
        // VSOCK 启动失败 (如驱动未加载)，记录错误但不退出 Daemon，保证本地 IPC 可用
        LOGE("Failed to start HostVsockServer on port %d. Cross-VM features disabled.", VSOCK_PORT);
    } else {
        LOGI("HostVsockServer started on port %d (Waiting for Android Guest...)", VSOCK_PORT);
    }

    // =========================================================
    // 3. 初始化 Command Executor (TODO)
    // =========================================================
    // mExecutor = std::make_unique<CommandExecutor>();
    // mExecutor->start();

    // =========================================================
    // 4. 启动自身的分发线程
    // =========================================================
    mRunning = true;
    mDispatchThread = std::thread(&PolarisManager::dispatchLoop, this);

    LOGI("PolarisManager started successfully.");
    return true;
}

void PolarisManager::stop() {
    if (!mRunning) return;
    
    LOGI("PolarisManager stopping...");
    mRunning = false;

    // 1. 停止接入层
    if (mIpcServer) {
        mIpcServer->stop();
    }
    if (mVsockServer) {
        mVsockServer->stop();
    }

    // 2. 停止执行层
    // if (mExecutor) mExecutor->stop();

    // 3. 等待分发线程
    if (mDispatchThread.joinable()) {
        mDispatchThread.join();
    }
    
    // 4. 清理资源
    mIpcServer.reset();
    mVsockServer.reset();
    // mExecutor.reset();

    LOGI("PolarisManager stopped.");
}

void PolarisManager::join() {
    if (mDispatchThread.joinable()) {
        mDispatchThread.join();
    }
}

// ============================================================================
// Core Dispatch Loop
// ============================================================================

void PolarisManager::dispatchLoop() {
    pthread_setname_np(pthread_self(), "PolarisMgr");

    while (mRunning) {
        // 从队列获取事件 (带超时 100ms)
        auto event = EventQueue::getInstance().pop(100);

        if (event) {
            processEvent(event);
        }
    }
}

void PolarisManager::processEvent(std::shared_ptr<HostManagerEvent> event) {
    if (!event) return;

    switch (event->type) {
        case HostManagerEvent::TYPE_IPC_EVENT:
            handleIpcEvent(event);
            break;

        case HostManagerEvent::TYPE_GUEST_CMD_REQ:
            handleGuestCmd(event);
            break;

        case HostManagerEvent::TYPE_STRATEGY_COMPLETE:
            handleStrategyComplete(event);
            break;

        default:
            LOGW("Unknown event type: %d", static_cast<int>(event->type));
            break;
    }
}

// ============================================================================
// Event Handlers
// ============================================================================

void PolarisManager::handleIpcEvent(std::shared_ptr<HostManagerEvent> envelope) {
    auto eventData = envelope->eventData;
    if (!eventData) {
        LOGW("IPC Event with no eventData");
        return;
    }

    LOGI("Processing IPC Event: ID=%lu, PID=%d, Name=%s", 
             eventData->eventId, eventData->pid, eventData->processName.c_str());

    // 1. 策略检查 (TODO)
    /*
    if (StrategyRegistry::check(eventData->eventId)) {
        // ...
    }
    */

    // 2. 转发给 Android (Forwarding)
    if (mVsockServer) {
        mVsockServer->sendEvent(eventData);
    } else {
        LOGD("VsockServer not ready, cannot forward event to Guest.");
    }
}

void PolarisManager::handleGuestCmd(std::shared_ptr<HostManagerEvent> envelope) {
    auto req = envelope->cmdRequest;
    if (!req) return;

    LOGI("Received Guest Command: ReqID=%u, Action=%s, Target=%d", 
             req->reqId, req->action.c_str(), req->target);

    // 简单的 Ping 处理
    if (req->action == "ping") {
        LOGI("Handling PING locally");
        // TODO: 回复 Pong
        return;
    }
}

void PolarisManager::handleStrategyComplete(std::shared_ptr<HostManagerEvent> envelope) {
    LOGI("Strategy execution complete, forwarding enriched event...");
    if (mVsockServer && envelope->eventData) {
        mVsockServer->sendEvent(envelope->eventData);
    }
}

} // namespace polaris
} // namespace voyah