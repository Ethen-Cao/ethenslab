#pragma once

#include <string>
#include <memory>
#include <json/json.h> // 必须确保系统安装了 jsoncpp (libjsoncpp-dev)

// 引用之前定义的 Event 结构体
// 根据你的目录结构，它在 src/message/PolarisEvent.h
#include "polaris/defs/PolarisEvent.h"

namespace voyah {
namespace polaris {

class JsonUtils {
public:
    /**
     * @brief 序列化：Json::Value -> String (Compact Mode, 无换行符)
     */
    static std::string toString(const Json::Value& root);

    /**
     * @brief 反序列化：String -> Json::Value
     * @return true 成功, false 失败
     */
    static bool fromString(const std::string& str, Json::Value& outRoot);

    /**
     * @brief 业务转换：PolarisEvent -> Json::Value
     * 用于发送端
     */
    static Json::Value toJson(const PolarisEvent& event);

    /**
     * @brief 业务转换：Json::Value -> PolarisEvent
     * 用于接收端
     */
    static std::shared_ptr<PolarisEvent> parsePolarisEvent(const Json::Value& root);
};

} // namespace polaris
} // namespace voyah