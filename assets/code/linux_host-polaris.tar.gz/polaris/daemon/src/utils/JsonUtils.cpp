#include "utils/JsonUtils.h"
#include "utils/Log.h" // 确保引用了我们刚才修复的 Log.h

namespace voyah {
namespace polaris {

// ============================================================================
// 基础 Helper
// ============================================================================

std::string JsonUtils::toString(const Json::Value& root) {
    // 使用 StreamWriterBuilder 生成紧凑的 JSON 字符串 (无空格换行)
    Json::StreamWriterBuilder builder;
    builder["commentStyle"] = "None";
    builder["indentation"] = ""; // 关键：空字符串表示压缩输出
    return Json::writeString(builder, root);
}

bool JsonUtils::fromString(const std::string& str, Json::Value& outRoot) {
    if (str.empty()) return false;
    
    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    std::string errs;
    
    if (!reader->parse(str.data(), str.data() + str.size(), &outRoot, &errs)) {
        LOGW("JsonUtils: Parse failed: %s", errs.c_str());
        return false;
    }
    return true;
}

// ============================================================================
// 业务对象转换
// ============================================================================

Json::Value JsonUtils::toJson(const PolarisEvent& event) {
    Json::Value root;
    // 强制类型转换，防止歧义
    root["eventId"]     = (Json::UInt64)event.eventId;
    root["timestamp"]   = (Json::UInt64)event.timestamp;
    root["pid"]         = event.pid;
    
    // 字符串字段，判空处理
    root["processName"] = event.processName.empty() ? "unknown" : event.processName;
    root["processVer"]  = event.processVer.empty() ? "1.0" : event.processVer;
    
    if (!event.logf.empty()) {
        root["logf"] = event.logf;
    }

    // [关键处理] params
    // event.params 本身是一个 JSON 格式的字符串 (例如 "{\"cpu\": 10}")
    // 为了让生成的最终 JSON 好看且易于解析，我们尝试把它解析回 Object 再放入 root
    if (!event.params.empty()) {
        Json::Value paramsObj;
        if (fromString(event.params, paramsObj)) {
            // 成功解析：以 Object 形式存入 {"params": {"cpu": 10}}
            root["params"] = paramsObj;
        } else {
            // 解析失败：作为普通字符串存入 {"params": "raw string"}
            root["params"] = event.params;
        }
    } else {
        root["params"] = Json::objectValue;
    }

    return root;
}

std::shared_ptr<PolarisEvent> JsonUtils::parsePolarisEvent(const Json::Value& root) {
    auto evt = std::make_shared<PolarisEvent>();

    // 1. 必填字段
    evt->eventId     = root.get("eventId", 0).asUInt64();
    evt->timestamp   = root.get("timestamp", 0).asUInt64();
    evt->pid         = root.get("pid", 0).asInt();
    evt->processName = root.get("processName", "unknown").asString();
    evt->processVer  = root.get("processVer", "1.0").asString();

    // 2. 选填字段
    if (root.isMember("logf")) {
        evt->logf = root["logf"].asString();
    }

    // 3. params 处理 (逆向操作)
    // 无论收到的是 Object 还是 String，最终都转为 String 存入结构体
    if (root.isMember("params")) {
        const Json::Value& paramsNode = root["params"];
        if (paramsNode.isObject() || paramsNode.isArray()) {
            evt->params = toString(paramsNode);
        } else {
            evt->params = paramsNode.asString();
        }
    } else {
        evt->params = "{}";
    }

    // 4. 简单校验
    if (evt->eventId == 0) {
        LOGW("JsonUtils: Parsed event with ID 0, might be invalid.");
    }

    return evt;
}

} // namespace polaris
} // namespace voyah