#pragma once
// Polaris Log - Production-grade single header (Final Fixed Version)
//
// Fixes applied (P0/P1/P2):
//   P0) to_syslog_prio/to_syslog_mask_from_level are declared before use (compiles)
//   P1) Clarify: when buffer is full we may overwrite the last byte to force '\n'
//       (cannot guarantee no overwrite if we insist on newline)
//   P2) Extra safety: clamp `off` before writing NUL terminator
//
// Build switches:
// -DPOLARIS_USE_SYSLOG
// -DPOLARIS_LOG_TAG="\"polarisd\""
// -DPOLARIS_SYSLOG_FACILITY=LOG_DAEMON
// -DPOLARIS_LOG_LEVEL=2
// -DPOLARIS_LOG_WITH_SOURCE=1
// -DPOLARIS_SYSLOG_PERROR=1        // syslog 时同时打印到 stderr（格式与 console 完全一致）
// -DPOLARIS_SYSLOG_APPEND_NL=1     // syslog 消息末尾添加 \n（默认关闭）

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <sys/time.h>
#include <unistd.h>

#if defined(POLARIS_USE_SYSLOG)
  #include <syslog.h>
#endif

// ============================================================================
// 1) Config defaults
// ============================================================================
#ifndef POLARIS_LOG_LEVEL
  #ifdef NDEBUG
    #define POLARIS_LOG_LEVEL 2
  #else
    #define POLARIS_LOG_LEVEL 3
  #endif
#endif

#ifndef POLARIS_LOG_TAG
  #define POLARIS_LOG_TAG ""
#endif

#ifndef POLARIS_LOG_WITH_SOURCE
  #define POLARIS_LOG_WITH_SOURCE 0
#endif

#ifndef POLARIS_LOG_MAX_LINE
  #define POLARIS_LOG_MAX_LINE 2048     // 推荐：>= 1024
#endif

#if defined(POLARIS_USE_SYSLOG)
  #ifndef POLARIS_SYSLOG_FACILITY
    #define POLARIS_SYSLOG_FACILITY LOG_DAEMON
  #endif
  #ifndef POLARIS_SYSLOG_PERROR
    #define POLARIS_SYSLOG_PERROR 0
  #endif
  #ifndef POLARIS_SYSLOG_APPEND_NL
    #define POLARIS_SYSLOG_APPEND_NL 0
  #endif
#endif

namespace voyah {
namespace polaris {
namespace log_detail {

// ---------------- Utilities ----------------
inline const char* level_to_str(int lvl) {
  switch (lvl) {
    case 0: return "ERROR";
    case 1: return "WARN";
    case 2: return "INFO";
    case 3: return "DEBUG";
    case 4: return "TRACE";
    default: return "UNK";
  }
}

inline const char* basename(const char* path) {
  if (!path) return "";
  const char* slash = std::strrchr(path, '/');
  return slash ? (slash + 1) : path;
}

// "YYYY-MM-DD HH:MM:SS.mmm"
inline void format_time(char* buf, size_t len) {
  struct timeval tv {};
  gettimeofday(&tv, nullptr);
  time_t now = tv.tv_sec;
  struct tm t {};
  localtime_r(&now, &t);
  const int ms = static_cast<int>(tv.tv_usec / 1000);

  std::snprintf(buf, len, "%04d-%02d-%02d %02d:%02d:%02d.%03d",
                t.tm_year + 1900, t.tm_mon + 1, t.tm_mday,
                t.tm_hour, t.tm_min, t.tm_sec, ms);
}

// Safe append helpers (avoid underflow/overflow)
inline void appendf(char* buf, size_t cap, size_t& off, const char* fmt, ...) {
  if (!buf || cap == 0 || off >= cap || !fmt) return;
  size_t rem = cap - off;

  va_list ap;
  va_start(ap, fmt);
  int n = std::vsnprintf(buf + off, rem, fmt, ap);
  va_end(ap);

  if (n > 0) {
    off += (static_cast<size_t>(n) < rem) ? static_cast<size_t>(n) : (rem - 1);
  }
}

inline void vappendf(char* buf, size_t cap, size_t& off, const char* fmt, va_list ap) {
  if (!buf || cap == 0 || off >= cap || !fmt) return;
  size_t rem = cap - off;

  va_list ap2;
  va_copy(ap2, ap);
  int n = std::vsnprintf(buf + off, rem, fmt, ap2);
  va_end(ap2);

  if (n > 0) {
    off += (static_cast<size_t>(n) < rem) ? static_cast<size_t>(n) : (rem - 1);
  }
}

// ---------------- Syslog helpers (P0: declare before use) ----------------
#if defined(POLARIS_USE_SYSLOG)
inline int to_syslog_prio(int lvl) {
  switch (lvl) {
    case 0: return LOG_ERR;
    case 1: return LOG_WARNING;
    case 2: return LOG_INFO;
    case 3: return LOG_DEBUG;
    case 4: return LOG_DEBUG;   // syslog has no TRACE
    default: return LOG_INFO;
  }
}

inline int to_syslog_mask_from_level(int level) {
  if (level >= 3) return LOG_UPTO(LOG_DEBUG);
  if (level == 2) return LOG_UPTO(LOG_INFO);
  if (level == 1) return LOG_UPTO(LOG_WARNING);
  return LOG_UPTO(LOG_ERR);
}
#endif

// ---------------- Console sink (always available) ----------------
inline void emit_console_line(int lvl,
                              const char* tag,
                              const char* file,
                              int line,
                              const char* func,
                              const char* fmt,
                              va_list ap) {
  char out[POLARIS_LOG_MAX_LINE];
  size_t off = 0;

  char tbuf[64];
  format_time(tbuf, sizeof(tbuf));

  if (tag && tag[0] != '\0') {
    appendf(out, sizeof(out), off, "[%s] [%s] [%s] ", tbuf, level_to_str(lvl), tag);
  } else {
    appendf(out, sizeof(out), off, "[%s] [%s] ", tbuf, level_to_str(lvl));
  }

  const char* b = basename(file);
  if (lvl == 0 || POLARIS_LOG_WITH_SOURCE) {
    appendf(out, sizeof(out), off, "%s:%d %s: ", b, line, func ? func : "");
  }

  vappendf(out, sizeof(out), off, fmt, ap);

  // Add '\n'. If buffer is full, we overwrite the last byte to force newline (P1 clarified).
  if (off + 1 < sizeof(out)) {
    out[off++] = '\n';
  } else if (off > 0) {
    out[off - 1] = '\n'; // sacrifice last byte to guarantee newline
  }

  // P2: extra clamp before NUL-terminator
  if (off >= sizeof(out)) off = sizeof(out) - 1;
  out[off] = '\0';

  (void)::write(STDERR_FILENO, out, off);
}

// ---------------- Syslog sink ----------------
inline void emit_syslog_line(int lvl,
                             const char* tag,
                             const char* file,
                             int line,
                             const char* func,
                             const char* fmt,
                             va_list ap) {
#if !defined(POLARIS_USE_SYSLOG)
  (void)lvl; (void)tag; (void)file; (void)line; (void)func; (void)fmt; (void)ap;
#else
  // Note: syslog/journald already provides timestamps in metadata; we do not embed time by default.
  char msg[POLARIS_LOG_MAX_LINE];
  size_t off = 0;

  if (tag && tag[0] != '\0') {
    appendf(msg, sizeof(msg), off, "%s [%s] ", level_to_str(lvl), tag);
  } else {
    appendf(msg, sizeof(msg), off, "%s ", level_to_str(lvl));
  }

  const char* b = basename(file);
  if (lvl == 0 || POLARIS_LOG_WITH_SOURCE) {
    appendf(msg, sizeof(msg), off, "%s:%d %s: ", b, line, func ? func : "");
  }

  vappendf(msg, sizeof(msg), off, fmt, ap);

  // Optional '\n' (off by default). syslog does not require it, but keep option.
  #if POLARIS_SYSLOG_APPEND_NL
    if (off + 1 < sizeof(msg)) {
      msg[off++] = '\n';
    } else if (off > 0) {
      msg[off - 1] = '\n';
    }
  #endif

  // P2: extra clamp before NUL-terminator
  if (off >= sizeof(msg)) off = sizeof(msg) - 1;
  msg[off] = '\0';

  syslog(to_syslog_prio(lvl), "%s", msg);

  // If enabled, also print to stderr in the SAME format as console mode (with timestamp).
  #if POLARIS_SYSLOG_PERROR
    va_list ap2;
    va_copy(ap2, ap);
    emit_console_line(lvl, tag, file, line, func, fmt, ap2);
    va_end(ap2);
  #endif
#endif
}

// ---------------- Unified entry ----------------
inline void log(int lvl,
                const char* tag,
                const char* file,
                int line,
                const char* func,
                const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);

#if defined(POLARIS_USE_SYSLOG)
  emit_syslog_line(lvl, tag, file, line, func, fmt, ap);
#else
  emit_console_line(lvl, tag, file, line, func, fmt, ap);
#endif

  va_end(ap);
}

} // namespace log_detail
} // namespace polaris
} // namespace voyah

// ============================================================================
// 2) Init / Deinit
// ============================================================================
#if defined(POLARIS_USE_SYSLOG)
  #define POLARIS_LOG_INIT(ident) \
    do { \
      openlog((ident), LOG_PID | LOG_NDELAY, POLARIS_SYSLOG_FACILITY); \
      setlogmask(::voyah::polaris::log_detail::to_syslog_mask_from_level(POLARIS_LOG_LEVEL)); \
    } while(0)
  #define POLARIS_LOG_DEINIT() closelog()
#else
  #define POLARIS_LOG_INIT(ident) do { (void)(ident); setvbuf(stderr, nullptr, _IONBF, 0); } while(0)
  #define POLARIS_LOG_DEINIT() do {} while(0)
#endif

// ============================================================================
// 3) Compile-time gated macros
// ============================================================================
#define POLARIS__LOG_CALL(lvl, fmt, ...) \
  ::voyah::polaris::log_detail::log((lvl), POLARIS_LOG_TAG, __FILE__, __LINE__, __func__, (fmt), ##__VA_ARGS__)

#if POLARIS_LOG_LEVEL >= 0
  #define POLARIS_LOGE(fmt, ...) do { POLARIS__LOG_CALL(0, fmt, ##__VA_ARGS__); } while(0)
#else
  #define POLARIS_LOGE(...) do {} while(0)
#endif

#if POLARIS_LOG_LEVEL >= 1
  #define POLARIS_LOGW(fmt, ...) do { POLARIS__LOG_CALL(1, fmt, ##__VA_ARGS__); } while(0)
#else
  #define POLARIS_LOGW(...) do {} while(0)
#endif

#if POLARIS_LOG_LEVEL >= 2
  #define POLARIS_LOGI(fmt, ...) do { POLARIS__LOG_CALL(2, fmt, ##__VA_ARGS__); } while(0)
#else
  #define POLARIS_LOGI(...) do {} while(0)
#endif

#if POLARIS_LOG_LEVEL >= 3
  #define POLARIS_LOGD(fmt, ...) do { POLARIS__LOG_CALL(3, fmt, ##__VA_ARGS__); } while(0)
#else
  #define POLARIS_LOGD(...) do {} while(0)
#endif

#if POLARIS_LOG_LEVEL >= 4
  #define POLARIS_LOGT(fmt, ...) do { POLARIS__LOG_CALL(4, fmt, ##__VA_ARGS__); } while(0)
#else
  #define POLARIS_LOGT(...) do {} while(0)
#endif

// Short aliases
#define LOGE(...) POLARIS_LOGE(__VA_ARGS__)
#define LOGW(...) POLARIS_LOGW(__VA_ARGS__)
#define LOGI(...) POLARIS_LOGI(__VA_ARGS__)
#define LOGD(...) POLARIS_LOGD(__VA_ARGS__)
#define LOGT(...) POLARIS_LOGT(__VA_ARGS__)
