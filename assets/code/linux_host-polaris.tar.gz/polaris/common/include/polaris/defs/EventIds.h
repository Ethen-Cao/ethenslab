#pragma once

#include <cstdint>

namespace voyah {
namespace polaris {

/**
 * @brief 全局业务事件 ID 定义
 * * 这里的 ID 是跨进程通信的唯一标识。
 * 必须显式指定 : uint64_t 以支持大于 42 亿的大数值。
 */
enum class EventId : uint64_t {
    // 未知/无效事件
    UNKNOWN = 0,

    // ==========================================
    // 系统监控类 (System Monitor)
    // ==========================================
    
    // CPU 负载统计
    // Value: 6660000018
    PVM_SYS_CPU_LOAD_STAT = 6660000018ULL,
    PVM_SYS_MEMORY_LOAD_STAT = 6660000019ULL,

    // 你可以在这里继续添加其他 ID...
    // SYS_MEM_USAGE = ...
};

} // namespace polaris
} // namespace voyah