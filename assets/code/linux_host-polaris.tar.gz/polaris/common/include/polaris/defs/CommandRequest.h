#pragma once
#include <string>
#include <cstdint>
#include <json/json.h> // 必须引入 jsoncpp

namespace voyah {
namespace polaris {

struct CommandResult {
    uint32_t reqId;         // 对应请求ID
    int32_t code;           // 状态码
    std::string msg;        // 消息
    Json::Value data;       // 返回数据 (JSON对象)

    CommandResult() : reqId(0), code(-1), msg("Unknown") {}

    // 快捷构造函数
    static CommandResult success(uint32_t id, const std::string& message = "OK") {
        CommandResult r;
        r.reqId = id;
        r.code = 0;
        r.msg = message;
        return r;
    }
    
    static CommandResult fail(uint32_t id, int32_t errCode, const std::string& message) {
        CommandResult r;
        r.reqId = id;
        r.code = errCode;
        r.msg = message;
        return r;
    }
};

} // namespace polaris
} // namespace voyah