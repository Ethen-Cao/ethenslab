#pragma once
#include <string>
#include <cstdint>
#include <json/json.h> // 必须引入 jsoncpp

namespace voyah {
namespace polaris {

struct CommandRequest {
    // 目标枚举定义
    enum Target {
        TARGET_LOCAL,
        TARGET_HOST
    };

    uint32_t reqId;         // 请求ID (对应 seqId)
    Target target;          // 执行目标
    std::string action;     // 动作名称
    Json::Value args;       // 参数 (JSON对象)
    uint32_t timeoutMs;     // 超时时间

    CommandRequest() : reqId(0), target(TARGET_LOCAL), timeoutMs(5000) {}
};

} // namespace polaris
} // namespace voyah