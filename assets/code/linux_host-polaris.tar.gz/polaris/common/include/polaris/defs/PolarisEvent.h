#pragma once
#include <string>
#include <cstdint>

namespace voyah {
namespace polaris {

struct PolarisEvent {
    uint64_t eventId;
    uint64_t timestamp;
    int32_t pid;
    std::string processName;
    std::string processVer;
    std::string params;      // JSON String
    std::string logf;        // Path

    PolarisEvent() : eventId(0), timestamp(0), pid(0) {}
};

}
}