#pragma once
#include <cstdint>

namespace voyah {
namespace polaris {
namespace protocol {

// 协议常量
constexpr uint32_t HEADER_SIZE = 12;
constexpr uint32_t MAX_PACKET_SIZE = 2 * 1024 * 1024; // 2MB

// 消息类型
enum MsgType : uint16_t {
    EVENT_REPORT = 0x0001,
    CMD_REQ      = 0x0020,
    CMD_RESP     = 0x0021
};

#pragma pack(push, 1)
// 物理帧头 (Packed, Little Endian)
struct Header {
    uint32_t totalLen;  // Header + Payload
    uint16_t msgType;
    uint16_t reserved;
    uint32_t reqId;
};
#pragma pack(pop)

// 编译期检查确保对齐无误
static_assert(sizeof(Header) == HEADER_SIZE, "LSP Header size mismatch");

} // namespace protocol
} // namespace polaris
} // namespace voyah