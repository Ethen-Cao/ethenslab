set -euo pipefail

ROOT=/home/ethen/workspace/voyah/projects/8397/code/linux/apps/apps_proc/build-auto-voyah/tmp-glibc/work/oryon-1-oe-linux/polaris/00.01.00/image
DEVICE_SERIAL=e66b06ea

adb -s "$DEVICE_SERIAL" root
adb -s "$DEVICE_SERIAL" shell mount -o remount,rw /

echo "[1/5] stop services (avoid ETXTBSY)"
adb -s "$DEVICE_SERIAL" shell systemctl stop polaris-monitor.service || true
adb -s "$DEVICE_SERIAL" shell systemctl stop polarisd.service || true

# 可选：确认进程已退出（更稳）
adb -s "$DEVICE_SERIAL" shell 'for i in $(seq 1 30); do pidof polarisd polaris-monitor >/dev/null 2>&1 || exit 0; sleep 0.1; done; exit 0'

echo "[2/5] push libs/services"
adb -s "$DEVICE_SERIAL" push "$ROOT/usr/lib/libpolaris_client.so.1.0.0" /usr/lib/libpolaris_client.so.1.0.0
adb -s "$DEVICE_SERIAL" shell ln -sf /usr/lib/libpolaris_client.so.1.0.0 /usr/lib/libpolaris_client.so.1
adb -s "$DEVICE_SERIAL" shell ln -sf /usr/lib/libpolaris_client.so.1 /usr/lib/libpolaris_client.so

adb -s "$DEVICE_SERIAL" push "$ROOT/usr/lib/systemd/system/polarisd.service" /usr/lib/systemd/system/polarisd.service
adb -s "$DEVICE_SERIAL" push "$ROOT/usr/lib/systemd/system/polaris-monitor.service" /usr/lib/systemd/system/polaris-monitor.service

echo "[3/5] push binaries to .new then atomic replace"
adb -s "$DEVICE_SERIAL" push "$ROOT/usr/bin/polarisd" /usr/bin/polarisd.new
adb -s "$DEVICE_SERIAL" shell 'chmod 0755 /usr/bin/polarisd.new && mv -f /usr/bin/polarisd.new /usr/bin/polarisd'

adb -s "$DEVICE_SERIAL" push "$ROOT/usr/bin/polaris-monitor" /usr/bin/polaris-monitor.new
adb -s "$DEVICE_SERIAL" shell 'chmod 0755 /usr/bin/polaris-monitor.new && mv -f /usr/bin/polaris-monitor.new /usr/bin/polaris-monitor'

echo "[4/5] daemon-reload & enable"
adb -s "$DEVICE_SERIAL" shell systemctl daemon-reload
adb -s "$DEVICE_SERIAL" shell systemctl enable polarisd.service
adb -s "$DEVICE_SERIAL" shell systemctl enable polaris-monitor.service

echo "[5/5] restart services"
adb -s "$DEVICE_SERIAL" shell systemctl restart polarisd.service
adb -s "$DEVICE_SERIAL" shell systemctl restart polaris-monitor.service

echo "Done."
