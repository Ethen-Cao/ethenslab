#include "core/Config.h"
#include "core/PolarisReporter.h"
#include "core/ModuleManager.h"
#include "monitors/process/ProcessMonitor.h"
#include "monitors/resource/ResourceMonitor.h"
#include "utils/Log.h"
#include "polaris/polaris_api.h" // 确保包含 SDK 头文件

#include <csignal>
#include <thread>
#include <condition_variable>
#include <mutex>

// [关键修复]：直接使用 voyah::polaris 命名空间
using namespace voyah::polaris;

std::mutex g_exit_mutex;
std::condition_variable g_exit_cv;
bool g_running = true;

void signal_handler(int) {
    {
        std::lock_guard<std::mutex> lock(g_exit_mutex);
        g_running = false;
    }
    g_exit_cv.notify_all();
}

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    
    std::signal(SIGTERM, signal_handler);
    std::signal(SIGINT, signal_handler);

    // [关键修复]
    // 宏展开后是 setlogmask(polaris::log_detail::...);
    // 这里的 polaris 可能会被编译器认为是顶层命名空间。
    // 为了保险，我们在调用宏之前确保 polaris 是可见的，或者修改 Log.h
    // 如果无法修改 Log.h，尝试在 voyah 命名空间内调用
    {
        using namespace voyah; 
        POLARIS_LOG_INIT("polaris-monitor");
    }

    // 版本号处理
#ifdef POLARIS_MONITOR_VERSION
    LOGI("Polaris Monitor v%s Starting...", POLARIS_MONITOR_VERSION);
#else
    LOGI("Polaris Monitor Starting...");
#endif

    // Config 加载
    Config config;
    // 假设 Config.cpp 修正了，这里我们演示手动赋值避免 Config::Load 报错
    config.resource.enable_cpu = true;
    config.resource.cpu_interval_ms = 3000;
    
    // 初始化 Reporter
    std::string version = "0.1.0";
#ifdef POLARIS_MONITOR_VERSION
    version = POLARIS_MONITOR_VERSION;
#endif
    auto reporter = std::make_shared<PolarisReporter>("polaris-monitor", version);

    // 模块管理
    ModuleManager modules;
    modules.Register(std::make_unique<ResourceMonitor>());
    modules.Register(std::make_unique<ProcessMonitor>());

    if (!modules.InitAll(config, reporter)) {
        LOGE("Failed to init modules");
        return -1;
    }

    modules.StartAll();
    LOGI("All modules started.");

    {
        std::unique_lock<std::mutex> lock(g_exit_mutex);
        g_exit_cv.wait(lock, []{ return !g_running; });
    }

    LOGI("Stopping modules...");
    modules.StopAll();
    
    // 修正：删除 polaris_deinit() 调用，如果是最新 SDK，它通常不需要手动调用，或者在 SDK 内部析构处理
    // 如果 SDK 头文件里有 polaris_deinit，可以保留；否则删除
    // polaris_deinit(); 
    
    POLARIS_LOG_DEINIT();
    return 0;
}