#include "SystemdBusSource.h"
#include "utils/Log.h"
#include <sys/prctl.h>
#include <cstring>
#include <chrono>
#include <csignal>

namespace voyah {
namespace polaris {

// ============================================================================
// 静态辅助函数
// ============================================================================

static std::string get_unit_id_from_path(sd_bus* bus, const char* path) {
    sd_bus_error error = SD_BUS_ERROR_NULL;
    char* id = nullptr;
    int r = sd_bus_get_property_string(bus, "org.freedesktop.systemd1", path,
                                       "org.freedesktop.systemd1.Unit", "Id", &error, &id);
    std::string name = (r >= 0 && id) ? id : path;
    if (id) free(id);
    sd_bus_error_free(&error);
    return name;
}

static std::string get_unit_result(sd_bus* bus, const char* path) {
    sd_bus_error error = SD_BUS_ERROR_NULL;
    char* res = nullptr;
    sd_bus_get_property_string(bus, "org.freedesktop.systemd1", path,
                               "org.freedesktop.systemd1.Service", "Result", &error, &res);
    std::string result = res ? res : "unknown";
    if (res) free(res);
    sd_bus_error_free(&error);
    return result;
}

/**
 * 核心：映射信号编号到可读字符串
 */
static std::string signal_to_string(int sig) {
    switch (sig) {
        case SIGABRT: return "SIGABRT";
        case SIGSEGV: return "SIGSEGV";
        case SIGILL:  return "SIGILL";
        case SIGFPE:  return "SIGFPE";
        case SIGKILL: return "SIGKILL";
        case SIGBUS:  return "SIGBUS";
        case SIGSYS:  return "SIGSYS";
        case SIGTRAP: return "SIGTRAP";
        default:      return "SIGNAL(" + std::to_string(sig) + ")";
    }
}

/**
 * 获取服务退出的具体状态码/信号
 */
static int get_exec_main_status(sd_bus* bus, const char* path) {
    sd_bus_error error = SD_BUS_ERROR_NULL;
    int32_t status = 0;
    // ExecMainStatus 包含退出码或信号值
    sd_bus_get_property_trivial(bus, "org.freedesktop.systemd1", path,
                                "org.freedesktop.systemd1.Service", "ExecMainStatus", 
                                &error, 'i', &status);
    sd_bus_error_free(&error);
    return static_cast<int>(status);
}

static int get_exec_main_pid(sd_bus* bus, const char* path) {
    sd_bus_error error = SD_BUS_ERROR_NULL;
    uint32_t pid = 0;
    sd_bus_get_property_trivial(bus, "org.freedesktop.systemd1", path,
                                "org.freedesktop.systemd1.Service", "ExecMainPID", 
                                &error, 'u', &pid);
    sd_bus_error_free(&error);
    return static_cast<int>(pid);
}

static int on_property_changed(sd_bus_message *m, void *userdata, sd_bus_error *ret_error) {
    (void)ret_error;
    auto* self = static_cast<SystemdBusSource*>(userdata);
    const char* path = sd_bus_message_get_path(m);
    const char* iface;

    if (sd_bus_message_read(m, "s", &iface) < 0) return 0;
    if (strcmp(iface, "org.freedesktop.systemd1.Unit") != 0 &&
        strcmp(iface, "org.freedesktop.systemd1.Service") != 0) return 0;

    if (sd_bus_message_enter_container(m, 'a', "{sv}") < 0) return 0;

    std::string active_state;
    std::string result_state;
    int pid_hint = 0;
    int status_hint = 0;
    bool has_status = false;

    while (sd_bus_message_enter_container(m, 'e', "sv") > 0) {
        const char* prop_name;
        sd_bus_message_read(m, "s", &prop_name);

        if (strcmp(prop_name, "ActiveState") == 0) {
            const char* s;
            sd_bus_message_enter_container(m, 'v', "s");
            sd_bus_message_read(m, "s", &s);
            active_state = s;
            sd_bus_message_exit_container(m);
        } 
        else if (strcmp(prop_name, "Result") == 0) {
            const char* s;
            sd_bus_message_enter_container(m, 'v', "s");
            sd_bus_message_read(m, "s", &s);
            result_state = s;
            sd_bus_message_exit_container(m);
        }
        else if (strcmp(prop_name, "ExecMainPID") == 0) {
            uint32_t u_pid;
            sd_bus_message_enter_container(m, 'v', "u");
            sd_bus_message_read(m, "u", &u_pid);
            pid_hint = static_cast<int>(u_pid);
            sd_bus_message_exit_container(m);
        }
        else if (strcmp(prop_name, "ExecMainStatus") == 0) {
            int32_t i_status;
            sd_bus_message_enter_container(m, 'v', "i");
            sd_bus_message_read(m, "i", &i_status);
            status_hint = static_cast<int>(i_status);
            has_status = true;
            sd_bus_message_exit_container(m);
        }
        else {
            sd_bus_message_skip(m, "v");
        }
        sd_bus_message_exit_container(m);
    }
    sd_bus_message_exit_container(m);

    if (active_state == "failed") {
        self->OnUnitFailed(path, result_state, pid_hint, has_status ? status_hint : -1);
    }
    return 0;
}

// ============================================================================
// 成员实现
// ============================================================================

SystemdBusSource::SystemdBusSource() : bus_(nullptr), running_(false) {}
SystemdBusSource::~SystemdBusSource() { Stop(); }

bool SystemdBusSource::Start() {
    if (running_.exchange(true)) return true;
    if (sd_bus_default_system(&bus_) < 0) {
        running_ = false;
        return false;
    }

    sd_bus_add_match(bus_, NULL, "type='signal',sender='org.freedesktop.systemd1',"
                                 "interface='org.freedesktop.DBus.Properties',"
                                 "member='PropertiesChanged',arg0='org.freedesktop.systemd1.Unit'", 
                                 on_property_changed, this);
    
    sd_bus_add_match(bus_, NULL, "type='signal',sender='org.freedesktop.systemd1',"
                                 "interface='org.freedesktop.DBus.Properties',"
                                 "member='PropertiesChanged',arg0='org.freedesktop.systemd1.Service'", 
                                 on_property_changed, this);

    worker_ = std::thread(&SystemdBusSource::Loop, this);
    return true;
}

void SystemdBusSource::Stop() {
    if (!running_.exchange(false)) return;
    if (bus_) sd_bus_close(bus_);
    if (worker_.joinable()) worker_.join();
    if (bus_) { sd_bus_unref(bus_); bus_ = nullptr; }
}

void SystemdBusSource::OnUnitFailed(const std::string& path, std::string result, int pid_hint, int status_hint) {
    if (result.empty()) result = get_unit_result(bus_, path.c_str());
    if (result != "signal" && result != "core-dump" && result != "watchdog") return;

    int final_pid = (pid_hint > 0) ? pid_hint : get_exec_main_pid(bus_, path.c_str());
    int final_status = (status_hint >= 0) ? status_hint : get_exec_main_status(bus_, path.c_str());

    CrashInfo info;
    info.pid = final_pid;
    info.unit = get_unit_id_from_path(bus_, path.c_str());
    info.pname = info.unit;
    size_t last_dot = info.pname.find_last_of('.');
    if (last_dot != std::string::npos) info.pname = info.pname.substr(0, last_dot);

    // 精准解析 Reason
    if ((result == "core-dump" || result == "signal") && final_status > 0) {
        info.reason = signal_to_string(final_status);
        info.message = "Systemd service crashed with " + result + " (" + std::to_string(final_status) + ")";
    } else {
        info.reason = result;
        info.message = "Systemd service failed";
    }

    info.ts = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    LOGW("SystemdBusSource: [%s] crashed, PID: %d, Reason: %s", info.unit.c_str(), info.pid, info.reason.c_str());

    if (callback_) callback_(info);
}

void SystemdBusSource::Loop() {
    prctl(PR_SET_NAME, "PolBusScan", 0, 0, 0);
    while (running_.load(std::memory_order_relaxed)) {
        if (!bus_) break;
        int r = sd_bus_process(bus_, NULL);
        if (r < 0) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        if (r > 0) continue; 
        sd_bus_wait(bus_, 1000000);
    }
}

} // namespace polaris
} // namespace voyah