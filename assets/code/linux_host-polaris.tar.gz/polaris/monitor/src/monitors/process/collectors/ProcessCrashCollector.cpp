#include "monitors/process/collectors/ProcessCrashCollector.h"
#include "utils/Log.h"
#include <json/json.h>

namespace voyah {
namespace polaris {


ProcessCrashCollector::ProcessCrashCollector(BaseScheduler* scheduler, 
                                             std::unique_ptr<ICrashSource> source)
    : scheduler_(scheduler), source_(std::move(source)) {
    
    if (source_) {
        source_->SetCallback([this](const CrashInfo& info) {
            std::string json_str = this->BuildCrashJson(info);
            {
                std::lock_guard<std::mutex> lk(this->mu_);
                this->queue_.push({3001, std::move(json_str)});
            }
            // 唤醒 BaseScheduler
            if (this->scheduler_) {
                this->scheduler_->WakeUp();
            }
            LOGI("Event queued from %s", source_->Name().c_str());
        });
    }
}

/**
 * @brief 析构函数：确保监控源安全停止
 */
ProcessCrashCollector::~ProcessCrashCollector() {
    if (source_) {
        source_->Stop();
    }
}

/**
 * @brief 实现 ICollector 接口：向外交付数据
 */
CollectStatus ProcessCrashCollector::CollectOnce(CollectOutput& out) noexcept {
    std::lock_guard<std::mutex> lk(mu_);
    
    if (queue_.empty()) {
        return CollectStatus::kSkip;
    }

    auto ev = std::move(queue_.front());
    queue_.pop();

    out.event_id = ev.event_id;
    out.params_json = std::move(ev.json);

    return CollectStatus::kOk;
}

/**
 * @brief 私有辅助函数：封装 JSON 序列化逻辑
 */
std::string ProcessCrashCollector::BuildCrashJson(const CrashInfo& info) {
    Json::Value root;
    
    // 基础必选字段
    root["pid"] = info.pid;
    root["pname"] = info.pname;
    root["reason"] = info.reason;
    root["ts"] = (Json::UInt64)info.ts;

    // 扩展可选字段：仅当不为空时才序列化
    if (!info.unit.empty())    root["unit"] = info.unit;
    if (!info.exe.empty())     root["exe"] = info.exe;
    if (!info.message.empty()) root["message"] = info.message;
    if (!info.logf.empty())    root["logf"] = info.logf;

    // 静态元数据：标记采集方式以备云端分析
    if (source_) {
        root["source_type"] = source_->Name();
    }

    // 紧凑格式输出
    Json::FastWriter writer;
    std::string json_str = writer.write(root);
    
    // 去除 FastWriter 自动添加的尾部换行符
    if (!json_str.empty() && json_str.back() == '\n') {
        json_str.pop_back();
    }
    
    return json_str;
}

} // namespace polaris
} // namespace voyah