## 进程crash与systemd感知流程图
```mermaid
graph
    subgraph Process 部分
        A[用户进程 / 服务进程] -->|1. 发生致命信号| B{"收到致命信号<br>SIGSEGV / SIGABRT / SIGBUS / SIGFPE 等"}

        B -->|进程异常终止| C[内核处理信号<br>记录 segfault / oops 等信息]

        C --> D[写入 kernel 日志<br>dmesg / /proc/kmsg]

        C -->|"如果设置了 core_pattern"| E{"生成 core dump ?<br>由内核根据 /proc/sys/kernel/core_pattern 决定"}

        E -->|"直接写文件"| F[写入文件系统<br>例如 /cores/core.pid 或自定义路径]

        E -->|"pipe 到程序"| G["管道传输给 systemd-coredump<br>core_pattern = '|/usr/lib/systemd/systemd-coredump ...'"]
    end

    subgraph systemd 部分
        H[systemd PID 1] -->|收到内核 SIGCHLD| I[回收子进程<br>waitpid 获取退出状态]

        I --> J{进程被信号杀死 ?<br>WIFSIGNALED status}

        J -->|是| K[标记服务状态为 failed<br>ActiveState → failed<br>Result → signal / core-dump]

        J -->|"core_pattern 是 pipe 到 systemd-coredump"| L[激活 systemd-coredump.socket<br>启动 systemd-coredump@.service]

        L --> M[systemd-coredump 接收 core 数据<br>解析 / 收集元数据]

        M --> N[写入 journal 日志<br>包含 PID、EXE、信号、时间、backtrace 等]

        M -->|"如果启用持久化"| O[保存压缩的 .zst core 文件<br>/var/lib/systemd/coredump/...]

        K -->|"根据 Restart= 配置"| P[尝试重启服务<br>Restart=on-failure / always / on-abnormal]

        P -->|"执行 ExecStart="| Q[重新 fork + exec<br>启动新的进程实例]

        Q --> R[服务恢复<br>ActiveState → activating → active]
    end
    A~~~H
    %% 关键文件标注
    classDef file fill:#f9f,stroke:#333,stroke-width:2px;
    D:::file
    F:::file
    O:::file
    N:::file

    %% 组件标注
    classDef component fill:#bbf,stroke:#333;
    H:::component
    L:::component
    M:::component
```

## sd-journal 监听 crash 事件的原理图
```mermaid
graph TD
    A[进程崩溃<br>收到致命信号<br>SIGSEGV / SIGABRT / SIGBUS 等] --> B[内核处理<br>终止进程<br>产生 core dump 数据]

    B --> C1[写入 dmesg / kernel log buffer<br>（几乎瞬间）]
    B --> C2[根据 /proc/sys/kernel/core_pattern<br>生成 core dump 或 pipe]

    C2 -->|pipe 到程序| D[systemd-coredump<br>接收 core 数据<br>解析 / 收集元数据]

    D --> E[写入 journald<br>核心日志条目<br>包含：MESSAGE、COREDUMP_* 字段]

    C1 -->|内核日志也进入 journald| E

    subgraph "journald 内部"
        E --> F[journald 存储<br>二进制日志文件<br>并维护索引]
        F --> G[输出通道<br>Unix socket / eventfd<br>供消费者读取]
    end

    subgraph "监控程序（使用 sd-journal API）"
        H[sd_journal_open<br>打开 journal] --> I[sd_journal_add_match<br>添加匹配条件<br>如 COREDUMP_SIGNAL / dumped core / _SYSTEMD_UNIT=systemd-coredump.service]
        I --> J[sd_journal_seek_tail<br>定位到最新位置]
        J --> K[sd_journal_wait<br>阻塞等待新日志事件<br>（基于 epoll / fd 可读）]
        K -->|新日志到来| L[sd_journal_get_data<br>读取字段<br>_PID / COREDUMP_SIGNAL / MESSAGE / COREDUMP_EXE / COREDUMP_STORAGE 等]
        L --> M[业务逻辑<br>解析 PID、信号、进程名、上报 / 记录 / 告警]
    end

    G --> K

    style A fill:#ffcccc,stroke:#f66
    style D fill:#ccffcc,stroke:#6c6
    style H fill:#ccccff,stroke:#66c
```
```mermaid
flowchart LR
  %% =============================================================================
  %% systemd ecosystem (precise, crash + journal + coredump + consumers)
  %% =============================================================================

  %% ---------------- Kernel / procfs ----------------
  subgraph KERNEL["Kernel / Procfs / Syscalls"]
    SIG["Fatal signal delivered<br/>(SIGSEGV/SIGABRT/SIGBUS/SIGFPE/...)"]
    KILL["Kernel terminates task<br/>do_exit + signal accounting"]
    KMSG["Kernel ring buffer<br/>dmesg (/dev/kmsg, /proc/kmsg)"]
    CORECFG["/proc/sys/kernel/core_pattern<br/>and RLIMIT_CORE"]
    COREFILE["Core file written<br/>(filesystem)"]
    COREPIPE["Core piped to userspace helper<br/>via core_pattern = |..."]
    SIG --> KILL
    KILL --> KMSG
    KILL --> CORECFG
    CORECFG --> COREFILE
    CORECFG --> COREPIPE
  end

  %% ---------------- systemd PID1 + service manager ----------------
  subgraph PID1["systemd (PID 1) / Service Manager"]
    SPAWN["fork/exec service process<br/>(ExecStart=...)"]
    SUP["Supervisor state machine<br/>(unit.c/service.c)"]
    SIGCHLD["SIGCHLD from kernel"]
    WAIT["waitpid() collects status<br/>(exit code / signal / core)"]
    FAIL["Update unit state<br/>ActiveState=failed<br/>Result=signal/core-dump"]
    RESTART{"Restart policy?<br/>Restart=on-failure/always/on-abnormal"}
    BACKOFF["RestartSec / StartLimitBurst<br/>StartLimitIntervalSec"]
    SPAWN --> SUP
    SIGCHLD --> WAIT
    WAIT --> FAIL
    FAIL --> RESTART
    RESTART -->|yes| BACKOFF --> SPAWN
    RESTART -->|no| SUP
  end

  %% ---------------- journald ----------------
  subgraph JOURNALD["systemd-journald (logging daemon)"]
    JD_SOCK["/run/systemd/journal/socket<br/>AF_UNIX datagram (native)"]
    JD_STREAM["/run/systemd/journal/stdout<br/>stream fd for services<br/>(stdout/stderr capture)"]
    JD_KMSG["/dev/kmsg reader<br/>(kernel messages)"]
    JD_IN["Input pipeline<br/>rate-limit / parse / metadata"]
    JD_STORE["Journal store<br/>/run/log/journal (volatile)<br/>/var/log/journal (persistent)"]
    JD_IDX["Indexes / hash tables<br/>for field lookup"]
    JD_NOTIFY["Notify readers<br/>sd-journal fd becomes readable<br/>(eventfd/pipe)"]
    JD_SOCK --> JD_IN
    JD_STREAM --> JD_IN
    JD_KMSG --> JD_IN
    JD_IN --> JD_STORE --> JD_IDX --> JD_NOTIFY
  end

  %% ---------------- systemd-coredump ----------------
  subgraph COREDUMP["systemd-coredump (core handler)"]
    CDSOCK["systemd-coredump.socket<br/>(AF_UNIX stream / datagram)<br/>activated by PID1"]
    CDUNIT["systemd-coredump@.service<br/>(socket-activated instance)"]
    CDIN["Receives core bytes + metadata<br/>(pid, uid, exe, signal, cgroup, unit)"]
    CDMETA["Collect metadata<br/>maps, cmdline, cgroup, unit, limits"]
    CDWRITE["Store core (optional)<br/>/var/lib/systemd/coredump/*.zst"]
    CDJ["Emit journal entry<br/>MESSAGE + COREDUMP_* fields"]
    CDSOCK --> CDUNIT --> CDIN --> CDMETA
    CDMETA --> CDWRITE
    CDMETA --> CDJ
  end

  %% ---------------- Journal consumers ----------------
  subgraph CONSUMERS["Journal consumers"]
    JCTL["journalctl<br/>(reads journal files)"]
    API["sd-journal API consumer<br/>(sd_journal_open / add_match / wait / get_data)"]
    FW["systemd-journal-remote / forwarders<br/>(optional)"]
    JCTL -->|"reads"| JD_STORE
    API -->|"reads + waits"| JD_NOTIFY
    FW -->|"reads"| JD_STORE
  end

  %% =============================================================================
  %% Cross edges (crash flow wiring)
  %% =============================================================================

  %% service crash -> PID1 notices
  SIGCHLD -. "delivered after task exit" .-> PID1
  KILL --> SIGCHLD

  %% kernel log -> journald
  KMSG --> JD_KMSG

  %% service stdout/stderr -> journald (if StandardOutput=journal / journal+console)
  SUP -->|"sets stdout/stderr fds"| JD_STREAM

  %% core_pattern pipe -> systemd-coredump (common default on systemd distros)
  COREPIPE -->|"pipe payload"| CDIN

  %% PID1 socket-activates systemd-coredump
  FAIL -->|"on core-dump path / configured"| CDSOCK

  %% coredump metadata + journal entry
  CDJ --> JD_SOCK --> JD_IN

  %% PID1 also logs unit failure to journald (manager logs)
  FAIL -->|"manager log record"| JD_SOCK

  %% =============================================================================
  %% Styling
  %% =============================================================================
  classDef kernel fill:#fff2cc,stroke:#b8860b,stroke-width:1px;
  classDef sysd fill:#dbe8ff,stroke:#4c6ef5,stroke-width:1px;
  classDef journal fill:#e6ffed,stroke:#2f9e44,stroke-width:1px;
  classDef file fill:#ffd6e7,stroke:#c2255c,stroke-width:1px;

  class SIG,KILL,KMSG,CORECFG,COREFILE,COREPIPE kernel;
  class PID1,SPAWN,SUP,SIGCHLD,WAIT,FAIL,RESTART,BACKOFF sysd;
  class JOURNALD,JD_SOCK,JD_STREAM,JD_KMSG,JD_IN,JD_STORE,JD_IDX,JD_NOTIFY journal;
  class CDWRITE file;
```