#pragma once
#include "ICrashSource.h"
#include <systemd/sd-bus.h>
#include <thread>
#include <atomic>

namespace voyah {
namespace polaris {

class SystemdBusSource : public ICrashSource {
public:
    SystemdBusSource();
    ~SystemdBusSource() override;

    void SetCallback(OnCrashCallback cb) override { callback_ = cb; }
    bool Start() override;
    void Stop() override;
    std::string Name() const override { return "SystemdBusSource"; }
    // 内部处理函数 (public 为了让 C 回调能访问)
    void OnUnitFailed(const std::string& path, std::string result, int pid_hint, int status_hint);

private:
    void Loop(); // 工作线程循环

    sd_bus* bus_{nullptr};
    std::thread worker_;
    std::atomic<bool> running_{false};
    
    // 持有回调实例
    OnCrashCallback callback_;
};

} // polaris
} // voyah