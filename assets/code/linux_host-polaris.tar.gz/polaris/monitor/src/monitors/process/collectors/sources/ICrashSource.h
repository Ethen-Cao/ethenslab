#pragma once
#include <string>
#include <functional>
#include <cstdint>

namespace voyah {
namespace polaris {

// 1. 标准化的崩溃信息
struct CrashInfo {
    int pid = 0;             
    std::string pname;       // 进程名
    std::string unit;        // Unit 名
    std::string exe;         // 执行路径
    std::string reason;      // 原因 (signal/core-dump)
    std::string message;     // 详细信息
    std::string logf;        // coredump 文件路径 (可选)
    uint64_t ts = 0;         // 时间戳
};

// 2. 抽象接口
class ICrashSource {
public:
    virtual ~ICrashSource() = default;

    // 定义回调类型
    using OnCrashCallback = std::function<void(const CrashInfo&)>;

    // 注册回调
    virtual void SetCallback(OnCrashCallback cb) = 0;
    
    virtual bool Start() = 0;
    virtual void Stop() = 0;
    virtual std::string Name() const = 0;
};

} // polaris
} // voyah