#pragma once

#include "core/IMonitor.h"
#include "core/BaseScheduler.h"
#include <memory>

namespace voyah {
namespace polaris {

class ProcessScheduler;

class ProcessMonitor final : public IMonitor {
public:
    ProcessMonitor();
    ~ProcessMonitor() override;

    std::string Name() const override;
    bool Init(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) override;
    void Start() override;
    void Stop() override;

private:
    // 使用通用调度器
    std::unique_ptr<BaseScheduler> scheduler_;
};

} // namespace polaris
} // namespace voyah