#include "monitors/process/ProcessMonitor.h"
#include "monitors/process/collectors/ProcessCrashCollector.h"
#include "monitors/process/collectors/sources/SystemdBusSource.h"
#include "utils/Log.h"

namespace voyah {
namespace polaris {

ProcessMonitor::ProcessMonitor() = default;
ProcessMonitor::~ProcessMonitor() = default;

// 返回类型改为 std::string，去掉 noexcept
std::string ProcessMonitor::Name() const { 
    return "ProcessMonitor"; 
}

bool ProcessMonitor::Init(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) {
    (void)cfg;
    
    // 实例化 BaseScheduler，命名为 "ProcSched" (用于线程名)
    scheduler_ = std::make_unique<BaseScheduler>(reporter, "ProcSched");

    // 组装组件
    auto bus_source = std::make_unique<SystemdBusSource>();
    
    // 注入 scheduler 指针，支持 WakeUp
    auto crash_collector = std::make_unique<ProcessCrashCollector>(
        scheduler_.get(), 
        std::move(bus_source)
    );

    scheduler_->Add(std::move(crash_collector));
    return true;
}

void ProcessMonitor::Start() {
    if (scheduler_) scheduler_->Start();
}

void ProcessMonitor::Stop() {
    if (scheduler_) scheduler_->Stop();
}

}
}