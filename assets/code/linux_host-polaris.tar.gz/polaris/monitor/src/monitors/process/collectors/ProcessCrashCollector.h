#pragma once
#include "core/ICollector.h"
#include "core/BaseScheduler.h" // 引用 BaseScheduler
#include "monitors/process/collectors/sources/ICrashSource.h"
#include <queue>
#include <mutex>
#include <memory>

namespace voyah {
namespace polaris {

class ProcessCrashCollector : public ICollector {
public:
    // 注意：这里接收 BaseScheduler 指针
    ProcessCrashCollector(BaseScheduler* scheduler, std::unique_ptr<ICrashSource> source);
    ~ProcessCrashCollector() override;

    const char* Name() const noexcept override { return "ProcessCrashCollector"; }

    CollectStatus CollectOnce(CollectOutput& out) noexcept override;

    void StartAt(std::chrono::steady_clock::time_point now) noexcept override {
        (void)now;
        if (source_) source_->Start();
    }

    // [关键适配]：如果队列不为空，说明“到期”了，需要处理
    bool Due(std::chrono::steady_clock::time_point now) const noexcept override { 
        (void)now; 
        std::lock_guard<std::mutex> lk(mu_);
        return !queue_.empty();
    }
    
    void OnFired(std::chrono::steady_clock::time_point now) noexcept override { (void)now; }

    // 事件驱动型，没有预定的下一次时间，返回 max 让 Scheduler 仅依赖 WakeUp 或其他 Collector
    std::chrono::steady_clock::time_point NextDue() const noexcept override { 
        return std::chrono::steady_clock::time_point::max(); 
    }

private:
    std::string BuildCrashJson(const CrashInfo& info);

    BaseScheduler* scheduler_; // 依赖 BaseScheduler
    std::unique_ptr<ICrashSource> source_;

    struct EventWrapper {
        uint64_t event_id;
        std::string json;
    };
    
    mutable std::mutex mu_; // mutable 为了在 const Due() 中使用
    std::queue<EventWrapper> queue_;
};

} // polaris
} // voyah