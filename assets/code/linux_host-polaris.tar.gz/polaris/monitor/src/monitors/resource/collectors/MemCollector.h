#pragma once

#include "core/IntervalCollector.h"
#include <chrono>
#include <string>

namespace voyah {
namespace polaris {

class MemCollector : public IntervalCollector {
public:
    explicit MemCollector(std::chrono::milliseconds interval)
        : IntervalCollector(interval) {}

    const char* Name() const noexcept override { return "MemCollector"; }

    CollectStatus CollectOnce(CollectOutput& out) noexcept override;

private:
    std::string BuildParamsJson(
        uint64_t total_mb,
        uint64_t available_mb,
        uint64_t used_mb,
        double usage_percent) const noexcept;

    bool ReadMemInfo(
        uint64_t& total_kb,
        uint64_t& available_kb,
        uint64_t& free_kb) const noexcept;
};

}  // namespace polaris
}  // namespace voyah