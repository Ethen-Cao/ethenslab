#pragma once
#include "core/IMonitor.h"
#include <memory>
#include <string>

namespace voyah {
namespace polaris {

// [Change 1] 前向声明改为核心调度器
class BaseScheduler;

class ResourceMonitor final : public IMonitor {
public:
    ResourceMonitor();
    ~ResourceMonitor() override;

    std::string Name() const override;
    
    bool Init(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) override;
    void Start() override;
    void Stop() override;

private:
    // [Change 2] 持有通用调度器的实例
    std::unique_ptr<BaseScheduler> scheduler_;
};

} // namespace polaris
} // namespace voyah