#include "monitors/resource/collectors/MemCollector.h"
#include "polaris/defs/EventIds.h"
#include "utils/Log.h"

#include <fstream>
#include <sstream>
#include <unordered_map>
#include <iomanip>
#include <cmath>

namespace voyah {
namespace polaris {

bool MemCollector::ReadMemInfo(
    uint64_t& total_kb,
    uint64_t& available_kb,
    uint64_t& free_kb) const noexcept
{
    std::ifstream file("/proc/meminfo");
    if (!file.is_open()) {
        LOGW("MemCollector: cannot open /proc/meminfo");
        return false;
    }

    std::unordered_map<std::string, uint64_t> mem_map;
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string key;
        uint64_t value{};
        std::string unit;
        iss >> key >> value >> unit;
        if (key.empty()) continue;
        if (!key.empty() && key.back() == ':') {
            key.pop_back();
        }
        mem_map[key] = value;
    }

    auto get = [&](const std::string& k, uint64_t& v) -> bool {
        auto it = mem_map.find(k);
        if (it != mem_map.end()) {
            v = it->second;
            return true;
        }
        return false;
    };

    bool ok = true;
    ok &= get("MemTotal", total_kb);
    ok &= get("MemAvailable", available_kb);
    ok &= get("MemFree", free_kb);

    if (!ok) {
        LOGW("MemCollector: missing some key fields in /proc/meminfo");
    }

    return ok && total_kb > 0;
}

std::string MemCollector::BuildParamsJson(
    uint64_t total_mb,
    uint64_t available_mb,
    uint64_t used_mb,
    double usage_percent) const noexcept
{
    std::ostringstream os;
        os << std::fixed << std::setprecision(1);
        os << "{"
        << "\"total_mb\":"      << total_mb      << ","
        << "\"available_mb\":"  << available_mb  << ","
        << "\"used_mb\":"       << used_mb       << ","
        << "\"usage_percent\":" << usage_percent
        << "}";
        return os.str();
}

CollectStatus MemCollector::CollectOnce(CollectOutput& out) noexcept
{
    uint64_t total_kb     = 0;
    uint64_t available_kb = 0;
    uint64_t free_kb      = 0;

    if (!ReadMemInfo(total_kb, available_kb, free_kb)) {
        return CollectStatus::kError;
    }

    if (total_kb == 0) {
        return CollectStatus::kSkip;
    }

    double used_kb = static_cast<double>(total_kb - available_kb);
    double usage_percent = (used_kb / static_cast<double>(total_kb)) * 100.0;

    uint64_t total_mb     = total_kb / 1024;
    uint64_t available_mb = available_kb / 1024;
    uint64_t used_mb      = static_cast<uint64_t>(used_kb / 1024);
    usage_percent         = std::round(usage_percent * 10.0) / 10.0;  // 保留一位小数

    out.event_id    = static_cast<uint64_t>(EventId::PVM_SYS_MEMORY_LOAD_STAT);  // 请根据你的 EventId 枚举调整
    out.params_json = BuildParamsJson(total_mb, available_mb, used_mb, usage_percent);

    return CollectStatus::kOk;
}

}  // namespace polaris
}  // namespace voyah