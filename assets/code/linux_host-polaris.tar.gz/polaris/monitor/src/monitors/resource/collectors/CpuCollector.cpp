#include "monitors/resource/collectors/CpuCollector.h"

#include "polaris/defs/EventIds.h"
#include "utils/Log.h"
#include <vector>
#include <fstream>
#include <sstream>
#include <iomanip>

namespace voyah {
namespace polaris {

CpuCollector::CpuCollector(std::chrono::milliseconds interval)
    : IntervalCollector(interval) {}

bool CpuCollector::ReadCpuLine(std::array<uint64_t, 8>& ticks) noexcept {
  // /proc/stat: cpu user nice system idle iowait irq softirq steal ...
  std::ifstream ifs("/proc/stat");
  if (!ifs.is_open()) return false;

  std::string line;
  if (!std::getline(ifs, line)) return false;

  std::istringstream iss(line);
  std::string cpu;
  iss >> cpu;
  if (cpu != "cpu") return false;

  // 只取前 8 个关键字段
  for (size_t i = 0; i < ticks.size(); i++) {
    uint64_t v = 0;
    if (!(iss >> v)) return false;
    ticks[i] = v;
  }
  return true;
}

std::string CpuCollector::BuildParamsJson(double usage,
                                         double user,
                                         double system,
                                         double idle,
                                         double iowait,
                                         double irq,
                                         double softirq,
                                         double steal) {
  // 生成一个紧凑 JSON object（不依赖 jsoncpp）
  std::ostringstream os;
  os.setf(std::ios::fixed);
  os << std::setprecision(3);
  os << "{"
     << "\"usage\":"   << usage   << ","
     << "\"user\":"    << user    << ","
     << "\"system\":"  << system  << ","
     << "\"idle\":"    << idle    << ","
     << "\"iowait\":"  << iowait  << ","
     << "\"irq\":"     << irq     << ","
     << "\"softirq\":" << softirq << ","
     << "\"steal\":"   << steal
     << "}";
  return os.str();
}

CollectStatus CpuCollector::CollectOnce(CollectOutput& out) noexcept {
  std::array<uint64_t, 8> cur{};
  if (!ReadCpuLine(cur)) {
    LOGW("CpuCollector: failed to read /proc/stat");
    return CollectStatus::kError;
  }

  if (!has_prev_) {
    prev_ = cur;
    has_prev_ = true;
    return CollectStatus::kSkip; // 第一次无差分
  }

  std::array<uint64_t, 8> d{};
  uint64_t total = 0;
  for (size_t i = 0; i < d.size(); i++) {
    d[i] = (cur[i] >= prev_[i]) ? (cur[i] - prev_[i]) : 0;
    total += d[i];
  }
  prev_ = cur;

  if (total == 0) return CollectStatus::kSkip;

  const double total_d = static_cast<double>(total);

  const double user    = 100.0 * (static_cast<double>(d[0] + d[1]) / total_d); // user+nice
  const double system  = 100.0 * (static_cast<double>(d[2]) / total_d);
  const double idle    = 100.0 * (static_cast<double>(d[3]) / total_d);
  const double iowait  = 100.0 * (static_cast<double>(d[4]) / total_d);
  const double irq     = 100.0 * (static_cast<double>(d[5]) / total_d);
  const double softirq = 100.0 * (static_cast<double>(d[6]) / total_d);
  const double steal   = 100.0 * (static_cast<double>(d[7]) / total_d);

  const double idle_all = idle + iowait;
  const double usage    = 100.0 - idle_all; // 经典定义：total - idle(iowait 포함)

  out.event_id = static_cast<uint64_t>(EventId::PVM_SYS_CPU_LOAD_STAT);
  out.params_json = BuildParamsJson(usage, user, system, idle, iowait, irq, softirq, steal);
  return CollectStatus::kOk;
}

} // namespace polaris
} // namespace voyah
