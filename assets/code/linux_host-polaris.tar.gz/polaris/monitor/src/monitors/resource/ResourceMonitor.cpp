#include "monitors/resource/ResourceMonitor.h"
// [Change 1] 包含通用调度器的头文件
#include "core/BaseScheduler.h" 
#include "monitors/resource/collectors/CpuCollector.h"
#include "monitors/resource/collectors/MemCollector.h"
// #include "monitors/resource/collectors/LoadCollector.h"
#include "core/Config.h"
#include "utils/Log.h"

namespace voyah {
namespace polaris {

ResourceMonitor::ResourceMonitor() = default;
ResourceMonitor::~ResourceMonitor() = default;

// 返回类型改为 std::string
std::string ResourceMonitor::Name() const { 
    return "ResourceMonitor"; 
}

bool ResourceMonitor::Init(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) {
    LOGI("Initializing ResourceMonitor...");

    // [Change 2] 实例化 BaseScheduler
    // 参数1: reporter
    // 参数2: 调度器名称 (用于线程命名，例如 "ResSched")
    scheduler_ = std::make_unique<BaseScheduler>(reporter, "ResSched");

    // 注册 CPU 采集器
    if (cfg.resource.enable_cpu) {
        // CpuCollector 继承自 IntervalCollector -> 继承自 ICollector
        // 所以可以直接 Add 进去
        scheduler_->Add(std::make_unique<CpuCollector>(
            std::chrono::milliseconds(cfg.resource.cpu_interval_ms)
        ));
    }
    
    // 注册 Memory 采集器
    if (cfg.resource.enable_mem) {
        scheduler_->Add(std::make_unique<MemCollector>(
            std::chrono::milliseconds(cfg.resource.mem_interval_ms)
        ));
    }
    
    // 注册 LoadAvg 采集器 (如果需要)
    // if (cfg.resource.enable_load) {
    //     scheduler_->Add(std::make_unique<LoadCollector>(
    //         std::chrono::milliseconds(cfg.resource.load_interval_ms)
    //     ));
    // }

    return true;
}

void ResourceMonitor::Start() {
    if (scheduler_) {
        LOGI("Starting ResourceMonitor...");
        scheduler_->Start();
    }
}

void ResourceMonitor::Stop() {
    if (scheduler_) {
        LOGI("Stopping ResourceMonitor...");
        scheduler_->Stop();
    }
}

} // namespace polaris
} // namespace voyah