#pragma once
#include "core/IntervalCollector.h"

#include <array>
#include <cstdint>

namespace voyah {
namespace polaris {

class CpuCollector final : public IntervalCollector {
public:
  explicit CpuCollector(std::chrono::milliseconds interval);

  const char* Name() const noexcept override { return "CpuCollector"; }
  CollectStatus CollectOnce(CollectOutput& out) noexcept override;

private:
  bool ReadCpuLine(std::array<uint64_t, 8>& ticks) noexcept;
  static std::string BuildParamsJson(double usage,
                                    double user,
                                    double system,
                                    double idle,
                                    double iowait,
                                    double irq,
                                    double softirq,
                                    double steal);

private:
  bool has_prev_ = false;
  std::array<uint64_t, 8> prev_{};
};

} // namespace polaris
} // namespace voyah
