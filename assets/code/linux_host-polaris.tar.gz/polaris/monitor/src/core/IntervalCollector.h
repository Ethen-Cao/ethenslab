#pragma once
#include "ICollector.h"

#include <chrono>

namespace voyah {
namespace polaris {

class IntervalCollector : public ICollector {
public:
  explicit IntervalCollector(std::chrono::milliseconds interval)
      : interval_(interval) {
    if (interval_.count() <= 0) interval_ = std::chrono::milliseconds(1);
  }

  void StartAt(std::chrono::steady_clock::time_point now) noexcept override {
    started_ = true;
    // 启动后立即允许运行一次（CPU Collector 首次会 kSkip）
    next_due_ = now;
  }

  bool Due(std::chrono::steady_clock::time_point now) const noexcept override {
    // P2: 未 start 时不允许跑，避免 epoch 触发风暴
    if (!started_) return false;
    return now >= next_due_;
  }

void OnFired(std::chrono::steady_clock::time_point now) noexcept override {
  if (!started_) {
    started_ = true;
    next_due_ = now + interval_;
    return;
  }

  // Normal: keep phase (next_due_ += interval)
  auto candidate = next_due_ + interval_;

  // Late (or exactly on boundary): resync to now + interval (no catch-up)
  next_due_ = (candidate <= now) ? (now + interval_) : candidate;
}


  std::chrono::steady_clock::time_point NextDue() const noexcept override {
    return next_due_;
  }

protected:
  std::chrono::milliseconds interval_;
  std::chrono::steady_clock::time_point next_due_{};
  bool started_{false};
};

} // namespace polaris
} // namespace voyah
