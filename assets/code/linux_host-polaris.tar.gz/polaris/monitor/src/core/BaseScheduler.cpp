#include "core/BaseScheduler.h"
#include "utils/Log.h"
#include <chrono>
#include <algorithm>

#if defined(__linux__)
#include <sys/prctl.h>
#endif

namespace voyah {
namespace polaris {

BaseScheduler::BaseScheduler(std::shared_ptr<PolarisReporter> reporter, std::string name)
    : name_(std::move(name)), reporter_(std::move(reporter)) {}

BaseScheduler::~BaseScheduler() {
    Stop();
}

void BaseScheduler::Add(std::unique_ptr<ICollector> c) {
    if (!c) return;
    if (running_.load(std::memory_order_relaxed)) {
        LOGW("%s: Cannot add collector %s while running", name_.c_str(), c->Name());
        return;
    }
    collectors_.push_back(std::move(c));
}

void BaseScheduler::Start() {
    if (running_.exchange(true)) return;

    // 初始化所有采集器的启动时间
    const auto now = std::chrono::steady_clock::now();
    for (auto& c : collectors_) {
        c->StartAt(now);
    }

    worker_ = std::thread([this]() {
#if defined(__linux__)
        std::string thread_name = "Pol" + name_;
        if (thread_name.length() > 15) thread_name = thread_name.substr(0, 15);
        prctl(PR_SET_NAME, thread_name.c_str(), 0, 0, 0);
#endif
        this->Loop();
    });

    LOGI("%s: Scheduler started with %zu collectors", name_.c_str(), collectors_.size());
}

void BaseScheduler::Stop() {
    if (!running_.exchange(false)) return;

    // 唤醒线程以便退出
    WakeUp();

    if (worker_.joinable()) {
        worker_.join();
    }
    LOGI("%s: Scheduler stopped", name_.c_str());
}

void BaseScheduler::WakeUp() {
    {
        std::lock_guard<std::mutex> lk(mu_);
        pending_wakeup_ = true;
    }
    cv_.notify_one();
}

void BaseScheduler::Loop() {
    using clock = std::chrono::steady_clock;
    
    // 默认休眠兜底 (防止所有 collector 都是事件型导致 wait 时间无限长)
    constexpr auto kMaxSleep = std::chrono::seconds(5); 

    while (running_.load(std::memory_order_relaxed)) {
        const auto now = clock::now();
        
        // 1. 遍历执行
        // 无论是由时间触发还是 WakeUp 触发，我们都检查一遍谁 Due 了
        for (auto& c : collectors_) {
            try {
                if (c->Due(now)) {
                    CollectOutput out{};
                    CollectStatus st = c->CollectOnce(out);
                    
                    if (st == CollectStatus::kOk && reporter_) {
                        reporter_->Report(out.event_id, out.params_json);
                    }
                    
                    // 无论成功失败，都需要更新内部状态 (如 next_due)
                    c->OnFired(clock::now());
                }
            } catch (const std::exception& e) {
                LOGE("%s: Collector %s exception: %s", name_.c_str(), c->Name(), e.what());
            } catch (...) {
                LOGE("%s: Collector %s unknown exception", name_.c_str(), c->Name());
            }
        }

        // 2. 计算下一次唤醒时间
        auto next_wake = now + kMaxSleep;
        
        for (const auto& c : collectors_) {
            auto nd = c->NextDue();
            if (nd < next_wake) {
                next_wake = nd;
            }
        }

        // 3. 防御性检查：不要 wait 过去的时间
        if (next_wake < clock::now()) {
            next_wake = clock::now();
        }

        // 4. 等待 (混合动力核心：等待时间到达 OR 被 WakeUp 唤醒)
        std::unique_lock<std::mutex> lk(mu_);
        
        // 我们在 wait 之前就清除 pending 标记
        // 这样如果在处理期间又来了 WakeUp，下一次循环不会错过
        bool expected = true;
        bool changed = pending_wakeup_.compare_exchange_strong(expected, false);
        (void)changed; // 消除 unused warning

        cv_.wait_until(lk, next_wake, [this]() {
            // 如果停止了，或者有新的唤醒请求，立即返回
            return !running_.load(std::memory_order_relaxed) || pending_wakeup_.load();
        });
    }
}

} // namespace polaris
} // namespace voyah