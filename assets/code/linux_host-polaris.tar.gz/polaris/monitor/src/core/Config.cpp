#include "core/Config.h"

namespace voyah {
namespace polaris {

Config LoadConfigOrDefault(const std::string& path) {
  Config cfg;
  cfg.config_path = path;
  // v1.1 最小可跑：先不解析文件，直接用默认值
  return cfg;
}

} // namespace polaris
} // namespace voyah
