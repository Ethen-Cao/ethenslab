#pragma once

#include "core/IMonitor.h"
#include "core/Config.h" // 确保包含 Config 定义
#include <vector>
#include <memory>

namespace voyah {
namespace polaris {

class PolarisReporter; // 前向声明

class ModuleManager {
public:
    ModuleManager() = default;
    ~ModuleManager();

    // 注册模块（接管 unique_ptr 所有权）
    void Register(std::unique_ptr<IMonitor> module);

    // 初始化所有模块
    // return: true 表示所有模块初始化成功
    bool InitAll(const Config& cfg, std::shared_ptr<PolarisReporter> reporter);

    // 启动所有模块
    void StartAll();

    // 停止所有模块（反序停止）
    void StopAll();

private:
    std::vector<std::unique_ptr<IMonitor>> modules_;
};

} // namespace polaris
} // namespace voyah