#include "core/ModuleManager.h"
#include "core/PolarisReporter.h"
#include "utils/Log.h"

namespace voyah {
namespace polaris {

ModuleManager::~ModuleManager() {
    StopAll();
    modules_.clear();
}

void ModuleManager::Register(std::unique_ptr<IMonitor> module) {
    if (module) {
        // 可以在这里打印日志，方便调试加载顺序
        // LOGD("Registering module: %s", module->Name().c_str());
        modules_.push_back(std::move(module));
    }
}

bool ModuleManager::InitAll(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) {
    bool all_success = true;

    for (const auto& module : modules_) {
        LOGI("Initializing module: %s", module->Name().c_str());
        
        if (!module->Init(cfg, reporter)) {
            LOGE("Failed to initialize module: %s", module->Name().c_str());
            all_success = false;
            // 策略选择：
            // 1. 遇到失败立即停止？ -> return false;
            // 2. 标记失败但继续尝试初始化其他模块？ -> all_success = false;
            // 这里我们选择策略2，并在最后统一返回结果，方便排查多个错误。
        }
    }
    
    return all_success;
}

void ModuleManager::StartAll() {
    for (const auto& module : modules_) {
        LOGI("Starting module: %s", module->Name().c_str());
        module->Start();
    }
}

void ModuleManager::StopAll() {
    // [关键] 反序停止
    // 这是一个良好的实践：后启动的先停止（LIFO）。
    // 避免因为模块间可能的依赖关系（虽然目前设计是独立的）导致崩溃。
    for (auto it = modules_.rbegin(); it != modules_.rend(); ++it) {
        auto& module = *it;
        if (module) {
            LOGI("Stopping module: %s", module->Name().c_str());
            module->Stop();
        }
    }
}

} // namespace polaris
} // namespace voyah