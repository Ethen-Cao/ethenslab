#pragma once

#include <string>
#include <chrono>

namespace voyah {
namespace polaris {

// 采集结果状态
enum class CollectStatus {
    kOk,    // 成功采集并产生数据
    kSkip,  // 本次不需要采集（或无数据）
    kError  // 采集发生错误
};

// 采集输出数据
struct CollectOutput {
    uint64_t event_id;
    std::string params_json;
};

class ICollector {
public:
    virtual ~ICollector() = default;

    // 1. 采集器名称 (用于日志)
    virtual const char* Name() const noexcept = 0;

    // 2. 核心采集动作
    virtual CollectStatus CollectOnce(CollectOutput& out) noexcept = 0;

    // 3. 生命周期挂钩
    // 调度器启动时调用，传入当前时间
    virtual void StartAt(std::chrono::steady_clock::time_point now) noexcept = 0;

    // 4. 调度判定
    // 检查当前时间是否应该执行采集 (周期性采集器检查时间，事件型采集器检查队列是否为空)
    virtual bool Due(std::chrono::steady_clock::time_point now) const noexcept = 0;

    // 5. 状态更新
    // 采集完成后调用，用于更新下一次采集时间
    virtual void OnFired(std::chrono::steady_clock::time_point now) noexcept = 0;

    // 6. 下一次唤醒时间预测
    // 用于计算线程休眠时间。如果是纯事件驱动，返回 time_point::max()
    virtual std::chrono::steady_clock::time_point NextDue() const noexcept = 0;
};

} // namespace polaris
} // namespace voyah