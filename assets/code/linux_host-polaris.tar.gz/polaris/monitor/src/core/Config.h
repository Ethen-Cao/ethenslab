#pragma once
#include <string>

namespace voyah {
namespace polaris {

struct ResourceConfig {
    bool enable_cpu = true;
    int cpu_interval_ms = 3000;
    
    bool enable_mem = true;
    int mem_interval_ms = 5000;
    
    bool enable_load = true;
    int load_interval_ms = 5000;
};

struct Config {
    // [关键修复] 添加 config_path 成员
    std::string config_path; 

    ResourceConfig resource;
    
    // 静态加载函数声明
    static Config Load(const std::string& path);
};

} // namespace polaris
} // namespace voyah