#pragma once

#include "core/ICollector.h"
#include "core/PolarisReporter.h"
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>

namespace voyah {
namespace polaris {

class BaseScheduler {
public:
    explicit BaseScheduler(std::shared_ptr<PolarisReporter> reporter, std::string name);
    virtual ~BaseScheduler();

    // 添加采集器 (必须在 Start 前调用)
    void Add(std::unique_ptr<ICollector> c);

    // 启动调度线程
    void Start();

    // 停止调度线程
    void Stop();

    // [核心特性] 外部唤醒：用于事件驱动型采集器通知调度器“有活干了”
    void WakeUp();

protected:
    void Loop();

private:
    std::string name_;
    std::shared_ptr<PolarisReporter> reporter_;
    std::vector<std::unique_ptr<ICollector>> collectors_;

    std::thread worker_;
    std::mutex mu_;
    std::condition_variable cv_;
    
    std::atomic<bool> running_{false};
    std::atomic<bool> pending_wakeup_{false}; // 唤醒标记
};

} // namespace polaris
} // namespace voyah