#pragma once
#include <memory>
#include <string>

namespace voyah {
namespace polaris {

struct Config;
class PolarisReporter;

class IMonitor {
public:
  virtual ~IMonitor() = default;

  virtual std::string Name() const = 0;
  virtual bool Init(const Config& cfg, std::shared_ptr<PolarisReporter> reporter) = 0;
  virtual void Start() = 0;
  virtual void Stop() = 0;
};

} // namespace polaris
} // namespace voyah
