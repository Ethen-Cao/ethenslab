#pragma once
#include <cstdint>
#include <string>
#include <atomic>

namespace voyah {
namespace polaris {

class PolarisReporter {
public:
  PolarisReporter(std::string process_name, std::string process_ver);

  // params_json 必须是一个 JSON Object 字符串，例如：{"usage":12.3,"user":1.2}
  // 返回：0 成功入队；-EAGAIN drop；其他负值失败
  int Report(uint64_t event_id, const std::string& params_json, const char* log_path = nullptr) noexcept;

  struct Stats {
    uint64_t report_ok = 0;
    uint64_t report_drop = 0; // -EAGAIN
    uint64_t report_fail = 0;
  };

  Stats GetStats() const noexcept;

private:
  std::string process_name_;
  std::string process_ver_;

  std::atomic<uint64_t> ok_{0};
  std::atomic<uint64_t> drop_{0};
  std::atomic<uint64_t> fail_{0};

  // 降噪：连续失败每 N 次打一条
  static constexpr uint64_t kLogEveryN = 100;
};

} // namespace polaris
} // namespace voyah
