#include "core/PolarisReporter.h"

#include "utils/Log.h"
#include <cerrno>

// SDK C API
#include <polaris/polaris_api.h>

namespace voyah {
namespace polaris {

PolarisReporter::PolarisReporter(std::string process_name, std::string process_ver)
    : process_name_(std::move(process_name)), process_ver_(std::move(process_ver)) {}

int PolarisReporter::Report(uint64_t event_id, const std::string& params_json, const char* log_path) noexcept {
  const int rc = polaris_report_raw(
      event_id,
      process_name_.c_str(),
      process_ver_.c_str(),
      params_json.c_str(),
      log_path);

  if (rc == 0) {
    ok_.fetch_add(1, std::memory_order_relaxed);
    LOGD("PolarisReporter: report success. event_id=%llu, params=%s", (unsigned long long)event_id, params_json.c_str());
    return rc;
  }

  if (rc == -EAGAIN) {
    const auto v = drop_.fetch_add(1, std::memory_order_relaxed) + 1;
    if (v % kLogEveryN == 1) {
      LOGW("PolarisReporter: drop (-EAGAIN). dropped=%llu", (unsigned long long)v);
    }
    return rc;
  }

  const auto v = fail_.fetch_add(1, std::memory_order_relaxed) + 1;
  if (v % kLogEveryN == 1) {
    LOGW("PolarisReporter: report failed rc=%d, fail=%llu", rc, (unsigned long long)v);
  }
  return rc;
}

PolarisReporter::Stats PolarisReporter::GetStats() const noexcept {
  Stats s;
  s.report_ok = ok_.load(std::memory_order_relaxed);
  s.report_drop = drop_.load(std::memory_order_relaxed);
  s.report_fail = fail_.load(std::memory_order_relaxed);
  return s;
}

} // namespace polaris
} // namespace voyah
