# Polaris Monitor 软件设计说明书 (SDS)

| 项目名称     | Polaris (Linux Host)                             |
| -------- | ------------------------------------------------ |
| **模块名称** | **System Monitor (polaris-monitor)**             |
| **版本**   | **v1.1 (Refactored, Development Baseline)**      |
| **状态**   | **Release for Development**                      |
| **日期**   | **2026-02-11**                                   |
| **作者**   | Polaris Team                                     |
| **适用范围** | Linux Host (Cluster/IVI/T-Box) / Yocto / systemd |

---

## 1. 引言

### 1.1 背景与目的

Host 端需要一个轻量级、高可靠的守护进程，用于采集系统运行状态（资源使用、系统负载、关键服务健康度等），并通过 `libpolaris_client` 上报至 `polarisd`。这些数据将用于：

* 长期性能画像（趋势分析）
* 故障前兆检测（CPU 抖动、VM 压力、负载异常）
* 与 Guest / 业务事件做相关性分析（Host ↔ Guest）

### 1.2 设计原则

1. **稳定性 (Stability)**：采集异常不应导致进程崩溃；具备 systemd 自动重启；支持 SIGTERM 优雅退出。
2. **低开销 (Low Overhead)**：空闲态 CPU 占用接近 0；RSS < 5MB（v1.1 目标）。
3. **可扩展性 (Extensibility)**：采用 **Core + Plugins** 插件化架构；新增监控类型无需修改核心框架。
4. **架构解耦 (Decoupling)**：将 **主动轮询(Polling)** 与 **被动事件(Event-driven)** 模块解耦，独立演进。
5. **协议一致性 (Consistency)**：所有上报事件遵循统一 Event Schema（`params` 为 Object），与 `polarisd` 解析一致。

### 1.3 范围与版本边界

**v1.1 必须实现：**

* **Resource Monitor（Polling）**

  * CPU 使用率（基于 `/proc/stat` 差分）
  * 内存使用（基于 `/proc/meminfo`）
  * 系统负载（优先 `/proc/loadavg`，可选 `getloadavg()`）
* **Crash Monitor（Event-driven）**

  * 基于 systemd DBus（sd-bus）监听服务状态变化与异常退出
  * 白名单过滤（仅关注指定 unit）
* **统一上报（Reporting）**

  * 封装 `libpolaris_client`（`polaris_report_raw()`）+ JSON 序列化 + 错误码处理 + 限频日志

**v1.2+（预留扩展，不在本期交付）：**

* Journal 日志流监控（journald follow）
* TopN 进程 CPU/内存（按需）
* GPU/温度/电池等平台差异项
* cgroup / 容器维度指标
* eBPF 深度观测

---

## 2. 总体架构设计

### 2.1 系统上下文与进程边界

`polaris-monitor` 是由 systemd 管理的独立进程：

* **采集（Polling / Event）→ 生成 Event(JSON) → 调用 SDK 上报 → polarisd 处理**
* 监控进程 **不直接操作** `polarisd` 的 UDS 协议；仅通过 `libpolaris_client`（best-effort, at-most-once）投递。

### 2.2 逻辑架构（Core + Plugins）

* **Layer 1: Entry & Bootstrap**：`main.cpp`（加载配置、初始化日志、启动模块）
* **Layer 2: Core Infrastructure**：配置、Reporter、模块接口、ModuleManager
* **Layer 3: Monitor Modules**：

  * Resource Module：主动轮询（Polling）
  * Crash Module：事件驱动（Event-driven）
    -（预留）Journal Module：日志流监控

### 2.3 物理目录结构（Physical Architecture）

```text
polaris/monitor/
├── CMakeLists.txt
├── polaris-monitor.service
└── src/
    ├── main.cpp
    │
    ├── core/
    │   ├── Config.h/cpp
    │   ├── IMonitor.h
    │   ├── ModuleManager.h/cpp
    │   └── PolarisReporter.h/cpp
    │
    └── monitors/
        ├── resource/
        │   ├── ResourceMonitor.h/cpp          (implements IMonitor)
        │   ├── ResourceScheduler.h/cpp        (pure scheduler)
        │   └── collectors/
        │       ├── ICollector.h
        │       ├── CpuCollector.h/cpp
        │       ├── MemCollector.h/cpp
        │       └── LoadCollector.h/cpp
        │
        └── crash/
            ├── CrashMonitor.h/cpp             (implements IMonitor)
            ├── SystemdWatcher.h/cpp           (sd-bus loop)
            └── CrashAnalyzer.h/cpp            (normalize fields)
```

---

## 3. 核心接口设计

### 3.1 模块接口 `IMonitor`

目标：做到 `main.cpp` 零修改扩展。所有监控业务以插件形式实现此接口。

```cpp
class IMonitor {
public:
    virtual ~IMonitor() = default;
    virtual std::string Name() const = 0;

    // Init: 依赖注入 Config / Reporter（Reporter 为共享对象，需线程安全）
    virtual bool Init(const Config& cfg,
                      std::shared_ptr<PolarisReporter> reporter) = 0;

    // Start: 启动内部线程（或事件循环）
    virtual void Start() = 0;

    // Stop: 停止并阻塞等待线程退出（可选超时策略由实现决定）
    virtual void Stop() = 0;
};
```

### 3.2 资源采集接口 `ICollector`

```cpp
enum class CollectStatus { kOk, kSkip, kError };

struct CollectOutput {
    uint64_t eventId;
    Json::Value params;    // MUST be Object
    std::string logPath;   // optional
};

class ICollector {
public:
    virtual ~ICollector() = default;
    virtual const char* Name() const noexcept = 0;
    virtual CollectStatus CollectOnce(CollectOutput& out) noexcept = 0;
};
```

---

## 4. 线程模型与调度策略

### 4.1 Resource Monitor（Polling）线程模型

* ResourceMonitor 内部持有 `std::thread`
* 线程运行 `ResourceScheduler::RunLoop()`
* Scheduler 维护 collectors 的 next_due，并使用 `sleep_until()` 达到低 CPU

### 4.2 时间源（P0）

* **必须使用单调时钟**：`std::chrono::steady_clock`
* 禁止使用 `system_clock/time()` 作为调度依据，避免 NTP 校时导致周期错乱

### 4.3 调度策略（P0 写死实现语义）

**目标：既减少漂移，又避免卡顿后的补采风暴。**

**固定节拍 + 过载保护（推荐实现语义）：**

* 每个 Collector 维护 `interval` 和 `next_due`
* 触发后按固定节拍推进 `next_due += interval`
* 若系统曾严重卡顿（`now` 远超 `next_due`），则重置 `next_due = now + interval`（跳过补采）

**伪代码（作为实现约束）：**

```cpp
// per collector
if (!inited) next_due = now;  // first fire asap

if (now >= next_due) {
  CollectOnce();
  next_due += interval;

  // overload protection: if we are too late, skip catch-up
  if (now > next_due + 2*interval) {
    next_due = now + interval;
  }
}

// scheduler sleep policy
auto next_wakeup = min(all_collectors.next_due);
sleep_until(next_wakeup);
```

---

## 5. 数据协议（Event Schema）

### 5.1 统一 Event JSON Schema（P0 对齐 SDK / 服务端）

所有模块上报必须遵循以下 schema（`params` 必须为 Object）：

```json
{
  "eventId": 2001001,
  "timestamp": 1770312345678,
  "pid": 1234,
  "processName": "polaris-monitor",
  "processVer": "1.1.0",
  "params": { },
  "logf": ""
}
```

**字段规则：**

* `timestamp`：毫秒（ms）
* `pid`：当前进程 PID
* `processName`：默认 `polaris-monitor`（可配置覆盖）
* `processVer`：编译宏或版本文件（默认 "unknown"）
* `logf`：可选，默认空字符串
* `params`：必须是 JSON Object（禁止 stringified JSON）

### 5.2 Event ID 引用与规范

EventId 定义来源：`common/include/polaris/defs/EventIds.h`（以仓库真实路径为准）。

| 模块       | 指标            | Event ID (Macro)           | params 字段                                                                        |
| -------- | ------------- | -------------------------- | -------------------------------------------------------------------------------- |
| Resource | CPU Load      | `PVM_SYS_CPU_LOAD_STAT`    | usage, user, system, iowait, irq, softirq, steal                                 |
| Resource | Memory        | `PVM_SYS_MEMORY_LOAD_STAT` | total_kb, avail_kb, used_kb, used_pct                                            |
| Resource | LoadAvg       | `PVM_SYS_LOADAVG_STAT`     | load1, load5, load15, running, threads                                           |
| Crash    | Service Crash | `PVM_PROC_CRASH_STAT`      | unit_name, active_state, result, exec_main_code, exec_main_status, exec_main_pid |

> 注：宏名以你们 EventId Registry 为准，这里用于设计约束与字段规划。

---

## 6. 子模块详细设计

## 6.1 Resource Monitor（资源采集 / Polling）

### 6.1.1 功能职责

* 注册多个 Collector
* 调度执行（按各自 interval）
* 将 Collector 输出交给 Reporter 上报（统一 schema）
* 维护统计计数与限频日志

### 6.1.2 Collector 规范

#### CPU Collector（/proc/stat 差分）

**输入：**
`/proc/stat` 第一行 `cpu  user nice system idle iowait irq softirq steal guest guest_nice`

**算法：**

* 保存上一帧 tick（prev）
* 当前帧 tick（cur）
* `delta_total = sum(cur - prev)`
* `delta_idle_all = (idle + iowait) delta`
* `usage = (delta_total - delta_idle_all) / delta_total * 100`

**行为：**

* 首次读取：缓存 prev，返回 `kSkip`
* 解析失败：返回 `kError`
* 输出 `params`：`usage/user/system/iowait/irq/softirq/steal`（百分比 double）

#### Memory Collector（/proc/meminfo）

* 读取 `MemTotal`、`MemAvailable`
* `used_kb = total_kb - avail_kb`
* `used_pct = used_kb / total_kb * 100`

#### Load Collector（/proc/loadavg 优先）

* 首选解析 `/proc/loadavg`
* 可选：若编译/平台提供 `getloadavg()`，可作为替代实现，但必须保留 `/proc/loadavg` fallback

输出字段：

* `load1/load5/load15`
* `running/threads`（来自 `running/threads`）

---

## 6.2 Crash Monitor（服务崩溃监听 / Event-driven）

### 6.2.1 运行模式与线程模型

* CrashMonitor 内部持有 `std::thread`
* 线程运行 `SystemdWatcher` 的 sd-bus loop（阻塞等待信号）

### 6.2.2 依赖与技术选型（P1 写死）

* 推荐直接使用 `libsystemd` 的 **sd-bus**（最少依赖）
* 连接：**system bus**
* 监听方式：订阅 `org.freedesktop.DBus.Properties.PropertiesChanged`

### 6.2.3 监听对象与字段（P1 写死）

对于白名单 unit（如 `polarisd.service`、`weston.service`）：

* 目标对象路径：`/org/freedesktop/systemd1/unit/<escaped_unit_name>`
* 关注接口：

  * `org.freedesktop.systemd1.Unit`
  * `org.freedesktop.systemd1.Service`

**关键属性（至少读取）：**

* `ActiveState` / `SubState`
* `Result`
* `ExecMainCode`
* `ExecMainStatus`
* `ExecMainPID`

### 6.2.4 触发条件（P1 写死）

仅当满足“非正常退出”才上报：

* `ActiveState == "failed"` **或**
* `Result != "success"` **或**
* `ExecMainCode != 0` **或**
* `ExecMainStatus != 0`

并通过白名单过滤：

* 仅处理 whitelist 中 unit
* 其他 unit 丢弃（避免刷屏）

输出事件 `PVM_PROC_CRASH_STAT`，params 示例：

```json
{
  "unit_name": "polarisd.service",
  "active_state": "failed",
  "result": "exit-code",
  "exec_main_code": 1,
  "exec_main_status": 1,
  "exec_main_pid": 1234
}
```

---

## 7. PolarisReporter（统一上报器）

### 7.1 职责

* 统一 schema 构建（补齐 timestamp/pid/processName/processVer/logf）
* JSON 序列化（无缩进、UTF-8）
* 调用 `polaris_report_raw(eventId, processName, processVer, json_body, logPath)`
* 处理返回码、计数器、限频日志
* 必须线程安全（Resource 与 Crash 可并发上报）

### 7.2 返回码处理规则（P0）

* `0`：入队成功 → `report_ok++`
* `-EAGAIN`：SDK 队列满（drop）→ `report_drop++`（限频 log）
* `-E2BIG`：payload 超限（drop）→ `report_drop++`（限频 log）
* 其他 `<0`：`report_fail++`（限频 log）

**强约束：不重试同一条数据**（best-effort, at-most-once），避免放大压力。

---

## 8. 配置设计

### 8.1 配置文件

路径：`/etc/polaris/monitor.json`（可选；无配置必须能跑）

```json
{
  "process_name": "polaris-monitor",
  "process_ver": "1.1.0",
  "resource": {
    "enable": true,
    "cpu_interval_ms": 3000,
    "mem_interval_ms": 5000,
    "load_interval_ms": 5000
  },
  "crash": {
    "enable": true,
    "whitelist": ["polarisd.service", "weston.service"]
  }
}
```

### 8.2 配置优先级

1. 配置文件
2. 编译默认值（硬编码默认）

---

## 9. 日志与可观测性

### 9.1 日志策略（推荐）

systemd 环境下推荐输出到 `stderr`，由 journald 收集：

* `StandardOutput=journal`
* `StandardError=journal`

也可通过编译宏切换 syslog（若已有统一 Log 头）。

### 9.2 运行指标（至少）

* `collect_ok / collect_skip / collect_fail`
* `report_ok / report_fail / report_drop`
* `last_report_errno`（最近一次上报失败 errno-style）

限频策略建议：

* 同类错误每 N 次打印一次（N=100/1000）
* 启动、配置加载、模块启动：INFO
* 成功上报默认不刷屏（除非 debug）

---

## 10. 异常处理与稳定性

### 10.1 polarisd 未启动 / socket 不存在

* Reporter/SDK 返回 `<0`
* Monitor 不退出
* 计数 + 限频日志
* 待 polarisd 恢复后继续上报

### 10.2 /proc 读取失败

* 单次失败：collector 返回 `kError`
* 不影响其他 collector
* 计数 + 限频日志

### 10.3 自身退出与重启

systemd unit 建议：

* `Restart=always`
* `RestartSec=5`
* `After=polarisd.service`（可选，非强依赖）
* 收到 SIGTERM：Stop 模块 → join 线程 → 退出

---

## 11. 构建与 Yocto/systemd 集成

### 11.1 依赖

* `jsoncpp`（或与 polarisd 一致的 JSON 库）
* Crash Monitor：`libsystemd`（sd-bus）

### 11.2 产物与安装

* 可执行：`/usr/bin/polaris-monitor`
* unit：`/usr/lib/systemd/system/polaris-monitor.service`
* 配置（可选）：`/etc/polaris/monitor.json`

---

## 12. 验收标准（Acceptance Criteria）

1. **基本功能**：polarisd 能持续收到 CPU/Mem/Load 周期性数据
2. **准确性**：CPU 使用率与 `top`/`vmstat` 对比误差 < 5%（按同时间窗）
3. **Crash 捕获**：对 whitelist unit 人为制造异常退出（如 `kill -9`）能上报 crash event
4. **资源消耗**：Monitor CPU < 1%，RSS < 5MB（正常周期配置下）
5. **健壮性**：

   * 停止 polarisd：monitor 不崩溃，错误日志受控
   * 重启 polarisd：monitor 自动恢复上报
6. **并发安全**：Resource 与 Crash 同时上报时无数据竞争/崩溃（Reporter 线程安全）

---

## 附录 A：/proc/stat 说明

`/proc/stat` 的 `cpu` 行是从开机以来的 **累计 jiffies**，必须做差分（delta）才能得到某个采样周期内的 CPU 使用率。

