#include "Transport.h"
#include "utils/Log.h" 
#include "polaris/protocol/LspDef.h"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstring>
#include <chrono>
#include <endian.h>

namespace voyah {
namespace polaris {

static constexpr uint64_t MIN_RETRY_INTERVAL_MS = 100;
static constexpr uint64_t MAX_RETRY_INTERVAL_MS = 5000;

using namespace protocol;

Transport::Transport(const std::string& socketPath) 
    : mSocketPath(socketPath)
    , mFd(-1)
    , mRetryCount(0)
    , mLastConnectTime(0) {
}

Transport::~Transport() {
    close();
}

// ---------------------------------------------------------
// Public Interface (Thread-Safe Wrapper)
// ---------------------------------------------------------

void Transport::close() {
    std::lock_guard<std::mutex> lock(mMutex);
    closeLocked();
}

bool Transport::connect() {
    std::lock_guard<std::mutex> lock(mMutex);
    return connectLocked();
}

bool Transport::isConnected() {
    std::lock_guard<std::mutex> lock(mMutex);
    return mFd >= 0;
}

// ---------------------------------------------------------
// Internal Logic (Must be called with mMutex held)
// ---------------------------------------------------------

void Transport::closeLocked() {
    if (mFd >= 0) {
        ::close(mFd);
        mFd = -1;
    }
}

bool Transport::connectLocked() {
    if (mFd >= 0) return true;

    // 1. 退避检查
    auto now = std::chrono::steady_clock::now();
    uint64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
    
    uint64_t interval = MIN_RETRY_INTERVAL_MS * (1ULL << mRetryCount);
    if (interval > MAX_RETRY_INTERVAL_MS) interval = MAX_RETRY_INTERVAL_MS;

    if (nowMs - mLastConnectTime < interval) {
        return false; 
    }

    mLastConnectTime = nowMs;

    // 2. 创建 Socket
    int fd = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        LOGE("Transport: socket create failed: %s", strerror(errno));
        return false;
    }

    struct sockaddr_un addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    
    // [修复] 安全的 path 拷贝，防止越界
    std::strncpy(addr.sun_path, mSocketPath.c_str(), sizeof(addr.sun_path) - 1);
    addr.sun_path[sizeof(addr.sun_path) - 1] = '\0'; // 强制 NULL 结尾

    if (::connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        LOGW("Transport: connect failed: %s (Retry %d)", strerror(errno), mRetryCount);
        ::close(fd);
        if (mRetryCount < 10) mRetryCount++;
        return false;
    }

    // [修复] 检查 fcntl 返回值
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) {
        LOGE("Transport: fcntl GET failed");
        ::close(fd);
        return false;
    }
    
    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
        LOGE("Transport: fcntl SET NONBLOCK failed");
        ::close(fd);
        return false;
    }

    mFd = fd;
    mRetryCount = 0;
    LOGI("Transport: connected to %s", mSocketPath.c_str());
    return true;
}

void Transport::buildHeader(uint32_t payloadLen, uint8_t* outHeader) {
    protocol::Header header;
    header.totalLen = htole32(protocol::HEADER_SIZE + payloadLen);
    header.msgType  = htole16(protocol::EVENT_REPORT);
    header.reserved = 0;
    header.reqId    = 0;
    std::memcpy(outHeader, &header, sizeof(header));
}

bool Transport::send(const std::string& payload) {
    // [关键] 加锁保护整个发送过程
    std::lock_guard<std::mutex> lock(mMutex);

    // 1. 确保连接 (调用内部无锁版本)
    if (mFd < 0) {
        if (!connectLocked()) return false;
    }

    // 2. 准备数据
    uint8_t header[HEADER_SIZE];
    buildHeader(static_cast<uint32_t>(payload.size()), header);

    struct iovec iov[2];
    iov[0].iov_base = header;
    iov[0].iov_len = HEADER_SIZE;
    iov[1].iov_base = const_cast<char*>(payload.data());
    iov[1].iov_len = payload.size();

    struct msghdr msg = {};
    msg.msg_iov = iov;
    msg.msg_iovlen = 2;

    // 3. 发送 (循环处理 EINTR)
    ssize_t ret = -1;
    do {
        // 使用 sendmsg 支持 MSG_NOSIGNAL
        ret = ::sendmsg(mFd, &msg, MSG_NOSIGNAL | MSG_DONTWAIT);
    } while (ret < 0 && errno == EINTR); // [修复] 处理信号中断

    if (ret < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            // Buffer 满，丢弃 (不关闭连接)
            LOGW("Transport: buffer full, event dropped");
            return false;
        } 
        else {
            // 连接错误，关闭 (调用内部无锁版本)
            LOGW("Transport: send error: %s", strerror(errno));
            closeLocked();
            return false;
        }
    }

    // 4. 处理 Partial Write
    size_t totalBytes = HEADER_SIZE + payload.size();
    if (static_cast<size_t>(ret) < totalBytes) {
        LOGE("Transport: partial write %zd / %zu. Closing.", ret, totalBytes);
        closeLocked();
        return false;
    }

    return true;
}

} // namespace polaris
} // namespace voyah