#pragma once

#include <string>
#include <cstdint>
#include <json/json.h> // 依赖 jsoncpp

namespace voyah {
namespace polaris {

/**
 * @brief 事件构建器
 * * 职责：
 * 1. 收集事件字段 (EventID, ProcessName, Params, LogPath)
 * 2. 自动填充上下文 (PID, Timestamp)
 * 3. 序列化为 JSON 字符串
 * * 注意：此类非线程安全 (Builder 模式通常由单线程操作)
 */
class PolarisEventBuilder {
public:
    explicit PolarisEventBuilder(uint64_t eventId);
    ~PolarisEventBuilder() = default;

    // --- 基础属性设置 ---
    void setProcessName(const char* name);
    void setProcessVer(const char* ver);
    void setLogPath(const char* path);

    // --- Params (Key-Value) 设置 ---
    void addString(const std::string& key, const std::string& value);
    void addInt(const std::string& key, int32_t value);
    void addLong(const std::string& key, int64_t value);
    void addDouble(const std::string& key, double value);
    void addBool(const std::string& key, bool value);

    /**
     * @brief 设置原始 JSON 参数 (用于 polaris_report_raw)
     * 如果调用了此方法，之前通过 add* 添加的参数将被忽略或覆盖。
     */
    void setRawParams(const std::string& rawJson);

    /**
     * @brief 构建最终 payload
     * @return 序列化后的 JSON 字符串 (无换行，紧凑格式)
     */
    std::string build();

private:
    // 自动获取当前进程名
    std::string autoGetProcessName();
    // 自动获取当前时间戳 (ms)
    uint64_t getCurrentTimeMs();

private:
    uint64_t mEventId;
    uint64_t mTimestamp;
    int32_t mPid;
    
    std::string mProcessName;
    std::string mProcessVer;
    std::string mLogPath;

    // 存储 params 键值对
    Json::Value mParams; 
    
    // 如果不为空，则优先使用此原始字符串作为 params
    std::string mRawParams; 
};

} // namespace polaris
} // namespace voyah