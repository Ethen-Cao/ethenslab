#include "PolarisEventBuilder.h"

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include <cstring>
#include <fstream>
#include <sstream>

// GLIBC 扩展：获取当前程序名
#include <errno.h>
extern char *program_invocation_short_name;

namespace voyah {
namespace polaris {

PolarisEventBuilder::PolarisEventBuilder(uint64_t eventId) 
    : mEventId(eventId), mParams(Json::objectValue) {
    // 自动填充基础信息
    mPid = getpid();
    mTimestamp = getCurrentTimeMs();
    mProcessName = autoGetProcessName();
    mProcessVer = "unknown"; // 默认值
}

void PolarisEventBuilder::setProcessName(const char* name) {
    if (name && *name) {
        mProcessName = name;
    }
}

void PolarisEventBuilder::setProcessVer(const char* ver) {
    if (ver && *ver) {
        mProcessVer = ver;
    }
}

void PolarisEventBuilder::setLogPath(const char* path) {
    if (path && *path) {
        mLogPath = path;
    }
}

// --- Params Setters ---

void PolarisEventBuilder::addString(const std::string& key, const std::string& value) {
    mParams[key] = value;
}

void PolarisEventBuilder::addInt(const std::string& key, int32_t value) {
    mParams[key] = value;
}

void PolarisEventBuilder::addLong(const std::string& key, int64_t value) {
    mParams[key] = (Json::Int64)value;
}

void PolarisEventBuilder::addDouble(const std::string& key, double value) {
    mParams[key] = value;
}

void PolarisEventBuilder::addBool(const std::string& key, bool value) {
    mParams[key] = value;
}

void PolarisEventBuilder::setRawParams(const std::string& rawJson) {
    mRawParams = rawJson;
}

// --- Build ---

std::string PolarisEventBuilder::build() {
    Json::Value root;
    
    // 1. 组装标准字段
    root["eventId"] = (Json::UInt64)mEventId;
    root["timestamp"] = (Json::UInt64)mTimestamp;
    root["pid"] = mPid;
    root["processName"] = mProcessName;
    
    if (!mProcessVer.empty()) {
        root["processVer"] = mProcessVer;
    }
    
    if (!mLogPath.empty()) {
        root["logf"] = mLogPath;
    }

    // 2. 组装 Params
    if (!mRawParams.empty()) {
        // 如果有 Raw Params，尝试解析并合并
        // 为了安全，如果解析失败，我们将其作为字符串存储，或者放入 error 字段
        // 这里采用：尝试解析为 Object，失败则存为 String
        Json::Reader reader;
        Json::Value rawObj;
        if (reader.parse(mRawParams, rawObj)) {
            root["params"] = rawObj;
        } else {
            // 解析失败，回退为字符串，避免丢数据
            root["params"] = mRawParams;
        }
    } else {
        // 常规 Key-Value 模式
        root["params"] = mParams;
    }

    // 3. 序列化为字符串 (Compact)
    Json::StreamWriterBuilder builder;
    builder["commentStyle"] = "None";
    builder["indentation"] = ""; // 无缩进
    return Json::writeString(builder, root);
}

// --- Helpers ---

uint64_t PolarisEventBuilder::getCurrentTimeMs() {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

std::string PolarisEventBuilder::autoGetProcessName() {
    // 优先使用 glibc 全局变量 (最快)
    if (program_invocation_short_name && *program_invocation_short_name) {
        return std::string(program_invocation_short_name);
    }

    // 回退读取 /proc/self/comm
    std::ifstream commFile("/proc/self/comm");
    if (commFile.is_open()) {
        std::string name;
        std::getline(commFile, name);
        if (!name.empty()) {
            // 移除可能的换行符
            if (name.back() == '\n') name.pop_back();
            return name;
        }
    }

    return "unknown_process";
}

} // namespace polaris
} // namespace voyah