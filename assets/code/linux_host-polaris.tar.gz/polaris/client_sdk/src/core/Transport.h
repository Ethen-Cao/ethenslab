#pragma once
#include <string>
#include <atomic>
#include <mutex> // [新增]

namespace voyah {
namespace polaris {

class Transport {
public:
    // [新增] 支持传入 socket path，不再硬编码
    explicit Transport(const std::string& socketPath = "/run/polaris/polaris_bridge.sock");
    ~Transport();

    // 尝试连接 (线程安全)
    bool connect();
    
    // 断开连接 (线程安全)
    void close();

    // 发送数据 (线程安全, 非阻塞)
    bool send(const std::string& payload);
    
    bool isConnected(); // 线程安全读取

private:
    // [新增] 内部辅助函数 (假定已持有锁)
    // 防止 send() 加锁后调用 connect() 再次加锁导致死锁
    bool connectLocked();
    void closeLocked();
    void setNonBlocking(int fd);
    void buildHeader(uint32_t payloadLen, uint8_t* outHeader);

    std::string mSocketPath;
    int mFd;
    int mRetryCount;
    uint64_t mLastConnectTime;

    // [新增] 互斥锁，保护所有成员变量
    mutable std::mutex mMutex; 
};

} // namespace polaris
} // namespace voyah