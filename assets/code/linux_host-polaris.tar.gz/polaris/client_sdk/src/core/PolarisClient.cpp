#include "PolarisClient.h"
#include "Transport.h" // 稍后实现
#include "utils/Log.h"        // 假设复用服务端的 Log 工具，或者 client 需自备简易 Log

#include <chrono>
#include <mutex>
#include <cerrno>

namespace voyah {
namespace polaris {

PolarisClient& PolarisClient::getInstance() {
    static PolarisClient instance;
    return instance;
}

PolarisClient::PolarisClient() {
    // 构造时不启动，lazy init
}

PolarisClient::~PolarisClient() {
    deinit(0); // 确保析构时停止
}

void PolarisClient::init() {
    if (mInited.exchange(true)) {
        return; // 已经初始化过
    }

    // 1. 初始化 Transport
    mTransport = std::make_shared<Transport>();

    // 2. 启动 Worker 线程
    mRunning = true;
    mWorkerThread = std::thread(&PolarisClient::workerLoop, this);

    // 设置线程名 (Client SDK 最好加上前缀避免混淆)
    pthread_setname_np(mWorkerThread.native_handle(), "PolClientWork");
}

void PolarisClient::deinit(int timeoutMs) {
    bool expected = true;
    if (!mInited.compare_exchange_strong(expected, false)) {
        return; // 未初始化或已反初始化
    }

    mRunning = false;
    mQueueCv.notify_all(); // 唤醒线程

    if (mWorkerThread.joinable()) {
        mWorkerThread.join();
    }
    
    // 清理队列
    std::lock_guard<std::mutex> lock(mQueueMutex);
    mQueue.clear();
    mCurrentBytes = 0;
    
    // Transport 清理
    if (mTransport) {
        mTransport->close(); // Transport 需要提供 close
    }
}

int PolarisClient::enqueue(std::string payload) {
    // 1. 基础校验
    if (!mInited) {
        init(); // Lazy Init
    }

    if (payload.empty()) return -EINVAL;
    
    if (payload.size() > MAX_PAYLOAD_SIZE) {
        // 限频日志
        LOGW("Payload too large: %zu", payload.size()); 
        return -E2BIG;
    }

    {
        std::lock_guard<std::mutex> lock(mQueueMutex);

        // 2. 流量控制 (Backpressure)
        if (mCurrentBytes + payload.size() > MAX_QUEUE_BYTES) {
            mStatDrop.fetch_add(1, std::memory_order_relaxed);
            // 可以在这里加个限频日志：RateLimitLog("Queue full, dropped event");
            LOGW("PolarisClient: queue full, drop event");
            return -EAGAIN;
        }

        // 3. 入队
        mCurrentBytes += payload.size();
        mQueue.push_back(std::move(payload));
    }

    mStatEnqueue.fetch_add(1, std::memory_order_relaxed);
    mQueueCv.notify_one();
    return 0;
}

void PolarisClient::workerLoop() {
    // 局部缓冲，用于减少锁竞争
    std::string currentPayload;
    static uint64_t send_attempt_count = 0;

    while (mRunning) {
        {
            std::unique_lock<std::mutex> lock(mQueueMutex);
            
            // 等待数据或停止信号
            mQueueCv.wait(lock, [this] {
                return !mQueue.empty() || !mRunning;
            });

            if (!mRunning && mQueue.empty()) {
                break;
            }
            
            // 取出一个任务
            // 优化：也可以 swap 整个队列出来批量发送，减少 lock 次数。
            // 但考虑到 IPC 发送本身可能有耗时（如果 buffer 满），逐个取能保证即时性。
            // 这里为了简单稳健，先逐个取。
            currentPayload = std::move(mQueue.front());
            mQueue.pop_front();
            mCurrentBytes -= currentPayload.size();
        }

        // --- 发送阶段 (无锁) ---
        if (mTransport) {
            
            ++send_attempt_count;

            // Transport 负责重连、打包 Header、处理 SIGPIPE
            bool success = mTransport->send(currentPayload);
            if (success) {
                mStatSendSuccess.fetch_add(1, std::memory_order_relaxed);
            } else {
                // 发送失败 (Transport 内部已重试过或判定不可达)
                // 策略：丢弃 (At-most-once)
                mStatSendFail.fetch_add(1, std::memory_order_relaxed);
            }

            // 每 100 次尝试打印一次（无论成功失败）
            if (send_attempt_count % 100 == 0) {
                auto stats = getStats();
                LOGI("PolarisClient periodic stats: "
                        "enq=%llu drop=%llu succ=%llu fail=%llu pending=%zu",
                        stats.enqueueCount,
                        stats.dropCount,
                        stats.sendSuccessCount,
                        stats.sendFailCount,
                        stats.pendingBytes);
            }
        }
    }
}

PolarisClient::Stats PolarisClient::getStats() const {
    Stats s;
    s.enqueueCount = mStatEnqueue.load(std::memory_order_relaxed);
    s.dropCount = mStatDrop.load(std::memory_order_relaxed);
    s.sendSuccessCount = mStatSendSuccess.load(std::memory_order_relaxed);
    s.sendFailCount = mStatSendFail.load(std::memory_order_relaxed);
    
    std::lock_guard<std::mutex> lock(mQueueMutex);
    s.pendingBytes = mCurrentBytes;
    return s;
}

} // namespace polaris
} // namespace voyah