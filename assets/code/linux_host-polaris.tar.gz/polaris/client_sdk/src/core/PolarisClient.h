#pragma once

#include <atomic>
#include <condition_variable>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace voyah {
namespace polaris {

class Transport; // 前置声明

/**
 * @brief Polaris Client SDK 核心管理器 (单例)
 *
 * 职责:
 * 1. 管理 SDK 初始化与反初始化 (Init/Deinit)
 * 2. 维护异步发送队列 (AsyncQueue) 与内存预算 (Byte Budget)
 * 3. 调度后台发送线程 (WorkerThread)
 * 4. 维护统计指标 (Metrics)
 */
class PolarisClient {
public:
    static PolarisClient& getInstance();

    // 禁止拷贝
    PolarisClient(const PolarisClient&) = delete;
    PolarisClient& operator=(const PolarisClient&) = delete;

    /**
     * @brief 初始化 SDK
     * 线程安全，幂等。第一次调用会启动后台线程。
     */
    void init();

    /**
     * @brief 反初始化 SDK
     * 停止后台线程，清理资源。建议在进程退出前调用。
     * @param timeoutMs 尝试发送剩余数据的最大等待时间 (ms)
     */
    void deinit(int timeoutMs = 100);

    /**
     * @brief 将序列化好的事件入队
     * @param payload 已经序列化好的 JSON 字符串 (不含 Header)
     * @return 0: 成功; -EAGAIN: 队列满; -EINVAL: 参数错; -ENOMEM: 内存错
     */
    int enqueue(std::string payload);

    // --- 可观测性 ---
    struct Stats {
        uint64_t enqueueCount;
        uint64_t dropCount;
        uint64_t sendSuccessCount;
        uint64_t sendFailCount;
        size_t pendingBytes;
    };
    Stats getStats() const;

private:
    PolarisClient();
    ~PolarisClient();

    // 后台工作线程循环
    void workerLoop();

private:
    std::atomic<bool> mInited{false};
    std::atomic<bool> mRunning{false};
    
    // --- 异步队列 ---
    mutable std::mutex mQueueMutex;
    std::condition_variable mQueueCv;
    std::deque<std::string> mQueue;
    
    // 流量控制
    size_t mCurrentBytes = 0;
    static constexpr size_t MAX_QUEUE_BYTES = 4 * 1024 * 1024; // 4MB 上限
    static constexpr size_t MAX_PAYLOAD_SIZE = 2 * 1024 * 1024; // 单包 2MB

    // --- 后台线程 ---
    std::thread mWorkerThread;

    // --- 通信层 ---
    std::shared_ptr<Transport> mTransport;

    // --- 统计指标 (Atomic) ---
    std::atomic<uint64_t> mStatEnqueue{0};
    std::atomic<uint64_t> mStatDrop{0};
    std::atomic<uint64_t> mStatSendSuccess{0};
    std::atomic<uint64_t> mStatSendFail{0};
};

} // namespace polaris
} // namespace voyah