#include "polaris/polaris_api.h"
#include "PolarisClient.h"
#include "PolarisEventBuilder.h"

#include <cstring>
#include <new> // for std::nothrow
#include <exception>

// 使用 voyah::polaris 命名空间简化代码，但在 extern "C" 中需小心
using namespace voyah::polaris;

// ============================================================================
// Internal Helpers
// ============================================================================

// 宏：统一的异常捕获与错误处理
#define POLARIS_CATCH_ALL_RETURN(ret_val) \
    catch (const std::exception& e) { \
        /* 可以选择性 Log e.what()，但要注意 Log 系统的重入性 */ \
        return -1; /* 通用错误 */ \
    } \
    catch (...) { \
        return -1; \
    }

// 宏：检查 Handle 有效性
#define CHECK_HANDLE(h) \
    if ((h) == nullptr) return -EINVAL; \
    auto* builder = reinterpret_cast<PolarisEventBuilder*>(h);

// ============================================================================
// Public C API Implementation
// ============================================================================

extern "C" {

int polaris_event_create(uint64_t event_id,
                         const char* process_name,
                         const char* process_ver,
                         PolarisEventHandle* out_handle) {
    if (out_handle == nullptr) return -EINVAL;
    if (event_id == 0) return -EINVAL;

    try {
        // 1. 触发 SDK 初始化 (Lazy Init)
        PolarisClient::getInstance().init();

        // 2. 创建 Builder
        // 使用 std::nothrow 防止 new 失败抛异常 (虽然极少见)
        auto* builder = new (std::nothrow) PolarisEventBuilder(event_id);
        if (!builder) return -ENOMEM;

        // 3. 填充基础信息
        if (process_name) builder->setProcessName(process_name);
        if (process_ver) builder->setProcessVer(process_ver);

        *out_handle = reinterpret_cast<PolarisEventHandle>(builder);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_add_string(PolarisEventHandle handle, const char* key, const char* value) {
    CHECK_HANDLE(handle);
    if (!key || !value) return -EINVAL;
    try {
        builder->addString(key, value);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_add_int(PolarisEventHandle handle, const char* key, int32_t value) {
    CHECK_HANDLE(handle);
    if (!key) return -EINVAL;
    try {
        builder->addInt(key, value);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_add_long(PolarisEventHandle handle, const char* key, int64_t value) {
    CHECK_HANDLE(handle);
    if (!key) return -EINVAL;
    try {
        builder->addLong(key, value);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_add_double(PolarisEventHandle handle, const char* key, double value) {
    CHECK_HANDLE(handle);
    if (!key) return -EINVAL;
    try {
        builder->addDouble(key, value);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_add_bool(PolarisEventHandle handle, const char* key, bool value) {
    CHECK_HANDLE(handle);
    if (!key) return -EINVAL;
    try {
        builder->addBool(key, value);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_commit(PolarisEventHandle handle, const char* log_path) {
    CHECK_HANDLE(handle);
    
    // 无论成功失败，commit 后都要销毁 handle
    // 使用 unique_ptr 接管，确保出了作用域自动 delete
    std::unique_ptr<PolarisEventBuilder> builderPtr(reinterpret_cast<PolarisEventBuilder*>(handle));

    try {
        if (log_path) {
            builderPtr->setLogPath(log_path);
        }

        // 序列化
        std::string payload = builderPtr->build();
        if (payload.empty()) return -EINVAL;

        // 入队发送
        return PolarisClient::getInstance().enqueue(std::move(payload));
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_event_cancel(PolarisEventHandle handle) {
    CHECK_HANDLE(handle);
    try {
        delete reinterpret_cast<PolarisEventBuilder*>(handle);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_report_raw(uint64_t event_id,
                       const char* process_name,
                       const char* process_ver,
                       const char* json_body,
                       const char* log_path) {
    if (event_id == 0 || !json_body) return -EINVAL;

    try {
        // Raw 接口也需要确保初始化
        PolarisClient::getInstance().init();

        // 临时创建一个 Builder 来复用其封装逻辑
        // (比手动拼接字符串更安全，且能复用 process_name 自动获取逻辑)
        PolarisEventBuilder builder(event_id);
        
        if (process_name) builder.setProcessName(process_name);
        if (process_ver) builder.setProcessVer(process_ver);
        if (log_path) builder.setLogPath(log_path);
        
        // 特殊处理：直接设置 params 为 Raw JSON
        // 这需要 PolarisEventBuilder 提供一个 setRawParams 接口，
        // 或者我们在这里手动构造 payload。
        // 为了架构统一，建议在 PolarisEventBuilder 中增加 setRawParamsStr(string)
        builder.setRawParams(json_body);

        std::string payload = builder.build();
        return PolarisClient::getInstance().enqueue(std::move(payload));
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

int polaris_deinit(void) {
    try {
        // 使用默认超时 100ms
        PolarisClient::getInstance().deinit(100);
        return 0;
    }
    POLARIS_CATCH_ALL_RETURN(-1)
}

} // extern "C"